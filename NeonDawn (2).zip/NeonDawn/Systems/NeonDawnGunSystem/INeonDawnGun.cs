﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;

namespace NeonDawn.Systems.NeonDawnGunSystem
{
    /// <summary>
    /// 表示一个需要应用 NeonDawn 枪械系统的物品.
    /// </summary>
    public interface INeonDawnGun
    {
        /// <summary>
        /// 指示当前是否可进行换弹.
        /// </summary>
        public bool CanReload( );
        /// <summary>
        /// 指示当前进行的换弹计算.
        /// </summary>
        /// <returns></returns>
        public bool ReloadUpdate( );
        /// <summary>
        /// 进行弹匣未空状态的换弹.
        /// </summary>
        public void Reload( );
        /// <summary>
        /// 进行弹匣的强制换弹.
        /// <br>[!] 在弹匣清空的情况下进行.</br>
        /// </summary>
        public void ForcedReload( );
        /// <summary>
        /// 当换弹完成时.
        /// </summary>
        public void OnReloadComplete( );
        /// <summary>
        /// 手持物品时进行的UI层面的绘制.
        /// </summary>
        public void HoldItemDraw( );

    }
}