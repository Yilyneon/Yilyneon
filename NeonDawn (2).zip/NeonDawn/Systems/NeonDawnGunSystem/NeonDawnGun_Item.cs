﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using NeonDawn.Items.Weapon.Gun.G0;
using ReLogic.Content;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Color = Microsoft.Xna.Framework.Color;
using Rectangle = Microsoft.Xna.Framework.Rectangle;

namespace NeonDawn.Systems.NeonDawnGunSystem
{
    /// <summary>
    /// NeonDawn 的独特枪械系统.
    /// </summary>
    public class NeonDawnGun_Item : GlobalItem
    {
        public override bool InstancePerEntity => true;

        /// <summary>
        /// 弹药优先.
        /// </summary>
        public int AmmoPriority = AmmoID.Bullet;

        /// <summary>
        /// 指示当前弹匣中是否仅剩一发子弹.
        /// </summary>
        public bool LastRound => MagazineCount <= 0;

        /// <summary>
        /// 弹匣容量.
        /// </summary>
        public int MagazineCap = 0;
        /// <summary>
        /// 弹匣计数.
        /// </summary>
        public int MagazineCount = 0;

        /// <summary>
        /// 指示是否自动换弹.
        /// </summary>
        public bool AutoReload = true;
        /// <summary>
        /// 换弹所需时间.
        /// </summary>
        public int ReloadTime = 60;
        /// <summary>
        /// 换弹计时器.
        /// </summary>
        public int ReloadTimer = 0;

        /// <summary>
        /// 强制换弹中.
        /// </summary>
        public bool OnForcedReload = false;
        /// <summary>
        /// 强制换弹所需时间.
        /// </summary>
        public int ForcedReloadTime = 600;
        /// <summary>
        /// 强制换弹计时器.
        /// </summary>
        public int ForcedReloadTimer = 0;

        private static Texture2D Icon;

        public override void HoldItem( Item item, Player player )
        {
            if( item.ModItem != null && item.ModItem is INeonDawnGun neonDawnGun )
            {
                if( AutoReload && ReloadTimer < ReloadTime && !OnForcedReload )
                {
                    ReloadTimer++;
                    neonDawnGun.ReloadUpdate( );
                }
                else if( ReloadTimer >= ReloadTime && !OnForcedReload )
                {
                    if( neonDawnGun.CanReload( ) && MagazineCount > 0 )
                    {
                        neonDawnGun.Reload( );
                        if( MagazineCount >= MagazineCap )
                            neonDawnGun.OnReloadComplete( );
                        ReloadTimer = 0;
                    }
                }

                if( AutoReload && ForcedReloadTimer < ForcedReloadTime )
                {
                    ForcedReloadTimer++;
                }
                else if( ForcedReloadTimer >= ForcedReloadTime )
                {
                    OnForcedReload = true;
                    if( neonDawnGun.CanReload( ) )
                    {
                        neonDawnGun.ForcedReload( );
                        OnForcedReload = false;
                        ForcedReloadTimer = 0;
                    }
                }

            }
            base.HoldItem( item, player );
        }

        public override void ModifyShootStats( Item item, Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback )
        {
            if( item.ModItem != null && item.ModItem is INeonDawnGun neonDawnGun )
            {
                if( !LastRound )
                {
                    ReloadTimer = 0;
                    ForcedReloadTimer = 0;
                    MagazineCount--;
                }
            }
            base.ModifyShootStats( item, player, ref position, ref velocity, ref type, ref damage, ref knockback );
        }

        public override void PostDrawInInventory( Item item, SpriteBatch spriteBatch, Vector2 position, Rectangle frame, Color drawColor, Color itemColor, Vector2 origin, float scale )
        {
            if( item!= null && item.ModItem != null && item.ModItem is INeonDawnGun )
            {
                Vector2 drawPos = position + frame.Size( ) * scale / 2 + new Vector2( 0, 4 );
                if( Icon == null )
                    Icon = ModContent.Request<Texture2D>( "NeonDawn/Images/ReloadIcon", AssetRequestMode.ImmediateLoad ).Value;
                int height = (int)((float)ReloadTimer / ReloadTime * 32);
                int fHeight = (int)((float)ForcedReloadTimer / ForcedReloadTime * 32);
                if( height < 32 && !OnForcedReload )
                {
                    Main.spriteBatch.Draw( Icon, drawPos, null, new Color( 255, 255, 255, 100 ), 0, Vector2.Zero, 0.5f, SpriteEffects.None, 1f );
                    Main.spriteBatch.Draw( Icon, drawPos, new Rectangle( 0, 0, 32, 32 - height ), Color.Gray, 0f, Vector2.Zero, 0.5f, SpriteEffects.None, 1f );
                }
                else if( fHeight < 32 )
                {
                    Main.spriteBatch.Draw( Icon, drawPos, null, new Color( 255, 255, 255, 100 ), 0, Vector2.Zero, 0.5f, SpriteEffects.None, 1f );
                    Main.spriteBatch.Draw( Icon, drawPos, new Rectangle( 0, 0, 32, 32 - fHeight ), Color.Gray, 0f, Vector2.Zero, 0.5f, SpriteEffects.None, 1f );
                }
            }

            base.PostDrawInInventory( item, spriteBatch, position, frame, drawColor, itemColor, origin, scale );
        }

    }
}