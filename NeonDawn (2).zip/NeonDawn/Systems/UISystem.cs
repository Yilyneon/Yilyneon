﻿using Microsoft.Xna.Framework;
using NeonDawn.Items.Weapon.Gun.G0;
using NeonDawn.Systems.NeonDawnGunSystem;
using System;
using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;
using Terraria.UI;

namespace NeonDawn.Systems
{
    internal class UISystem : ModSystem
    {
        public override void UpdateUI( GameTime gameTime )
        {
            if( NeonDawn.Instance.BookState.Visible )
                NeonDawn.Instance.Book?.Update( gameTime );

            if( NeonDawn.Instance.ExtractUIState.Visible )
                NeonDawn.Instance.ExtractUI?.Update( gameTime );
            base.UpdateUI( gameTime );
        }
        public override void ModifyInterfaceLayers( List<GameInterfaceLayer> layers )
        {
            int mouseTextIndex = layers.FindIndex( layer => layer.Name.Equals( "Vanilla: Mouse Text" ) );
            if( mouseTextIndex != -1 )
            {
                layers.Insert( mouseTextIndex, new LegacyGameInterfaceLayer(
                "Neon Dawn: Neon Dawn Gun System UI",
                delegate
                {
                    Item item = Main.LocalPlayer.HeldItem;
                    if( item != null && item.ModItem != null && item.ModItem is INeonDawnGun neonDawnGun )
                    {
                        neonDawnGun.HoldItemDraw( );
                    }
                    return true;
                },

                InterfaceScaleType.UI ) );
                layers.Insert( mouseTextIndex + 1, new LegacyGameInterfaceLayer(
                    "Neon Dawn: Gun Extract UI",
                    delegate
                    {
                        if( NeonDawn.Instance.ExtractUIState.Visible )
                        {
                            NeonDawn.Instance.ExtractUI.Draw( Main.spriteBatch, new GameTime( ) );
                        }
                        return true;
                    },
                    InterfaceScaleType.UI ) );

                layers.Insert( mouseTextIndex + 2, new LegacyGameInterfaceLayer(
                "Neon Dawn: Book UI",
                delegate
                {
                    if( NeonDawn.Instance.BookState.Visible )
                    {
                        NeonDawn.Instance.Book.Draw( Main.spriteBatch, new GameTime( ) );
                    }
                    return true;
                },
                InterfaceScaleType.UI ) );

               
            }
        }
    }
}