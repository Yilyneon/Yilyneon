﻿using System;
using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;
//UI模块与设计by幽银
//合成表配方by依琳（yilyn）
namespace NeonDawn.Systems
{
    internal class ExtractSystem
    {
        public static List<ExtractRecipe> ExtractList;
        public static void Load()
        {
            ExtractList = new List<ExtractRecipe>();
            #region 木头拆解
            //第一个数是ID，第二个数是最小，第三个数是最大，第四个数是概率。
            ExtractRecipe WoodRecipe = new ExtractRecipe("拆木头（平台");
            WoodRecipe.SetDismantled(9, 1);
            WoodRecipe.AddMaterial(94, 2, 4, 0.7f);
            WoodRecipe.AddExtractRecipe();

            ExtractRecipe WoodRecipe1 = new ExtractRecipe("拆木头（工作台");
            WoodRecipe1.SetDismantled(36, 1);
            WoodRecipe1.AddMaterial(9, 6, 12, 0.8f);
            WoodRecipe1.AddExtractRecipe();

            #endregion
            #region 墓碑
            ExtractRecipe gravestoneRecipe = new ExtractRecipe("拆墓碑（石头");
            gravestoneRecipe.SetDismantled(321, 1);
            gravestoneRecipe.AddMaterial(3, 15, 21, 1f);
            gravestoneRecipe.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe1 = new ExtractRecipe("拆墓碑（木头藤蔓");
            gravestoneRecipe1.SetDismantled(1173, 1);
            gravestoneRecipe1.AddMaterial(9, 8, 13, 1f);
            gravestoneRecipe1.AddMaterial(210, 2, 4, 0.6f);
            gravestoneRecipe1.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe2 = new ExtractRecipe("拆墓碑（木头");
            gravestoneRecipe2.SetDismantled(1174, 1);
            gravestoneRecipe2.AddMaterial(9, 6, 11, 1f);
            gravestoneRecipe2.AddMaterial(150, 3, 7, 0.8f);
            gravestoneRecipe2.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe3 = new ExtractRecipe("拆墓碑（石头十字");
            gravestoneRecipe3.SetDismantled(1175, 1);
            gravestoneRecipe3.AddMaterial(2119, 12, 17, 1f);
            gravestoneRecipe3.AddMaterial(3, 3, 7, 0.9f);
            gravestoneRecipe3.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe4 = new ExtractRecipe("拆墓碑（石头十字藤蔓");
            gravestoneRecipe4.SetDismantled(1176, 1);
            gravestoneRecipe4.AddMaterial(3, 9, 13, 1f);
            gravestoneRecipe4.AddMaterial(210, 3, 5, 0.8f);
            gravestoneRecipe4.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe5 = new ExtractRecipe("拆墓碑（方尖碑");
            gravestoneRecipe5.SetDismantled(1177, 1);
            gravestoneRecipe5.AddMaterial(173, 11, 19, 1f);
            gravestoneRecipe5.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe6 = new ExtractRecipe("拆墓碑（金墓石蠕虫三角");
            gravestoneRecipe6.SetDismantled(3230, 1);
            gravestoneRecipe6.AddMaterial(173, 4, 6, 1f);
            gravestoneRecipe6.AddMaterial(13, 4, 6, 0.8f);
            gravestoneRecipe6.AddMaterial(3653, 1, 1, 0.2f);
            gravestoneRecipe6.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe7 = new ExtractRecipe("拆墓碑（金墓石天使雕像");
            gravestoneRecipe7.SetDismantled(3231, 1);
            gravestoneRecipe7.AddMaterial(173, 5, 8, 1f);
            gravestoneRecipe7.AddMaterial(13, 3, 5, 0.8f);
            gravestoneRecipe7.AddMaterial(52, 1, 1, 0.5f);
            gravestoneRecipe7.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe8 = new ExtractRecipe("拆墓碑（金墓石十字");
            gravestoneRecipe8.SetDismantled(3229, 1);
            gravestoneRecipe8.AddMaterial(173, 2, 5, 1f);
            gravestoneRecipe8.AddMaterial(13, 7, 12, 0.8f);
            gravestoneRecipe8.AddMaterial(458, 1, 1, 0.6f);
            gravestoneRecipe8.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe9 = new ExtractRecipe("拆墓碑（金墓石十字2");
            gravestoneRecipe9.SetDismantled(3233, 1);
            gravestoneRecipe9.AddMaterial(173, 7, 11, 1f);
            gravestoneRecipe9.AddMaterial(13, 5, 9, 0.8f);
            gravestoneRecipe9.AddMaterial(554, 1, 1, 0.04f);
            gravestoneRecipe9.AddExtractRecipe();

            ExtractRecipe gravestoneRecipe10 = new ExtractRecipe("拆墓碑（金墓石斜柱");
            gravestoneRecipe10.SetDismantled(3232, 1);
            gravestoneRecipe10.AddMaterial(173, 2, 5, 1f);
            gravestoneRecipe10.AddMaterial(13, 13, 21, 0.8f);
            gravestoneRecipe10.AddMaterial(472, 1, 1, 0.6f);
            gravestoneRecipe10.AddExtractRecipe();
            #endregion
            #region 模组材料拆解
            //模组材料查询站，我猜是这样的。
            #endregion
            #region 工具拆解
            //第一个数是ID，第二个数是最小，第三个数是最大，第四个数是概率。
            ExtractRecipe ToolRecipe = new ExtractRecipe("铁镐");
            ToolRecipe.SetDismantled(1, 1);
            ToolRecipe.AddMaterial(22, 10, 14, 0.75f);
            ToolRecipe.AddMaterial(9, 1, 2, 1f);
            ToolRecipe.AddExtractRecipe();
            ExtractRecipe ToolRecipe1 = new ExtractRecipe("铁锤");
            ToolRecipe1.SetDismantled(7, 1);
            ToolRecipe1.AddMaterial(22, 8, 10, 0.75f);
            ToolRecipe1.AddMaterial(9, 2, 4, 1f);
            ToolRecipe1.AddExtractRecipe();
            #endregion
            #region 物块拆解
            //第一个数是ID，第二个数是最小，第三个数是最大，第四个数是概率。
            ExtractRecipe ItemRecipe = new ExtractRecipe("土");
            ItemRecipe.SetDismantled(2, 1);
            ItemRecipe.AddMaterial(176, 1, 2, 0.8f);
            ItemRecipe.AddExtractRecipe();
            ExtractRecipe ItemRecipe1 = new ExtractRecipe("泥");
            ItemRecipe1.SetDismantled(176, 1);
            ItemRecipe1.AddMaterial(2, 1, 0.8f);
            ItemRecipe1.AddExtractRecipe();
            ExtractRecipe ItemRecipe2 = new ExtractRecipe("石头");
            ItemRecipe2.SetDismantled(3, 1);
            ItemRecipe2.AddMaterial(129, 1, 2, 0.5f);
            ItemRecipe2.AddExtractRecipe();
            ExtractRecipe ItemRecipe3 = new ExtractRecipe("石砖");
            ItemRecipe3.SetDismantled(129, 1);
            ItemRecipe3.AddMaterial(3, 2, 3, 0.75f);
            ItemRecipe3.AddExtractRecipe();
            #endregion
            #region 近战武器拆解
            ExtractRecipe MeleeRecipe = new ExtractRecipe("铁剑");
            MeleeRecipe.SetDismantled(4, 1);
            MeleeRecipe.AddMaterial(22, 8, 10, 0.8f);
            MeleeRecipe.AddMaterial(9, 1, 2, 0.2f);
            MeleeRecipe.AddExtractRecipe();
            ExtractRecipe MeleeRecipe1 = new ExtractRecipe("铁短剑");
            MeleeRecipe1.SetDismantled(6, 1);
            MeleeRecipe1.AddMaterial(22, 7, 8, 0.8f);
            MeleeRecipe1.AddMaterial(9, 1, 0.2f);
            MeleeRecipe1.AddExtractRecipe();
            #endregion
            #region 远程武器拆解
            #endregion
            #region 魔法武器拆解
            //法师是这个MOD喜爱的职业诶，咱就别看了好吗。
            #endregion
            #region 其他武器拆解
            //杂七杂八，没准以后也会有臭鞋烂袜子之类的阿巴巴。
            #endregion
            #region 坐骑拆解
            //大多都是整活。
            #endregion
            #region 杂物
            ExtractRecipe OtherRecipe = new ExtractRecipe("蘑菇");
            OtherRecipe.SetDismantled(5, 1);
            OtherRecipe.AddMaterial(183, 1, 1f);
            OtherRecipe.AddExtractRecipe();
            #endregion
            #region 灵液与咒火转换
            //啊？为什么不能。
            #endregion
            #region 工程师
            #endregion
            #region 工具拆解（MOD
            #endregion
            #region 近战武器拆解（MOD
            #endregion
            #region 远程武器拆解（MOD
            ExtractRecipe extractRecipe3 = new ExtractRecipe("拆维纳斯");
            extractRecipe3.SetDismantled(ModContent.ItemType<Items.Weapon.ValliaRemake.VenusMagnumRemake>(), 1);
            extractRecipe3.AddMaterial(ModContent.ItemType<Items.Weapon.ValliaRemake.PhoenixBlasterRemake>(), 1);
            extractRecipe3.AddExtractRecipe();

            ExtractRecipe extractRecipe4 = new ExtractRecipe("拆凤凰冲击波");
            extractRecipe4.SetDismantled(ModContent.ItemType<Items.Weapon.ValliaRemake.PhoenixBlasterRemake>(), 1);
            extractRecipe4.AddMaterial(ModContent.ItemType<Items.Weapon.ValliaRemake.VenusMagnumRemake>(), 1);
            extractRecipe4.AddExtractRecipe();

            ExtractRecipe extractRecipe5 = new ExtractRecipe("拆维纳斯1");
            extractRecipe5.SetDismantled(ModContent.ItemType<Items.Weapon.ValliaRemake.VenusMagnumRemake>(), 1);
            extractRecipe5.AddMaterial(1, 1);
            extractRecipe5.AddExtractRecipe();
            #endregion
            #region 魔法武器拆解（MOD
            #endregion
            #region 其他武器拆解（MOD
            #endregion
            #region 模组致敬
            ExtractRecipe Fallen49Recipe = new ExtractRecipe("49落星");
            Fallen49Recipe.SetDismantled(197, 1);
            Fallen49Recipe.AddMaterial(75, 49, 49, 0.07f);
            Fallen49Recipe.AddExtractRecipe();

            ExtractRecipe GlowRecipe = new ExtractRecipe("彩虹荧光棒");
            GlowRecipe.SetDismantled(282, 10);
            GlowRecipe.AddMaterial(3002, 1, 1f);
            GlowRecipe.AddMaterial(282, 1, 1f);
            GlowRecipe.AddMaterial(286, 1, 1f);
            GlowRecipe.AddMaterial(4776, 1, 1f);
            GlowRecipe.AddMaterial(3112, 1, 1f);
            GlowRecipe.AddExtractRecipe();
            //这一部分致敬了一些优秀的MOD（不包括灾厄
            #endregion
        }
    }

    internal class ExtractRecipe
    {
        internal string Name { get; private set; }
        internal List<MaterialInfo> Materials;
        internal Item Dismantled;
        public ExtractRecipe(string name)
        {
            Name = name;
            Materials = new List<MaterialInfo>();
            Dismantled = new Item();
        }
        /// <summary>
        /// 设置被拆解物品
        /// </summary>
        /// <param name="item"></param>
        public void SetDismantled(Item item)
        {
            Dismantled = item.Clone();
        }
        /// <summary>
        /// 设置被拆解物品
        /// </summary>
        /// <param name="type"></param>
        /// <param name="stack"></param>
        public void SetDismantled(int type, int stack)
        {
            Dismantled.SetDefaults(type);
            Dismantled.stack = stack;
        }
        /// <summary>
        /// 添加拆解后得到的物品
        /// </summary>
        /// <param name="item"></param>
        public void AddMaterial(Item item, float probability = 1f)
        {
            MaterialInfo info = new MaterialInfo(item.type, probability);
            info.SetStack(item.stack);
            Materials.Add(info);
        }
        /// <summary>
        /// 添加拆解后得到的物品
        /// </summary>
        /// <param name="type"></param>
        /// <param name="stack"></param>
        public void AddMaterial(int type, int stack, float probability = 1f)
        {
            MaterialInfo info = new MaterialInfo(type, probability);
            info.SetStack(stack);
            Materials.Add(info);
        }
        /// <summary>
        /// 添加拆解后得到的物品
        /// </summary>
        /// <param name="info"></param>
        public void AddMaterial(MaterialInfo info)
        {
            Materials.Add(info);
        }
        /// <summary>
        /// 添加拆解后得到的物品
        /// </summary>
        /// <param name="type"></param>
        /// <param name="maxStack"></param>
        /// <param name="minStack"></param>
        /// <param name="probability"></param>
        public void AddMaterial(int type, int minStack, int maxStack, float probability = 1f)
        {
            MaterialInfo info = new MaterialInfo(type, probability);
            info.SetStack(minStack, maxStack);
            Materials.Add(info);
        }
        /// <summary>
        /// 将此拆解表添加到总表
        /// </summary>
        public void AddExtractRecipe()
        {
            ExtractSystem.ExtractList.Add(this);
        }
    }
    internal class MaterialInfo
    {
        public int Type, MaxStack, MinStack;
        private float _probability;
        public float Probability
        {
            get => _probability;
            internal set
            {
                if (value > 1f || value < 0f)
                    throw new Exception("请确保probability的取值在[0,1]区间内！");
                _probability = value;
            }
        }
        public MaterialInfo(int itemType, float probability)
        {
            Type = itemType;
            _probability = probability;
        }
        public void SetStack(int stack)
        {
            MinStack = MaxStack = stack;
        }
        public void SetStack(int minStack, int maxStack)
        {
            if (maxStack < minStack)
            {
                throw new Exception("请确保最小数量大于最大数量！");
            }
            MaxStack = maxStack;
            MinStack = minStack;
        }
        public Item GetItem()
        {
            if (Probability == 0f) return null;
            if (Main.rand.NextFloat() <= Probability)
            {
                Item item = new Item();
                item.SetDefaults(Type);
                item.stack = Main.rand.Next(MinStack, MaxStack);
                return item;
            }
            return null;
        }
        public MaterialInfo Clone()
        {
            MaterialInfo info = new MaterialInfo(Type, Probability);
            info.MaxStack = MaxStack;
            info.MinStack = MinStack;
            return info;
        }

    }
}
