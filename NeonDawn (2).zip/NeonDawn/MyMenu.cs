﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ReLogic.Content;

using Terraria.Localization;
using Terraria.ModLoader;

namespace NeonDawn
{
    internal class MyMenu : ModMenu
    {
        public override bool PreDrawLogo(SpriteBatch spriteBatch, ref Vector2 logoDrawCenter, ref float logoRotation, ref float logoScale, ref Color drawColor)
        {
            logoDrawCenter -= new Vector2(0, -20);
            logoScale = 1f;
            return true;
        }
        public static bool IsSelect = false;
        //主题音乐
        public override int Music => MusicLoader.GetMusicSlot("NeonDawn/Sounds/Music/Glimmers Of Vibrance");
        //主题名字
        public override string DisplayName => GameCulture.FromCultureName(GameCulture.CultureName.Chinese).IsActive ? "卡里斯托——冰层中的霓虹之城" : "Callisto——The Neon Twinkle City";
        //logo
        public override Asset<Texture2D> Logo => Mod.Assets.Request<Texture2D>("logo");
        //太阳
        public override Asset<Texture2D> SunTexture => Mod.Assets.Request<Texture2D>("NeonDawnSun");
        //月亮
        public override Asset<Texture2D> MoonTexture => Mod.Assets.Request<Texture2D>("Moon_8");
        public override void OnSelected()
        {
            IsSelect = true;
            base.OnSelected();
        }
        public override void OnDeselected()
        {
            IsSelect = false;
            base.OnDeselected();
        }
    }
}
