﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.NPCs;

using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Bosses
{
    public class MeleeMoonLaser : ModProjectile
    {
        public NPC owner
        {
            get => Main.npc[(int)Projectile.ai[0]];
            set => Main.npc[(int)Projectile.ai[0]] = value;
        }

        public float DrawWidth
        {
            get => Projectile.localAI[0];
            set => Projectile.localAI[0] = value;
        }

        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("绿激光");
        }

        public override void SetDefaults()
        {
            Projectile.timeLeft = 240;
            Projectile.width = Projectile.height = 26;
            Projectile.friendly = false;
            Projectile.hostile = true;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.alpha = 255;
        }

        public override void AI()
        {
            if (owner != null && owner.active)
            {
                if (Projectile.timeLeft > 210 || Projectile.timeLeft < 30)
                {
                    DrawWidth = MathHelper.Lerp(DrawWidth, 0.05f, .05f);
                }
                else
                {
                    DrawWidth = MathHelper.Lerp(DrawWidth, 1f, .05f);
                }
                Projectile.Center = owner.Center + (owner.rotation + MathHelper.PiOver2).ToRotationVector2() * 20f;
                Projectile.rotation = owner.rotation + MathHelper.PiOver2;
            }
            else
            {
                Projectile.Kill();
            }
            if (owner.type == ModContent.NPCType<RemoteMoon>())
            {
                if (Projectile.timeLeft == 210)
                {
                    SoundEngine.PlaySound(SoundID.Zombie104, Projectile.Center);
                }
            }
        }

        public override bool? Colliding(Rectangle projHitbox, Rectangle targetHitbox)
        {
            if (Projectile.timeLeft <= 210 && Projectile.timeLeft >= 30)
            {
                float r = 0;
                if (Collision.CheckAABBvLineCollision(targetHitbox.TopLeft(), targetHitbox.Size(), Projectile.Center, Projectile.Center + Projectile.rotation.ToRotationVector2() * 1200, 12, ref r))
                {
                    return true;
                }
            }
            return false;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            Texture2D texture = ModContent.Request<Texture2D>("NeonDawn/Projs/Bosses/MeleeMoonLaser").Value;
            const int UnitHeigh = 26;
            Rectangle rectangle;
            for (int i = 1; i < 1800; i += 20)
            {
                if (i == 1)
                {
                    rectangle = new(0, 0, 26, 26);
                }
                else if (i + 20 < 1800)
                {
                    rectangle = new(0, UnitHeigh, 26, 26);
                }
                else
                {
                    rectangle = new(0, UnitHeigh * 2, 26, 26);
                }
                spriteBatch.Draw(texture, Projectile.Center + Projectile.rotation.ToRotationVector2() * i - Main.screenPosition, rectangle, Color.White, Projectile.rotation - MathHelper.PiOver2, new Vector2(13, 0), new Vector2(DrawWidth, 1), SpriteEffects.None, 0f);
            }
            return false;
        }
    }
}