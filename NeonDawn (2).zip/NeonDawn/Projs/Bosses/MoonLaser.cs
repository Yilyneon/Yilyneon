﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Bosses
{
    public class MoonLaser : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("绿激光");
        }

        public override void SetDefaults()
        {
            Projectile.timeLeft = 150;
            Projectile.width = Projectile.height = 26;
            Projectile.friendly = false;
            Projectile.hostile = true;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.alpha = 255;
        }

        public override void AI()
        {
            foreach (var npc in Main.npc)
            {
                if (npc.type == ModContent.NPCType<NPCs.RemoteMoon>() && npc.active)
                {
                    Projectile.Center = npc.Center;
                    Player player = Main.player[npc.target];
                    if (player != null)
                    {
                        Vector2 v = player.Center - npc.Center; v /= v.Length();
                        Vector2 vector1 = Projectile.rotation.ToRotationVector2();
                        vector1 = Vector2.Lerp(vector1, v, 0.023f);
                        Projectile.rotation = vector1.ToRotation();
                    }
                }
            }
        }

        public override bool? Colliding(Rectangle projHitbox, Rectangle targetHitbox)
        {
            float r = 0;
            return Collision.CheckAABBvLineCollision(targetHitbox.TopLeft(), targetHitbox.Size(),
                Projectile.Center, Projectile.Center + Projectile.rotation.ToRotationVector2() * 1000f, 5, ref r);
        }

        public override bool PreDraw(ref Color lightColor)
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            spriteBatch.End();
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.Additive, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);
            for (int a = 0; a < 2; a++)
            {
                for (int i = 1; i < 1200; i += 20)
                {
                    Texture2D texture = TextureAssets.Projectile[Type].Value;
                    const int UnitHeigh = 26;
                    Rectangle rectangle;
                    if (i == 1)
                    {
                        rectangle = new(0, 0, 26, 26);
                    }
                    else if (i + 20 < 1200)
                    {
                        rectangle = new(0, UnitHeigh, 26, 26);
                    }
                    else
                    {
                        rectangle = new(0, UnitHeigh * 2, 26, 26);
                    }
                    spriteBatch.Draw(texture,
                        Projectile.Center + Projectile.rotation.ToRotationVector2() * i * 26 - Main.screenPosition,
                        rectangle,
                       Color.Lerp(new Color(0, 1f, 0), Color.Cyan, Main.DiscoG / 255f),
                        Projectile.rotation - MathHelper.PiOver2,
                        new Vector2(13, 0),
                        1f,
                        SpriteEffects.None,
                        0f);
                }
            }
            spriteBatch.End();
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);
            return PreDraw(ref lightColor);
        }
    }
}