﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Bosses
{
    public class Greenproj : ModProjectile
    {
        private Player Target => Main.player[(int)Projectile.ai[0]];

        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("绿色子弹");
            ProjectileID.Sets.TrailCacheLength[Type] = 10;
            ProjectileID.Sets.TrailingMode[Type] = 2;
        }

        public override void SetDefaults()
        {
            Projectile.timeLeft = 300;
            Projectile.width = 8;
            Projectile.height = 48;
            Projectile.friendly = false;
            Projectile.hostile = true;
            Projectile.penetrate = 1;
            Projectile.tileCollide = true;
        }

        public override void AI()
        {
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            Texture2D texture = TextureAssets.Projectile[Type].Value;
            for (int i = 1; i < 8; i++)
            {
                Vector2 DrawOldPos = Projectile.oldPos[i] + new Vector2(4, 24) - Main.screenPosition;
                Color color = Color.White;
                color *= 0.1f * (8 - i);
                spriteBatch.Draw(texture,
                    DrawOldPos,
                    null,
                    color,
                    Projectile.oldRot[i],
                    texture.Size() * 0.5f,
                    1f,
                    SpriteEffects.None,
                    0f);
            }
            return false;
        }
    }
}