﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Bosses
{
    public class MoonRocket : ModProjectile
    {
        private Player Target => Main.player[Projectile.owner];

        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("火箭");
            ProjectileID.Sets.TrailCacheLength[Type] = 10;
            ProjectileID.Sets.TrailingMode[Type] = 2;
        }

        public override void SetDefaults()
        {
            Projectile.timeLeft = 300;
            Projectile.width = Projectile.height = 16;
            Projectile.friendly = false;
            Projectile.hostile = true;
            Projectile.penetrate = 1;
            Projectile.tileCollide = true;
        }

        public override void AI()
        {
            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;
            if (Projectile.timeLeft > 210)
            {
                Projectile.velocity = Vector2.Normalize(Utils.SafeNormalize(Projectile.velocity, Vector2.UnitX) * 30f + Utils.SafeNormalize(Target.Center - Projectile.Center, Vector2.Zero)) * 6f;
            }
        }

        public override void Kill(int timeLeft)
        {
            Projectile projectile = Projectile.NewProjectileDirect(null, Projectile.Center, Vector2.Zero, 612, Projectile.damage, Projectile.knockBack, Main.myPlayer);
            projectile.friendly = false;
            projectile.hostile = true;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            Texture2D texture = TextureAssets.Projectile[Type].Value;
            Texture2D tex = ModContent.Request<Texture2D>("NeonDawn/Images/Trail1").Value;
            for (int i = 1; i < 8; i++)
            {
                Vector2 DrawOldPos = Projectile.oldPos[i] + new Vector2(8, 8) - Main.screenPosition;
                Color color = Color.Orange;
                color *= 0.1f * (8 - i);
                spriteBatch.Draw(tex,
                    DrawOldPos,
                    null,
                    color,
                    Projectile.oldRot[i],
                    tex.Size() * 0.5f,
                    1f - 0.125f * i,
                    SpriteEffects.None,
                    0f);
            }
            spriteBatch.Draw(texture, Projectile.Center - Main.screenPosition, null, Color.White, Projectile.rotation, texture.Size() * 0.5f, 1f, SpriteEffects.None, 0f);
            return false;
        }
    }
}