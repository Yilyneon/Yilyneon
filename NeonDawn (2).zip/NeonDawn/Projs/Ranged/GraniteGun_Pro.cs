﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ReLogic.Content;

using System;

using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Ranged
{
    public class GraniteGun_Pro : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("GraniteGun_Pro");
        }

        public override void SetDefaults()
        {
            Projectile.width = 46;
            Projectile.height = 78;
            Projectile.aiStyle = 14;
            Projectile.friendly = false;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.timeLeft = 60;
            Projectile.hide = true;
            Projectile.alpha = 255;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Vector2 drawPos = Projectile.Center;
            Texture2D texture = Mod.Assets.Request<Texture2D>("Projs/Trail").Value;
            bool flag = Main.player[base.Projectile.owner].direction == 1;
            if (flag)
            {
                Color color = Color.Lerp(new Color(100, 100, 100, 192), new Color(255, 255, 255, 192), Helper.Osc01(3f, 0f)) * 1f;
                float rotation = 0f;
                Vector2 angle = Projectile.velocity;
                rotation = angle.ToRotation();
                for (int k = 0; k < 200; k++)
                {
                    drawPos += new Vector2(texture.Height, 0).RotatedBy(angle.ToRotation());
                    int i = (int)drawPos.X / 16;
                    int j = (int)drawPos.Y / 16;
                    Main.spriteBatch.Draw(texture, drawPos - Main.screenPosition, null, color, rotation + MathHelper.ToRadians(90), new Vector2(texture.Width / 2, texture.Height / 2), Projectile.scale, SpriteEffects.None, 0f);
                    if (!WorldGen.InWorld(i, j, 20) || Main.tile[i, j].HasTile && Main.tileSolidTop[Main.tile[i, j].TileType] == false && Main.tileSolid[Main.tile[i, j].TileType] == true)
                    {
                        Texture2D lightTex = Mod.Assets.Request<Texture2D>("Projs/TrailWhite").Value;
                        Main.spriteBatch.Draw(lightTex, drawPos - Main.screenPosition, null, Color.GhostWhite, rotation + MathHelper.ToRadians(90), new Vector2(texture.Width / 2, texture.Height / 2), Projectile.scale, SpriteEffects.None, 0f);
                        break;
                    }
                }
            }
            else
            {
                float rotation = 0f;
                Vector2 angle = Projectile.velocity;
                rotation = angle.ToRotation();
                for (int k = 0; k < 200; k++)
                {
                    Color color = Color.Lerp(new Color(100, 100, 100, 192), new Color(255, 255, 255, 192), Helper.Osc01(3f, 0f)) * 1f;
                    drawPos += new Vector2(texture.Height, 0).RotatedBy(angle.ToRotation());
                    int i = (int)drawPos.X / 16;
                    int j = (int)drawPos.Y / 16;
                    Main.spriteBatch.Draw(texture, drawPos - Main.screenPosition, null, color, rotation + MathHelper.ToRadians(90), new Vector2(texture.Width / 2, texture.Height / 2), Projectile.scale, SpriteEffects.None, 0f);
                    if (!WorldGen.InWorld(i, j, 20) || Main.tile[i, j].HasTile && Main.tileSolidTop[Main.tile[i, j].TileType] == false && Main.tileSolid[Main.tile[i, j].TileType] == true)
                    {
                        Texture2D lightTex = Mod.Assets.Request<Texture2D>("Projs/TrailWhite").Value;
                        Main.spriteBatch.Draw(lightTex, drawPos - Main.screenPosition, null, Color.GhostWhite, rotation + MathHelper.ToRadians(90), new Vector2(texture.Width / 2, texture.Height / 2), Projectile.scale, SpriteEffects.None, 0f);
                        break;
                    }
                }
            }
            return true;
        }

        public override void PostDraw(Color lightColor)
        {
            Texture2D texture = (Texture2D)ModContent.Request<Texture2D>("NeonDawn/Projs/Ranged/GraniteGun_Pro_Extra");
            Vector2 drawOrigin = new Vector2(texture.Width / 2, texture.Height / 2);
            Vector2 drawPos = Projectile.Center - Main.screenPosition;
            Color color = Color.White;
            Main.spriteBatch.Draw(texture, drawPos, null, color, Projectile.rotation, drawOrigin, Projectile.scale, Projectile.direction != 1 ? SpriteEffects.FlipHorizontally : SpriteEffects.None, 0f);
        }

        private bool ended = false;

        public override bool PreAI()
        {
            Player player = Main.player[Projectile.owner];
            if (!Main.player[Projectile.owner].channel)
                ended = true;
            if (!ended)
                Projectile.timeLeft = 2;
            Vector2 vector2_1 = Main.player[Projectile.owner].RotatedRelativePoint(Main.player[Projectile.owner].MountedCenter, true);
            if (Main.myPlayer == Projectile.owner)
            {
                float num1 = 20 * Projectile.scale;
                Vector2 vector2_2 = vector2_1;
                float num2 = (float)((double)Main.mouseX + Main.screenPosition.X - vector2_2.X);
                float num3 = (float)((double)Main.mouseY + Main.screenPosition.Y - vector2_2.Y);
                if ((double)Main.player[Projectile.owner].gravDir == -1.0)
                    num3 = (float)((double)(Main.screenHeight - Main.mouseY) + Main.screenPosition.Y - vector2_2.Y);
                float num4 = (float)Math.Sqrt(num2 * (double)num2 + num3 * (double)num3);
                float num5 = (float)Math.Sqrt(num2 * (double)num2 + num3 * (double)num3);
                float num6 = num1 / num5;
                float num7 = num2 * num6;
                float num8 = num3 * num6;

                if ((double)num7 != Projectile.velocity.X || (double)num8 != Projectile.velocity.Y)
                    Projectile.netUpdate = true;
                Projectile.velocity.X = num7;
                Projectile.velocity.Y = num8;
                Projectile.velocity = Projectile.velocity.RotatedBy(Projectile.ai[0]);
            }
            if (Projectile.hide == false)
            {
                Projectile.alpha = 0;
                player.ChangeDir(Projectile.direction);
                player.heldProj = Projectile.whoAmI;
                player.itemRotation = MathHelper.WrapAngle(Projectile.rotation + MathHelper.ToRadians(Projectile.direction == -1 ? 90 : -90));
            }
            Projectile.hide = false;
            Projectile.spriteDirection = Projectile.direction;
            Projectile.position.X = (vector2_1.X - (Projectile.width / 2));
            Projectile.position.Y = (vector2_1.Y - (Projectile.height / 2));
            Projectile.rotation = (float)(Math.Atan2((double)Projectile.velocity.Y, (double)Projectile.velocity.X) + 1.57000005245209);
            return false;
        }
    }
}