﻿using Microsoft.Xna.Framework;

using System;

using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Melee
{
    public class Newknifep : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
        }

        public override void SetDefaults()
        {
            base.Projectile.light = 0.4f;
            base.Projectile.aiStyle = -1;
            base.Projectile.penetrate = -1;
            base.Projectile.timeLeft = 600;
            base.Projectile.DamageType = DamageClass.Melee;
            base.Projectile.tileCollide = false;
            base.Projectile.width = 118;
            base.Projectile.height = 62;
            base.Projectile.friendly = true;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.ownerHitCheck = true;
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 9;
            base.Projectile.hostile = false;
            Main.projFrames[base.Projectile.type] = 15;
        }

        public override bool PreAI()
        {
            Player player = Main.player[Projectile.owner];
            Vector2 vector = player.RotatedRelativePoint(player.MountedCenter, true);
            Newknifeproj ProjectileFrame = Projectile.GetGlobalProjectile<Newknifeproj>();
            ProjectileFrame.FrameSpeed = 2;
            ProjectileFrame.Timer++;
            PlayerFrame(Projectile.frame);
            PlaySound(Projectile.frame);
            if (ProjectileFrame.Timer % ProjectileFrame.FrameSpeed == 0)
            {
                ProjectileFrame.Timer = 0;
                Projectile.frame += 1;
            }
            if (Projectile.frame == 7)
            {
                player.immune = true;
                player.immuneTime = 30;
                Main.player[base.Projectile.owner].velocity = Vector2.Normalize(Main.player[base.Projectile.owner].Center - base.Projectile.Center) * -8f;
                base.Projectile.knockBack = 20f;
            }
            if (Projectile.frame > 16)
            {
                Projectile.Kill();
            }
            Projectile.position = player.MountedCenter - Projectile.Size / 2f + new Vector2(player.direction * 30, 0);
            Projectile.spriteDirection = Projectile.direction;
            Projectile.timeLeft = 2;
            player.ChangeDir(Projectile.direction);
            player.heldProj = Projectile.whoAmI;
            player.channel = true;
            player.itemTime = player.HeldItem.useTime;
            player.itemAnimation = player.HeldItem.useAnimation;
            player.itemRotation = (float)Math.Atan2((Projectile.velocity.Y * Projectile.direction), (Projectile.velocity.X * Projectile.direction));
            return false;
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            Projectile.NewProjectile(Projectile.InheritSource(base.Projectile), target.Center, new Vector2(0, 0f), ModContent.ProjectileType<HitEffect>(), 0, 0, Main.LocalPlayer.whoAmI, Main.rand.NextFloat(), 0);
        }

        public void PlayerFrame(int frame)
        {
            Player player = Main.player[Projectile.owner];
            int changeFrame = 0;
            switch (frame)
            {
                case 1:
                    changeFrame = 1;
                    break;

                case 2:
                    changeFrame = 1;
                    break;

                case 3:
                    changeFrame = 1;
                    break;

                case 4:
                    changeFrame = 1;
                    break;

                case 5:
                    changeFrame = 5;
                    break;

                case 6:
                    changeFrame = 3;
                    break;

                case 7:
                    changeFrame = 3;
                    break;

                case 8:
                    changeFrame = 3;
                    break;

                case 9:
                    changeFrame = 3;
                    break;

                case 10:
                    changeFrame = 1;
                    break;

                case 11:
                    changeFrame = 1;
                    break;

                case 12:
                    changeFrame = 1;
                    break;

                case 13:
                    changeFrame = 2;
                    break;

                case 14:
                    changeFrame = 2;
                    break;

                case 15:
                    changeFrame = 2;
                    break;
            }
            player.bodyFrame.Y = player.bodyFrame.Height * changeFrame;
        }

        public void PlaySound(int frame)
        {
            switch (frame)
            {
                case 2:
                    SoundEngine.PlaySound(SoundID.Item7, Projectile.Center);
                    break;

                case 7:
                    SoundEngine.PlaySound(SoundID.Item63, Projectile.Center);
                    break;

                case 12:
                    SoundEngine.PlaySound(SoundID.Item19, Projectile.Center);
                    break;

                case 14:
                    SoundEngine.PlaySound(SoundID.Item19, Projectile.Center);
                    break;
            }
        }

        public class Newknifeproj : GlobalProjectile
        {
            public override bool InstancePerEntity => true;

            public int Timer = 0;

            public int FrameSpeed = 0;
        }
    }
}