﻿using Microsoft.Xna.Framework;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Melee
{
    public class HitEffect : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            Main.projFrames[Projectile.type] = 3;
            base.SetStaticDefaults();
        }
        public override void SetDefaults()
        {
            Projectile.aiStyle = -1;
            Projectile.width = 82;
            Projectile.height = 82;
            Projectile.timeLeft = 600;
            Projectile.penetrate = 100;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.friendly = false;
            Projectile.hostile = false;
            Projectile.light = 0.2f;
            base.SetDefaults();
        }
        public override void AI()
        {
            Projectile.frameCounter++;
            if (Projectile.frameCounter % 2 == 0)
            {
                Projectile.frame++;
                if (Projectile.frame > 3)
                    Projectile.Kill();
            }
            Projectile.rotation = Projectile.ai[0];
            base.AI();
        }
        public override Color? GetAlpha(Color lightColor)
        {
            return new Color(lightColor.R, lightColor.G, lightColor.B, 0);
        }
    }
}