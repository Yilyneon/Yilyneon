﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Dusts;

using Terraria;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Melee
{
    public class TheGloryPro : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("TheGloryPro");
        }

        public override void SetDefaults()
        {
            base.Projectile.aiStyle = 451;
            base.Projectile.timeLeft = 320;
            base.Projectile.friendly = true;
            base.Projectile.width = (base.Projectile.height = 38);
            base.Projectile.extraUpdates = 1;
            base.Projectile.tileCollide = false;
            base.Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = 1;
            Projectile.ignoreWater = true;
            ProjectileID.Sets.TrailCacheLength[Projectile.type] = 12;
            ProjectileID.Sets.TrailingMode[Projectile.type] = 2;
        }

        public override void AI()
        {
            Lighting.AddLight((int)(Projectile.Center.X / 8f), (int)(Projectile.Center.Y / 8f), 0, 0, 0);
            base.Projectile.rotation = Utils.ToRotation(base.Projectile.velocity) + 0.7853982f;
            Projectile projectile = base.Projectile;
            projectile.velocity.Y = projectile.velocity.Y + 0.02f;
            Player player = Main.player[base.Projectile.owner];
            NPC target = null;
            float distanceMax = 900f;
            foreach (NPC npc in Main.npc)
            {
                if (npc.active && !npc.friendly && npc.type != NPCID.TargetDummy && npc.dontTakeDamage == false)
                {
                    float currentDistance = Vector2.Distance(npc.Center, Projectile.Center);
                    if (currentDistance < distanceMax)
                    {
                        distanceMax = currentDistance;
                        target = npc;
                    }
                }
            }
            if (target != null && Projectile.timeLeft < 290)
            {
                Vector2 targetVec = target.Center - Projectile.Center;
                targetVec.Normalize();
                targetVec *= 20f;
                Projectile.velocity = (Projectile.velocity * 30f + targetVec) / 31f;
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D Tail = ModContent.Request<Texture2D>("NeonDawn/Effects/Start").Value;
            Color TailColor = Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 1f;
            for (int t = 0; t < Projectile.oldPos.Length; t++)
            {
                Color color = TailColor * ((float)(Projectile.oldPos.Length - t) / (float)Projectile.oldPos.Length);
                float scale = Projectile.scale * ((float)(Projectile.oldPos.Length - t) / (float)Projectile.oldPos.Length);
                float rotation;
                float length;
                if (t + 1 >= Projectile.oldPos.Length)
                {
                    length = (Projectile.position - Projectile.oldPos[t]).Length();
                    rotation = (Projectile.position - Projectile.oldPos[t]).ToRotation() + MathHelper.PiOver2;
                }
                else
                {
                    length = (Projectile.oldPos[t + 1] - Projectile.oldPos[t]).Length();
                    rotation = (Projectile.oldPos[t + 1] - Projectile.oldPos[t]).ToRotation() + MathHelper.PiOver2;
                }
                Main.spriteBatch.Draw(Tail, Projectile.Center - Projectile.position + Projectile.oldPos[t] - Main.screenPosition, new Rectangle(0, 0, Tail.Width, Tail.Height), color * Projectile.Opacity, rotation, new Vector2(36, 36), new Vector2(scale * 0.5f, 1), SpriteEffects.None, 0f);
            }
            return true;
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            for (int i = 0; i < 1; i++)
            {
                int num = Dust.NewDust(target.position, target.width, target.height, ModContent.DustType<StarDust>(), 0f, 0f, 0, Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 1f, 0.9f);
                Main.dust[num].noGravity = true;
                Main.dust[num].position = base.Projectile.Center;
            }
        }

        public override Color? GetAlpha(Color newColor)
        {
            return new Color?(new Color(255, 255, 255, 200));
        }

        private float colorlerp;
    }
}