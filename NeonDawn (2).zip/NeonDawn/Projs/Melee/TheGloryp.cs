﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Dusts;

using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Melee
{
    public class TheGloryp : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
        }

        public override void SetDefaults()
        {
            Projectile.width = 60;
            Projectile.height = 60;
            Projectile.scale = 1f;
            Projectile.aiStyle = 19;
            Projectile.timeLeft = 90;
            Projectile.friendly = true;
            base.Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.light = 0.5f;
            Projectile.ownerHitCheck = true;
            Projectile.hide = true;
            Projectile.usesLocalNPCImmunity = true;
            Projectile.localNPCHitCooldown = 6;
        }

        public override void AI()
        {
            Lighting.AddLight((int)(Projectile.Center.X / 16f), (int)(Projectile.Center.Y / 16f), 0, 0, 0);
            Player player = Main.player[base.Projectile.owner];
            player.itemTime = player.itemAnimation;
            player.heldProj = base.Projectile.whoAmI;
            base.Projectile.direction = player.direction;
            if (!player.frozen)
            {
                if (base.Projectile.ai[0] == 0f)
                {
                    base.Projectile.ai[0] = 3f;
                    base.Projectile.netUpdate = true;
                }
                base.Projectile.ai[0] -= ((player.itemAnimation < player.itemAnimationMax / 3) ? 2.4f : -2.4f);
                base.Projectile.velocity = Utils.RotatedBy(base.Projectile.velocity, (double)base.Projectile.ai[1], default(Vector2));
            }
            if (base.Projectile.ai[1] == 0f && Main.myPlayer == player.whoAmI)
            {
                base.Projectile.ai[1] = Main.rand.NextFloatRange(0.015f);
                base.Projectile.netUpdate = true;
            }
            if (player.itemAnimation == player.itemAnimationMax - 1)
            {
                SoundEngine.PlaySound(SoundID.Item1, player.position);
                if (Main.myPlayer == player.whoAmI)
                {
                    Projectile.NewProjectileDirect(null, player.Center + base.Projectile.velocity * 12f, base.Projectile.velocity.Normalized() * 22f, ModContent.ProjectileType<TheGloryPro>(), base.Projectile.damage, 6f, base.Projectile.owner, 0f, 0f);
                    if (Main.hardMode)
                    {
                        Projectile.NewProjectileDirect(Projectile.InheritSource(base.Projectile), player.Center + base.Projectile.velocity * 12f, base.Projectile.velocity.Normalized() * 22f, ModContent.ProjectileType<TheGloryPro>(), base.Projectile.damage, 6f, base.Projectile.owner, 0f, 0f);
                        Projectile.NewProjectileDirect(Projectile.InheritSource(base.Projectile), player.Center + base.Projectile.velocity * 12f, base.Projectile.velocity.Normalized() * 22f, ModContent.ProjectileType<TheGloryPro>(), base.Projectile.damage, 6f, base.Projectile.owner, 0f, 0f);
                    }
                }
            }
            base.Projectile.Center = player.MountedCenter + base.Projectile.velocity * base.Projectile.ai[0];
            base.Projectile.rotation = Utils.ToRotation(base.Projectile.velocity) + ((base.Projectile.spriteDirection == -1) ? 0f : 1.5707964f) - 0.7853982f;
            if (player.itemAnimation == 0)
            {
                base.Projectile.Kill();
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            for (int i = 0; i < 10; i++)
            {
                int num = Dust.NewDust(target.position, target.width, target.height, DustID.GoldCoin, 0f, -2f, 0, Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 1f, 2f);
                Main.dust[num].noGravity = true;
                Main.dust[num].shader = GameShaders.Armor.GetSecondaryShader(10, Main.LocalPlayer);
                Dust dust = Main.dust[num];
                dust.position.X = dust.position.X + ((float)Main.rand.Next(-50, 51) * 0.05f - 1.5f);
                Dust dust2 = Main.dust[num];
                dust2.position.Y = dust2.position.Y + ((float)Main.rand.Next(-50, 51) * 0.05f - 1.5f);
                Main.dust[num].scale *= 0.15f;
                if (Main.dust[num].position != target.Center)
                {
                    Main.dust[num].velocity = target.DirectionTo(Main.dust[num].position) * 6f;
                }
            }
            for (int i = 0; i < 2; i++)
            {
                int num2 = Dust.NewDust(target.position, target.width, target.height, ModContent.DustType<StarDust>(), 0f, 0f, 0, Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 1f, 1f);
                Main.dust[num2].noGravity = true;
                Main.dust[num2].position = base.Projectile.Center;
            }
        }

        public override bool ShouldUpdatePosition()
        {
            return false;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D tex = TextureAssets.Projectile[base.Projectile.type].Value;
            Main.spriteBatch.Draw(tex, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, lightColor, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            Main.spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/Projs/Melee/TheGloryp").Value, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, Color.White * 0.66f, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            return false;
        }
    }
}