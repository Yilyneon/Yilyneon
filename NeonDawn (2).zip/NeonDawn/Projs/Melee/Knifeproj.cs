﻿using Microsoft.Xna.Framework;

using NeonDawn.Dustid;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Melee
{
    public class Knifeproj : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("Knifeproj");
        }

        public override void SetDefaults()
        {
            base.Projectile.width = 20;
            base.Projectile.height = 20;
            base.Projectile.aiStyle = 451;
            base.Projectile.friendly = true;
            base.Projectile.ignoreWater = true;
            base.Projectile.penetrate = 1;
            base.Projectile.DamageType = DamageClass.Melee;
            base.Projectile.usesLocalNPCImmunity = true;
            base.Projectile.localNPCHitCooldown = 100;
        }

        public override void AI()
        {
            base.Projectile.rotation = Utils.ToRotation(base.Projectile.velocity) + 0.7853982f;
            Projectile projectile = base.Projectile;
            projectile.velocity.Y = projectile.velocity.Y + 0.02f;
            base.Projectile.ai[0] += 1f;
            if (base.Projectile.ai[0] > 9f)
            {
                for (int d = 0; d < 2; d++)
                {
                    Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height,
                        MyDustId.CyanShortFx1, Projectile.velocity.X, Projectile.velocity.Y, 100, Color.White, 0.5f);
                    dust.velocity = Vector2.Zero;
                    dust.position -= base.Projectile.velocity / 5f * (float)d;
                    dust.noGravity = true;
                    dust.scale = 0.45f;
                    dust.noLight = false;
                }
            }
        }
    }
}