﻿using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Terraria.GameContent;
using Microsoft.Xna.Framework.Graphics;
using NeonDawn.Dusts;
using NeonDawn.Dustid;

namespace NeonDawn.Projs.Magic
{
    public class VIIILaserGunPro : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            ProjectileID.Sets.TrailCacheLength[base.Projectile.type] = 4;
            ProjectileID.Sets.TrailingMode[base.Projectile.type] = 0;
            //DisplayName.SetDefault("VIIILaserGunPro");
        }

        public override void SetDefaults()
        {
            base.Projectile.width = 24;
            base.Projectile.height = 24;
            base.Projectile.friendly = true;
            base.Projectile.DamageType = DamageClass.Magic;
            base.Projectile.penetrate = 1;
            base.Projectile.timeLeft = 300;
            base.Projectile.usesLocalNPCImmunity = true;
            base.Projectile.localNPCHitCooldown = 5;
            base.Projectile.ignoreWater = true;
        }

        public override void AI()
        {
            Lighting.AddLight((int)(Projectile.Center.X / 16f), (int)(Projectile.Center.Y / 16f), 0.2862f, 1f, 0.9725f);
            base.Projectile.ai[0] += 1f;
            if (base.Projectile.ai[0] > 9f)
            {
                for (int d = 0; d < 2; d++)
                {
                    Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height,
                        ModContent.DustType<EightbitDust>(), Projectile.velocity.X, Projectile.velocity.Y, 100, new Color(44, 232, 245), 0.5f);
                    dust.velocity = Vector2.Zero;
                    dust.noGravity = true;
                    dust.scale = 0.2f;
                    dust.noLight = false;
                }
            }
            base.Projectile.rotation = (float)Math.Atan2((double)base.Projectile.velocity.Y, (double)base.Projectile.velocity.X) + 1.5707964f;
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D tex = TextureAssets.Projectile[base.Projectile.type].Value;
            Main.spriteBatch.Draw(tex, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, lightColor, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            Main.spriteBatch.Draw(tex, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, Color.White * 0.66f, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            return false;
        }

        public override void Kill(int timeLeft)
        {
            for (int i = 0; i < 35; i++)
            {
                Vector2 position = base.Projectile.Center;
                Dust dust = Dust.NewDustDirect(Projectile.position, Projectile.width, Projectile.height,
                226, Projectile.velocity.X, Projectile.velocity.Y, 100, new Color(44, 232, 245), 0.75f);
                dust.noGravity = true;
                dust.fadeIn = 0.42632f;
            }
        }
    }
}