﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.Audio;
using Microsoft.Xna.Framework;
using NeonDawn.Items.Food;
using Microsoft.Xna.Framework.Graphics;
using Terraria.GameContent;

namespace NeonDawn.Projs.Food
{
    public class MooncakeYoyoProj : ModProjectile
    {
        public override void SetDefaults()
        {
            ProjectileID.Sets.YoyosLifeTimeMultiplier[Projectile.type] = 12f;
            ProjectileID.Sets.YoyosMaximumRange[Projectile.type] = 200f;
            ProjectileID.Sets.YoyosTopSpeed[Projectile.type] = 16f;
            Projectile.width = 18;
            Projectile.height = 18;
            Projectile.aiStyle = 99;
            Projectile.friendly = true;
            Projectile.penetrate = -1;
            Projectile.DamageType = DamageClass.Melee;
        }

        public override void AI()
        {
            if (base.Projectile.frameCounter >= 15)
            {
                base.Projectile.Kill();
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            base.Projectile.frameCounter++;
            for (int split = 0; split < 3; split++)
            {
                float shardspeedX = -base.Projectile.velocity.X * Utils.NextFloat(Main.rand, 0.5f, 0.7f) + Utils.NextFloat(Main.rand, -3f, 3f);
                float shardspeedY = -base.Projectile.velocity.Y * (float)Main.rand.Next(50, 70) * 0.01f + (float)Main.rand.Next(-8, 9) * 0.2f;
                if (shardspeedX < 2f && shardspeedX > -2f)
                {
                    shardspeedX += -base.Projectile.velocity.X;
                }
                if (shardspeedY > 2f && shardspeedY < 2f)
                {
                    shardspeedY += -base.Projectile.velocity.Y;
                }
                float shardspeedX2 = -base.Projectile.velocity.X * Utils.NextFloat(Main.rand, 0.4f, 0.8f) + Utils.NextFloat(Main.rand, -4f, 4f);
                float shardspeedY2 = -base.Projectile.velocity.Y * (float)Main.rand.Next(40, 60) * 0.01f + (float)Main.rand.Next(-7, 8) * 0.2f;
                if (shardspeedX2 < 2.5f && shardspeedX2 > -2.5f)
                {
                    shardspeedX2 += -base.Projectile.velocity.X;
                }
                if (shardspeedY2 > 2.5f && shardspeedY2 < 2.5f)
                {
                    shardspeedY2 += -base.Projectile.velocity.Y;
                }
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), (int)base.Projectile.position.X + shardspeedX, base.Projectile.position.Y + shardspeedY, shardspeedX, shardspeedY, ModContent.ProjectileType<ScrapSmall>(), (int)((double)base.Projectile.damage * 0.5), base.Projectile.knockBack, base.Projectile.owner, (float)Main.rand.Next(2), 0f);
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), (int)base.Projectile.position.X + shardspeedX2, base.Projectile.position.Y + shardspeedY2, shardspeedX2, shardspeedY2, ModContent.ProjectileType<ScrapMedium>(), (int)((double)base.Projectile.damage * 0.3), base.Projectile.knockBack, base.Projectile.owner, (float)Main.rand.Next(2), 0f);
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D tex = TextureAssets.Projectile[base.Projectile.type].Value;
            Main.spriteBatch.Draw(tex, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, lightColor, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            Main.spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/Projs/Food/MooncakeYoyoProj").Value, base.Projectile.Center - base.Projectile.velocity.Normalized() * 2f - Main.screenPosition, null, Color.White * 0.66f, base.Projectile.rotation, Utils.Size(tex) / 2f, base.Projectile.scale, 0, 0f);
            return false;
        }

        public override void Kill(int timeLeft)
        {
            if (base.Projectile.frameCounter >= 15)
            {
                Player player = Main.player[base.Projectile.owner];
                for (int j = 0; j < 5; j++)
                {
                    int type = 0;
                    switch (Main.rand.Next(3))
                    {
                        case 0:
                            type = ModContent.ItemType<Fiveren>();
                            break;

                        case 1:
                            type = ModContent.ItemType<Yolk>();
                            break;

                        case 2:
                            type = ModContent.ItemType<BeanSand>();
                            break;
                    }
                    int item = Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, type, 1, false, 0, false, false);
                    Main.item[item].velocity = Utils.RotatedBy(Vector2.UnitY, (double)(3.14f + Utils.NextFloat(Main.rand, 3.14f)), default(Vector2)) * 8f * (float)player.direction;
                }
                SoundEngine.PlaySound(SoundID.Item2, Projectile.Center);
            }
        }
    }
}