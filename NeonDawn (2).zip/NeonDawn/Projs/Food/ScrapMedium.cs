﻿using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Projs.Food
{
    public class ScrapMedium : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("scrap2");
        }

        public override void SetDefaults()
        {
            Projectile.width = 14;
            Projectile.height = 14;
            Projectile.aiStyle = 113;
            Projectile.friendly = true;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 600;
            Projectile.alpha = 50;
        }

        public override void AI()
        {
            base.Projectile.rotation += 0.6f * (float)base.Projectile.direction;
            base.Projectile.velocity.Y = base.Projectile.velocity.Y + 0.27f;
            if (base.Projectile.velocity.Y > 16f)
            {
                base.Projectile.velocity.Y = 16f;
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            if (target.defense > 0)
                target.defense = 0;
            target.immune[Projectile.owner] = 2;
        }
    }
}