﻿using System;

using Microsoft.Xna.Framework;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Projs.NoSort
{
    public class CapsuleExplosion : ModProjectile
    {
        public override void SetDefaults()
        {
            base.Projectile.width = 400;
            base.Projectile.height = 400;
            base.Projectile.friendly = true;
            base.Projectile.ignoreWater = true;
            base.Projectile.tileCollide = false;
            base.Projectile.penetrate = -1;
            base.Projectile.timeLeft = 5;
            base.Projectile.usesLocalNPCImmunity = true;
            base.Projectile.localNPCHitCooldown = 1;
        }

        // Token: 0x0600284B RID: 10315 RVA: 0x0015F0E8 File Offset: 0x0015D2E8
        public override void AI()
        {
            Lighting.AddLight(base.Projectile.Center, (float)(255 - base.Projectile.alpha) * 0.05f / 255f, (float)(255 - base.Projectile.alpha) * 0.5f / 255f, (float)(255 - base.Projectile.alpha) * 1f / 255f);
            if (base.Projectile.localAI[0] == 0f)
            {
                base.Projectile.localAI[0] += 1f;
            }
            bool flag15 = false;
            bool flag16 = false;
            if (base.Projectile.velocity.X < 0f && base.Projectile.position.X < base.Projectile.ai[0])
            {
                flag15 = true;
            }
            if (base.Projectile.velocity.X > 0f && base.Projectile.position.X > base.Projectile.ai[0])
            {
                flag15 = true;
            }
            if (base.Projectile.velocity.Y < 0f && base.Projectile.position.Y < base.Projectile.ai[1])
            {
                flag16 = true;
            }
            if (base.Projectile.velocity.Y > 0f && base.Projectile.position.Y > base.Projectile.ai[1])
            {
                flag16 = true;
            }
            if (flag15 && flag16)
            {
                base.Projectile.Kill();
            }
            float num461 = 25f;
            if (base.Projectile.ai[0] > 180f)
            {
                num461 -= (base.Projectile.ai[0] - 180f) / 2f;
            }
            if (num461 <= 0f)
            {
                num461 = 0f;
                base.Projectile.Kill();
            }
            num461 *= 0.7f;
            base.Projectile.ai[0] += 4f;
            int num462 = 0;
            while ((float)num462 < num461)
            {
                float num463 = (float)Main.rand.Next(-40, 41);
                float num464 = (float)Main.rand.Next(-40, 41);
                float num467 = (float)Main.rand.Next(12, 36);
                float num465 = (float)Math.Sqrt((double)(num463 * num463 + num464 * num464));
                num465 = num467 / num465;
                num463 *= num465;
                num464 *= num465;
                Dust dust = Main.dust[Dust.NewDust(base.Projectile.position, base.Projectile.width, base.Projectile.height, 226, base.Projectile.velocity.X, base.Projectile.velocity.Y, 100, Color.White, 1f)];
                dust.noGravity = true;
                dust.position.X = base.Projectile.Center.X;
                dust.position.Y = base.Projectile.Center.Y;
                dust.position.X = dust.position.X + (float)Main.rand.Next(-10, 11);
                dust.position.Y = dust.position.Y + (float)Main.rand.Next(-10, 11);
                dust.velocity.X = num463;
                dust.velocity.Y = num464;
                num462++;
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            base.OnHitNPC(target, hit, damageDone);
            target.AddBuff(31, 60, false);
        }

        public override void OnHitPlayer(Player target, Player.HurtInfo info)
        {
            base.OnHitPlayer(target, info);
            if (info.PvP)
                target.AddBuff(31, 60, true);
        }
    }
}