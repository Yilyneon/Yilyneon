﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Items.Bags;
using NeonDawn.Items.Materials;
using NeonDawn.Items.Weapon.Ranged;

using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace NeonDawn.Projs.NoSort
{
    public class BookSetting : ModPlayer
    {
        public override bool IsCloneable => true;

        public bool UseBookButton = false;

        public bool First = false;

        public override void LoadData(TagCompound tag)
        {
            UseBookButton = tag.GetBool("UseBookButton");
            First = tag.GetBool("First");

            base.LoadData(tag);
        }

        public override void SaveData(TagCompound tag)
        {
            tag.Add("UseBookButton", UseBookButton);
            tag.Add("First", First);
            base.SaveData(tag);
        }
    }

    public class SpaceCapsule : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("SpaceCapsule");
        }

        public override void SetDefaults()
        {
            Projectile.width = 160;
            Projectile.height = 224;
            base.Projectile.ignoreWater = true;
            base.Projectile.tileCollide = false;
            base.Projectile.timeLeft = 24000;
            Projectile.frame = 0;
            Main.projFrames[base.Projectile.type] = 12;
            base.Projectile.extraUpdates = 1;
        }

        public override void AI()
        {
            {
                Lighting.AddLight(Projectile.Center, 0.9f, 0.8f, 0.6f);
                Projectile.frameCounter++;
                if (Projectile.frameCounter % 1 == 0)
                {
                    Projectile.frame++;
                    Projectile.frameCounter = 0;
                }
                if (base.Projectile.frame >= 12)
                {
                    Projectile.frame = 0;
                    base.Projectile.localAI[0] += 1f;
                }
                if (base.Projectile.localAI[0] >= 12f)
                {
                    Projectile.frame = 0;
                    base.Projectile.localAI[0] = 0f;
                    base.Projectile.localAI[1] += 1f;
                }
                if (base.Projectile.localAI[1] >= 6f)
                {
                    Projectile.Kill();
                }
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D sprite = ModContent.Request<Texture2D>(this.Texture, (ReLogic.Content.AssetRequestMode)2).Value;
            Color drawColour = Color.White;
            Rectangle sourceRect = new Rectangle((int)Projectile.width * (int)Projectile.localAI[1], (int)Projectile.height * (int)base.Projectile.localAI[0], base.Projectile.width, base.Projectile.height); ;
            Vector2 origin = new Vector2((float)(base.Projectile.width / 2), (float)(base.Projectile.height / 2));
            float opacity = 1f;
            int sparkCount = 0;
            for (int i = 0; i < sparkCount * 2; i++)
            {
                int dustType = 132;
                if (Utils.NextBool(Main.rand))
                {
                    dustType = 264;
                }
                float rangeDiff = 2f;
                Vector2 dustPos = new Vector2(Utils.NextFloat(Main.rand, -1f, 1f), Utils.NextFloat(Main.rand, -1f, 1f));
                dustPos.Normalize();
                dustPos *= 98f + Utils.NextFloat(Main.rand, -rangeDiff, rangeDiff);
                int dust = Dust.NewDust(base.Projectile.Center + dustPos, 1, 1, dustType, 0f, 0f, 0, default(Color), 0.75f);
                Main.dust[dust].noGravity = true;
            }
            Main.EntitySpriteDraw(sprite, base.Projectile.Center - Main.screenPosition, new Rectangle?(sourceRect), drawColour * opacity, base.Projectile.rotation, origin, 1f, 0, 0);
            return false;
        }

        public override void Kill(int timeLeft)
        {
            for (int i = 0; i < 20; i++)
            {
                Gore.NewGore(Projectile.GetSource_FromAI(), new Vector2(base.Projectile.position.X, base.Projectile.position.Y), default(Vector2), Main.rand.Next(220, 223), 1f);
            }

            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 2, false, 0, false, false);
            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 5, false, 0, false, false);
            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 9, false, 0, false, false);
            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 8, false, 0, false, false);
            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 10, false, 0, false, false);
            Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<EnterVoucher>(), 1, false, 0, false, false);

            Player player = Main.player[Projectile.owner];
            SoundEngine.PlaySound(SoundID.Item89, player.position);
            if (Utils.NextBool(Main.rand, 2))
            {
                Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<Scrap>(), 10, false, 0, false, false);
            }
            if (Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton)
            {
                Item.NewItem(Projectile.GetSource_DropAsItem(), (int)base.Projectile.position.X, (int)base.Projectile.position.Y, base.Projectile.width, base.Projectile.height, ModContent.ItemType<GraniteGun>(), 1, false, 0, false, false);
            }

            if (base.Projectile.owner == Main.myPlayer)
            {
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), base.Projectile.Center.X, base.Projectile.Center.Y, 0f, 0f, ModContent.ProjectileType<CapsuleExplosion>(), base.Projectile.damage, base.Projectile.knockBack, base.Projectile.owner, 0f, 1f);
            }
        }

        // Token: 0x04000472 RID: 1138
        private const int framesX = 3;

        // Token: 0x04000473 RID: 1139
        private const int framesY = 6;
    }
}