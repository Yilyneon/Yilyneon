﻿using Microsoft.Xna.Framework;

using Terraria;
using Terraria.Audio;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Projs.NoSort
{
    public class Startproj : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            Main.projFrames[base.Projectile.type] = 4;
            //DisplayName.SetDefault("Startproj");
        }

        public override void SetDefaults()
        {
            Projectile.width = 160;
            Projectile.height = 224;
            Projectile.aiStyle = 113;
            Projectile.friendly = true;
            Projectile.penetrate = 1;
            Projectile.timeLeft = 600;
            Projectile.alpha = 50;
            Projectile.frame = 0;
            Main.projFrames[Projectile.type] = 4;
            Projectile.tileCollide = true;
        }

        public override void AI()
        {
            {
                Lighting.AddLight(Projectile.Center, 0.9f, 0.8f, 0.6f);
                if (Projectile.frameCounter % 4 == 0)
                {
                    Projectile.frame++;
                    Projectile.frameCounter = 0;
                }
                if (Projectile.frame % 4 == 0)
                    Projectile.frame = 0;
                Projectile.frameCounter++;
            }
            int num = 5;
            for (int i = 0; i < 30; i++)
            {
                int index2 = Dust.NewDust(Projectile.position, 1, 1, 226, 0f, 0f, 0, default(Color), 1f);
                Main.dust[index2].position = Projectile.Center - Projectile.velocity / (float)num * (float)i;
                Main.dust[index2].scale = 0.5f;
                Main.dust[index2].velocity *= 0f;
                Main.dust[index2].noGravity = true;
                Main.dust[index2].noLight = false;
            }
        }

        public override bool OnTileCollide(Vector2 oldVelocity)
        {
            Player player = Main.player[Projectile.owner];
            SoundEngine.PlaySound(SoundID.Item89, player.position);
            for (int i = 0; i < 20; i++)
            {
                Gore.NewGore(Projectile.GetSource_FromAI(), new Vector2(Projectile.Center.X, Projectile.Center.Y), default(Vector2), Main.rand.Next(220, 223), 1f);
            }
            int num226 = 36;
            for (int num227 = 0; num227 < num226; num227++)
            {
                Vector2 value = Utils.RotatedBy(Vector2.Normalize(Projectile.velocity) * new Vector2((float)Projectile.width / 2f, (float)Projectile.height) * 1f, (double)((float)(num227 - (num226 / 2 - 1)) * 6.2831855f / (float)num226), default(Vector2)) + Projectile.Center;
                Vector2 vector7 = value - Projectile.Center;
                int num228 = Dust.NewDust(value + vector7, 0, 0, 226, vector7.X, vector7.Y, 100, Color.White, 1.2f);
                Main.dust[num228].noGravity = true;
                Main.dust[num228].noLight = true;
                Main.dust[num228].velocity = vector7;
            }
            if (Projectile.velocity.X != oldVelocity.X)
            {
                Projectile.velocity.X = oldVelocity.X;
            }
            if (Projectile.velocity.Y != oldVelocity.Y)
            {
                Projectile.velocity.Y = oldVelocity.Y + 10f;
            }
            int num = 1;
            if (Projectile.owner == Main.myPlayer && num == 1)
            {
                Projectile.NewProjectile(Projectile.GetSource_FromThis(), Projectile.Center.X, Projectile.Center.Y + 18f, 0f, 0f, ModContent.ProjectileType<SpaceCapsule>(), Projectile.damage, Projectile.knockBack, Projectile.owner, 0f, 1f);

                num = 0;
            }
            for (int i = 0; i < 5; i++)
            {
                Dust.NewDust(Projectile.position + Projectile.velocity, Projectile.width, Projectile.height, 173, Projectile.velocity.X * 0.5f, Projectile.velocity.Y * 0.5f, 0, default(Color), 1f);
            }
            return true;
        }
    }
}