﻿using Microsoft.Xna.Framework;
using System.ComponentModel;
using Terraria;
using Terraria.ModLoader.Config;

namespace NeonDawn
{
    [Label("NeonConfig")]
    [BackgroundColor(95, 205, 228, 200)]

    public class NeonConfig : ModConfig
    {

        public override ConfigScope Mode => ConfigScope.ClientSide;
        [Label("盔甲眼部特效")]
        [BackgroundColor(202, 218, 250, 200)]
        [Tooltip("用于控制某些眼部特效的开关")]
        [DefaultValue(true)]
        public bool eyeseffectOpen;
    }
}
