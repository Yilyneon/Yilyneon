﻿using NeonDawn.NPCs;

using Terraria;
using Terraria.ModLoader;

using Filters = Terraria.Graphics.Effects.Filters;

namespace NeonDawn.Common.Systems
{
    public class FiltersSystem : ModSystem
    {
        public override void PreUpdateEntities()
        {
            if (!NPC.AnyNPCs(ModContent.NPCType<MeleeMoon>()))
            {
                if (Filters.Scene["GreenShader"].IsActive())
                {
                    Filters.Scene.Deactivate("GreenShader");
                }
                if (Filters.Scene["RedShader"].IsActive())
                {
                    Filters.Scene.Deactivate("RedShader");
                }
            }//if the melee moon is cleared by some reason(such as using Heros' tool) and has not deactivate the screenshader, use this to deactivate it
            if (!NPC.AnyNPCs(ModContent.NPCType<SatelliteSmall>()))
            {
                if (Filters.Scene["GradualGreenShader"].IsActive())
                {
                    Filters.Scene.Deactivate("GradualGreenShader");
                }
            }
        }
    }
}
