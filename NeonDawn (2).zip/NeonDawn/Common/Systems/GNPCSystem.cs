﻿using Microsoft.Xna.Framework;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Common.Systems
{
    public class GNPCSystem : ModSystem
    {
        public static void SpawnGore(NPC npc, int amount = 1, int type = -1)
        {
            var mod = npc.ModNPC.Mod;
            var position = npc.Center;
            for (int i = 0; i < amount; i++)
            {
                Gore.NewGore(npc.GetSource_FromAI(), position + new Vector2(Main.rand.Next(-20, 20), Main.rand.Next(-20, 20)), Vector2.Zero, type);
            }
        }
    }
}
