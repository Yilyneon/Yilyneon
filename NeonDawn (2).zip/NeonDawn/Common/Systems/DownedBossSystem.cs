﻿using System.IO;

using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace NeonDawn.Common.Systems
{
    public class DownedBossSystem : ModSystem //this is required for checking the boss downed progress
    {
        public static bool downedSatellite1;
        public static bool downedEnragedSatellite;
        public static bool downedSatellite2;
        public static string SatelliteName1;
        public static string SatelliteName2;
        public override void OnWorldLoad()
        {
            downedSatellite1 = false;
            downedSatellite2 = false;
            downedEnragedSatellite = false;
            SatelliteName1 = Language.ActiveCulture.Name == "zh-Hans" ? "失落卫星A" : "Lost Satellite A";
            SatelliteName2 = Language.ActiveCulture.Name == "zh-Hans" ? "失落卫星B" : "Lost Satellite B";
        }
        public override void OnWorldUnload()
        {
            downedSatellite1 = false;
            downedSatellite2 = false;
            downedEnragedSatellite = false;
        }
        public override void SaveWorldData(TagCompound tag)
        {
            if (downedSatellite1)
            {
                tag["downedSatellite1"] = true;
            }
            if (downedSatellite2)
            {
                tag["downedSatellite2"] = true;
            }
            if (downedEnragedSatellite)
            {
                tag["downedEnragedSatellite"] = true;
            }
        }
        public override void LoadWorldData(TagCompound tag)
        {
            downedSatellite1 = tag.ContainsKey("downedSatellite1");
            downedSatellite2 = tag.ContainsKey("downedSatellite2");
            downedEnragedSatellite = tag.ContainsKey("downedEnragedSatellite");
        }
        public override void NetSend(BinaryWriter writer)
        {
            BitsByte flags = default(BitsByte);
            flags[0] = downedSatellite1;
            flags[1] = downedSatellite2;
            flags[2] = downedEnragedSatellite;
            writer.Write(flags);
        }
        public override void NetReceive(BinaryReader reader)
        {
            BitsByte flags = reader.ReadByte();
            downedSatellite1 = flags[0];
            downedSatellite2 = flags[1];
            downedEnragedSatellite = flags[2];
        }
    }
}
