﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent.ObjectInteractions;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ObjectData;

namespace NeonDawn.Tiles
{
    internal class ExtractTable : ModTile
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();
            Main.tileFrameImportant[Type] = true;
            Main.tileObsidianKill[Type] = true;
            Main.tileLighted[Type] = true;

            TileID.Sets.NotReallySolid[Type] = true;
            TileID.Sets.DrawsWalls[Type] = true;
            TileID.Sets.HasOutlines[Type] = true;
            TileID.Sets.DisableSmartCursor[Type] = true;

            TileObjectData.newTile.CopyFrom(TileObjectData.StyleSmallCage);
            TileObjectData.newTile.Width = 4;
            TileObjectData.newTile.Height = 3;
            TileObjectData.newTile.CoordinatePadding = 2;
            TileObjectData.newTile.CoordinateHeights = new[] { 16, 16, 16 };
            TileObjectData.newTile.Origin = new Point16(0, 0);
            TileObjectData.newTile.AnchorTop = AnchorData.Empty;
            TileObjectData.newTile.LavaDeath = false;
            TileObjectData.addTile(Type);
            //ModTranslation name = CreateMapEntryName();
            //name.SetDefault("拆解台");
            //AddMapEntry(new Color(144, 148, 144), name);
            DustType = 11;
            AnimationFrameHeight = 54;
            //TextureAssets.HighlightMask[Type] = ModContent.Request<Texture2D>("NeonDawn/Tiles/ExtractTable_Outline", ReLogic.Content.AssetRequestMode.ImmediateLoad);
        }

        public override bool HasSmartInteract(int i, int j, SmartInteractScanSettings settings) => true;

        public override bool AutoSelect(int i, int j, Item item) => true;

        public override void KillMultiTile(int i, int j, int frameX, int frameY)
        {
            Item.NewItem(null, i * 16, j * 16, 32, 48, ModContent.ItemType<Items.Placeable.ExtractTableItem>());
        }

        public override void AnimateTile(ref int frame, ref int frameCounter)
        {
            base.AnimateTile(ref frame, ref frameCounter);
            //frame = 1;
            frameCounter++;
            if (frameCounter % 10 == 0)
            {
                frame++;
                frameCounter = 0;
            }
            if (frame == 6)
            {
                frame = 0;
            }
        }

        public override void NearbyEffects(int i, int j, bool closer)
        {
            if (NeonDawn.Instance.ExtractUIState.Visible && Vector2.Distance(new Vector2(i, j) * 16f, Main.LocalPlayer.Center) > 160)
            {
                NeonDawn.Instance.ExtractUIState.Visible = false;
            }
            base.NearbyEffects(i, j, closer);
        }

        public override void PostDraw(int i, int j, SpriteBatch spriteBatch)
        {
            base.PostDraw(i, j, spriteBatch);
            Tile tile = Main.tile[i, j];
            Vector2 zero = new Vector2(Main.offScreenRange, Main.offScreenRange);
            if (Main.drawToScreen)
            {
                zero = Vector2.Zero;
            }
            int animate = 0;
            if (tile.TileFrameY >= 54)
            {
                animate = Main.tileFrame[Type] * AnimationFrameHeight;
            }
            Main.spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/Tiles/ExtractTable_Glow", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, new Vector2(i * 16 - (int)Main.screenPosition.X, j * 16 - (int)Main.screenPosition.Y) + zero, new Rectangle(tile.TileFrameX, tile.TileFrameY + animate, 16, 16), Color.White, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
        }

        public override void ModifyLight(int i, int j, ref float r, ref float g, ref float b)
        {
            r = 0.2862f;
            g = 1f;
            b = 0.9725f;
            base.ModifyLight(i, j, ref r, ref g, ref b);
        }

        public override bool RightClick(int i, int j)
        {
            NeonDawn.Instance.ExtractUIState.Visible = !NeonDawn.Instance.ExtractUIState.Visible;
            Main.playerInventory = true;
            SoundEngine.PlaySound(SoundID.Item10);
            return true;
        }

        public override void MouseOver(int i, int j)
        {
            Player player = Main.LocalPlayer;

            player.noThrow = 2;
            player.cursorItemIconEnabled = true;
            player.cursorItemIconID = ModContent.ItemType<Items.Placeable.ExtractTableItem>();
        }
    }
}