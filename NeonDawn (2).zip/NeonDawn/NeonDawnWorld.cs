using Terraria.ModLoader;

namespace NeonDawn
{
    public class NeonDawnWorld : ModSystem
    {
        public override void PostUpdateTime()
        {
            NeonDawnWorld.Time += 1f;
            if (NeonDawnWorld.Time > 10000f)
            {
                NeonDawnWorld.Time = 0f;
            }
            base.PostUpdateTime();
        }
        internal static float Time;
    }
}

