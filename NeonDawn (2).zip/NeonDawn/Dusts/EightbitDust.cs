using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;
using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Dusts
{
	public class EightbitDust : ModDust
	{
		public override string Texture
		{
			get
			{
				return "NeonDawn/Effects/Eightbit";
			}
		}

		public override void OnSpawn(Dust dust)
		{
			dust.alpha = 100;
			dust.velocity *= 1.5f;
			dust.noLight = true;
			dust.scale = 0.1f;
			Color color = dust.color;
			color.A = 0;
			dust.color = color;
		}
		public override bool Update(Dust dust)
		{
			float light = 0.5f * MathHelper.Clamp(dust.scale, 0f, 1f);
			Vector3 vec = Color.Lerp(Color.White, dust.color, 1f).ToVector3();
			Lighting.AddLight(dust.position, vec * light);
			if (!dust.noGravity)
			{
				dust.position += dust.velocity;
				dust.velocity.X = dust.velocity.X * 0.5f;
				dust.velocity.Y = dust.velocity.Y - 0.05f;
				dust.scale -= 0.033333335f;
				dust.velocity *= 0.97f;
				if (dust.scale < 0.01f)
				{
					dust.active = false;
				}
			}
			else
			{
				dust.position += dust.velocity;
				dust.scale -= 0.05f;
				dust.velocity.Y = dust.velocity.Y - 0.010f;
				dust.velocity *= 0.97f;
				if (dust.scale < 0.01f)
				{
					dust.active = false;
				}
			}
			return false;
		}
		public override Color? GetAlpha(Dust dust, Color lightColor)
		{
			Texture2D texture = ModContent.Request<Texture2D>("NeonDawn/Effects/Eightbit").Value;
			Rectangle rectangle = new Rectangle(0, 0, texture.Width, texture.Height); ;
			Color color = Color.Lerp(Color.White, dust.color, 0.75f);
			color *= 0.5f;
			int y = 10;
			for (int i = 0; i < y; i++)
			{
				float Scale = dust.scale * (1f + 4f / (float)y * (float)i);
				color *= 1f - (float)i / (float)y;
				color.A = 0;
				Vector2 vector = dust.position - Main.screenPosition;
				Main.spriteBatch.Draw(texture, vector, new Rectangle?(rectangle), color, dust.rotation, Utils.Size(rectangle) / 2f, Scale, 0, 0f);
			}
			return new Color?(color);
		}
	}
}