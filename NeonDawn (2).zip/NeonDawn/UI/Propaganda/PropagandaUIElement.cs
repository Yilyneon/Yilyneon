﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Terraria.ModLoader;
using Terraria.UI;

namespace NeonDawn.UI.Propaganda
{
    public class PropagandaUIElement : UIElement
    {
        public override void Draw(SpriteBatch spriteBatch)
        {
            CalculatedStyle dimensions = GetDimensions();
            Rectangle position = new Rectangle((int)dimensions.X, (int)dimensions.Y, (int)dimensions.Width, (int)dimensions.Height);
            spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/UI/Propaganda/PropagandaUIElement").Value, position, Color.White);
            base.Draw(spriteBatch);
        }
    }
}
