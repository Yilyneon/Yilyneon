﻿using Microsoft.Xna.Framework;

using ReLogic.Graphics;

using Terraria.UI;

namespace NeonDawn.UI.Propaganda
{
    public class PropagandaUIState : UIState
    {
        public PropagandaUIElement MainPanel;

        public override void OnInitialize()
        {
            MainPanel = new PropagandaUIElement();
            MainPanel.Width.Set(300, 0);
            MainPanel.Height.Set(750, 0);
            MainPanel.Left.Set(0, 0);
            MainPanel.Top.Set(-375, 0.5f);
            Append(MainPanel);

            float x, y;
            MyUIText text = new MyUIText("  感谢你加载NeonDawn！", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            y = text.Height.Pixels;
            text.Left.Set(-text.Width.Pixels / 2f, 0.5f);
            text.Top.Set(20, 0);
            MainPanel.Append(text);

            text = new MyUIText("  NeonDawn玩家群：", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 20, 0);
            MainPanel.Append(text);

            text = new MyUIText("  930317611", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.Yellow, Color.Black);
            text.Left.Set(x + 10, 0);
            text.Top.Set(y + 20, 0);
            text.OnLeftClick += Text_OnClick;
            text.OnMouseOver += Text_OnMouseOver;
            text.OnMouseOut += Text_OnMouseOut;
            MainPanel.Append(text);

            text = new MyUIText("  点击群号可直接发送申请", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 45, 0);
            MainPanel.Append(text);

            text = new MyUIText("  感谢你加载霓虹MOD（NeonDawn)", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 75, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  10月31日更新：", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(15, 0);
            text.Top.Set(y + 105, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  增加一把大剑武器。", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(15, 0);
            text.Top.Set(y + 135, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  增加一个额外剧情收藏品。", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(15, 0);
            text.Top.Set(y + 165, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  南瓜盔甲重制。", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(15, 0);
            text.Top.Set(y + 195, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  版本号：0.0.0.9", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 445, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  Mod作者：yilyn", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 475, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  公告框作者：幽银", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 505, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("  本mod仅在玩家群", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 535, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("永恒意志1,2群", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 565, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("中二的释梦菌粉丝群发布", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 595, 0);
            MainPanel.Append(text);
            base.OnInitialize();

            text = new MyUIText("如有发现盗传现象，请与作者联系", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.White);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 625, 0);
            MainPanel.Append(text);
            base.OnInitialize();
            text = new MyUIText("点击这里与作者获取联系", NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, Color.Yellow, Color.Black);
            x = text.Width.Pixels;
            text.Left.Set(10, 0);
            text.Top.Set(y + 655, 0);
            text.OnLeftClick += Text_OnClickZ;
            text.OnMouseOver += Text_OnMouseOver;
            text.OnMouseOut += Text_OnMouseOut;
            MainPanel.Append(text);
        }

        private void Text_OnMouseOver(UIMouseEvent evt, UIElement listeningElement)
        {
            ((MyUIText)listeningElement).BorderColor = Color.White;
        }

        private void Text_OnMouseOut(UIMouseEvent evt, UIElement listeningElement)
        {
            ((MyUIText)listeningElement).BorderColor = Color.Black;
        }

        private void Text_OnClick(UIMouseEvent evt, UIElement listeningElement)
        {
            System.Diagnostics.Process.Start("msedge.exe", "https://jq.qq.com/?_wv=1027&k=SuxBagvj");
        }

        private void Text_OnClickZ(UIMouseEvent evt, UIElement listeningElement)
        {
            System.Diagnostics.Process.Start("msedge.exe", "https://space.bilibili.com/209703924");
        }
    }
}