﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using ReLogic.Graphics;

using Terraria;
using Terraria.UI;
using Terraria.UI.Chat;

namespace NeonDawn.UI
{
    public class MyUIElementText : UIElement
    {
        public string Text;
        public float Scale;
        private DynamicSpriteFont Font;
        private int drawMode;
        public Color Color, BorderColor;
        public MyUIElementText(string text, DynamicSpriteFont font, Color color, float scale = 1f)
        {
            Text = text;
            Scale = scale;
            Font = font;
            Color = color;
            drawMode = 0;
            Width.Pixels = Font.MeasureString(Text).X;
            Height.Pixels = Font.MeasureString(Text).Y;
            drawMode = 0;
        }
        public MyUIElementText(string text, DynamicSpriteFont font, Color color, Color borderColor, float scale = 1f)
        {
            Text = text;
            Scale = scale;
            Font = font;
            Color = color;
            BorderColor = borderColor;
            drawMode = 1;
            Width.Pixels = Font.MeasureString(Text).X;
            Height.Pixels = Font.MeasureString(Text).Y;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            CalculatedStyle dimensions = GetDimensions();
            if (drawMode == 0)
            {
                ChatManager.DrawColorCodedStringWithShadow(spriteBatch, Font, Text, new Vector2(dimensions.X, dimensions.Y), Color, 0, Vector2.Zero, new Vector2(Scale));
            }
            else if (drawMode == 1)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, Font, Text, dimensions.X, dimensions.Y, Color, BorderColor, Vector2.Zero, Scale);
            }
            Width.Pixels = Font.MeasureString(Text).X;
            Height.Pixels = Font.MeasureString(Text).Y;
        }
    }
}
