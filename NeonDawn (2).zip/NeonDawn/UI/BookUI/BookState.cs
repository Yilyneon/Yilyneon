﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Items.Bags;
using NeonDawn.Projs.NoSort;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.UI;
using Terraria.UI;

namespace NeonDawn.UI.BookUI
{
    public class BookState : UIState
    {
        public bool Visible = false;
        public UIImage Panel;

        public UIList TextView = new UIList();

        public BookScrollbar Scrollbar = new BookScrollbar();

        public UIImage Close;

        public UIImage Button;

        public UIImage OK;

        public override void OnInitialize()
        {
            Panel = new UIImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Panel", ReLogic.Content.AssetRequestMode.AsyncLoad));
            Panel.Width.Set(300, 0);
            Panel.Height.Set(490, 0);
            Panel.Top.Set(-Panel.Height.Pixels / 2, 0.5f);
            Panel.Left.Set(-Panel.Width.Pixels / 2, 0.5f);
            Append(Panel);

            TextView.Top.Set(0, 0.08f);
            TextView.Left.Set(0, 0.16f);
            TextView.Width.Set(0, 0.6f);
            TextView.Height.Set(0, 0.84f);
            Panel.Append(TextView);

            TextView.SetScrollbar(Scrollbar);
            Scrollbar.Left.Set(0, 0.9f);
            Scrollbar.Top.Set(0, 0.08f);
            Scrollbar.Width.Set(20, 0);
            Scrollbar.Height.Set(0, 0.8f);
            Scrollbar.WithView(100, 1000);
            Panel.Append(Scrollbar);
            for (int count = 0; count < 80; count++)
            {
                TextView.Add(new MyUIText("啊啊啊啊啊啊啊啊啊", FontAssets.MouseText.Value, Color.LightSkyBlue));
            }

            Close = new UIImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Close", ReLogic.Content.AssetRequestMode.AsyncLoad));
            Close.Width.Set(12, 0);
            Close.Height.Set(12, 0);
            Close.Left.Set(0, 0.82f);
            Close.Top.Set(0, 0.076f);
            Close.OnLeftClick += Close_OnClick;
            Panel.Append(Close);

            Button = new UIImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Button", ReLogic.Content.AssetRequestMode.AsyncLoad));
            Button.Width.Set(24, 0);
            Button.Height.Set(24, 0);
            Button.Left.Set(0, 0.1f);
            Button.Top.Set(0, 0.06f);
            Button.OnLeftClick += Button_OnClick;
            Panel.Append(Button);

            OK = new UIImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/OK", ReLogic.Content.AssetRequestMode.AsyncLoad));
            OK.Width.Set(24, 0);
            OK.Height.Set(24, 0);
            OK.Left.Set(0, 0.84f);
            OK.Top.Set(0, 0.9f);
            OK.OnLeftClick += OK_OnClick;
            Panel.Append(OK);

            base.OnInitialize();
        }

        private void OK_OnClick(UIMouseEvent evt, UIElement listeningElement)
        {
            if (!Main.LocalPlayer.GetModPlayer<BookSetting>().First)
            {
                OK.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/OK_Used", ReLogic.Content.AssetRequestMode.AsyncLoad));
                Main.LocalPlayer.QuickSpawnItem(Item.GetSource_None(), ModContent.ItemType<start>());
                Main.LocalPlayer.GetModPlayer<BookSetting>().First = true;
            }
            SoundEngine.PlaySound(new SoundStyle("NeonDawn/Sounds/Custom/UISFXButton"));
            Visible = false;
        }

        private void Button_OnClick(UIMouseEvent evt, UIElement listeningElement)
        {
            Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton = !Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton;
            if (Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton)
                Button.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Button_Used", ReLogic.Content.AssetRequestMode.AsyncLoad));
            else if (Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton)
                Button.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Button", ReLogic.Content.AssetRequestMode.AsyncLoad));
            SoundEngine.PlaySound(SoundID.Item114);
        }

        private void Close_OnClick(UIMouseEvent evt, UIElement listeningElement)
        {
            Visible = false;
        }

        public override void Update(GameTime gameTime)
        {
            if (Panel.ContainsPoint(Main.MouseScreen))
                Main.LocalPlayer.mouseInterface = true;

            Panel.Top.Set(-Panel.Height.Pixels / 2, 0.5f);
            Panel.Left.Set(-Panel.Width.Pixels / 2, 0.5f);

            if (Main.LocalPlayer.GetModPlayer<BookSetting>().First)
                OK.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/OK_Used", ReLogic.Content.AssetRequestMode.AsyncLoad));
            else
                OK.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/OK", ReLogic.Content.AssetRequestMode.AsyncLoad));

            if (Main.LocalPlayer.GetModPlayer<BookSetting>().UseBookButton)
                Button.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Button_Used", ReLogic.Content.AssetRequestMode.AsyncLoad));
            else
                Button.SetImage(ModContent.Request<Texture2D>("NeonDawn/Images/Book/Button", ReLogic.Content.AssetRequestMode.AsyncLoad));

            base.Update(gameTime);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
        }
    }
}