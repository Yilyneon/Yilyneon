﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using System.Reflection;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent.UI.Elements;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;

namespace NeonDawn.UI.BookUI
{
    public class BookScrollbar : UIScrollbar
    {
        private Asset<Texture2D> texture, innerTexture;
        public BookScrollbar( ) : base( )
        {
            texture = ModContent.Request<Texture2D>( "NeonDawn/Images/Book/SliderInner", ReLogic.Content.AssetRequestMode.ImmediateLoad );
            innerTexture = ModContent.Request<Texture2D>( "NeonDawn/Images/Book/Slider", ReLogic.Content.AssetRequestMode.ImmediateLoad );
            typeof( UIScrollbar ).GetField( "_texture", BindingFlags.NonPublic | BindingFlags.Instance ).SetValue( this, texture );
            typeof( UIScrollbar ).GetField( "_innerTexture", BindingFlags.NonPublic | BindingFlags.Instance ).SetValue( this, innerTexture );
        }
        protected override void DrawSelf( SpriteBatch spriteBatch )
        {
            CalculatedStyle dimensions = base.GetDimensions( );
            CalculatedStyle innerDimensions = base.GetInnerDimensions( );
            bool isDragging = (bool)typeof( UIScrollbar ).GetField( "_isDragging", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this );
            if( isDragging )
            {
                float num = UserInterface.ActiveInstance.MousePosition.Y - innerDimensions.Y - (float)typeof( UIScrollbar ).GetField( "_dragYOffset", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this ),
                    _maxViewSize = (float)typeof( UIScrollbar ).GetField( "_maxViewSize", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this ),
                    _viewSize = (float)typeof( UIScrollbar ).GetField( "_viewSize", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this );
                typeof( UIScrollbar ).GetField( "_viewPosition", BindingFlags.Instance | BindingFlags.NonPublic ).SetValue( this, MathHelper.Clamp( num / innerDimensions.Height * _maxViewSize, 0f, _maxViewSize - _viewSize ) );
            }
            Rectangle handleRectangle = (Rectangle)typeof( UIScrollbar ).GetMethod( "GetHandleRectangle", BindingFlags.Instance | BindingFlags.NonPublic ).Invoke( this, null );
            Vector2 mousePosition = UserInterface.ActiveInstance.MousePosition;
            bool isHoveringOverHandle = (bool)typeof( UIScrollbar ).GetField( "_isHoveringOverHandle", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this );
            typeof( UIScrollbar ).GetField( "_isHoveringOverHandle", BindingFlags.Instance | BindingFlags.NonPublic ).SetValue( this, handleRectangle.Contains( new Point( (int)mousePosition.X, (int)mousePosition.Y ) ) );
            if( !isHoveringOverHandle && (bool)typeof( UIScrollbar ).GetField( "_isHoveringOverHandle", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this ) && Main.hasFocus )
            {
                SoundEngine.PlaySound( SoundID.Item12 );
            }
            DrawBar( spriteBatch, texture.Value, dimensions.ToRectangle( ), Color.White );
            DrawBar( spriteBatch, innerTexture.Value, handleRectangle, Color.White * ((isDragging || (bool)typeof( UIScrollbar ).GetField( "_isHoveringOverHandle", BindingFlags.Instance | BindingFlags.NonPublic ).GetValue( this )) ? 1f : 0.85f) );
        }
        internal void DrawBar( SpriteBatch spriteBatch, Texture2D texture, Rectangle dimensions, Color color )
        {
            spriteBatch.Draw( texture, new Rectangle( dimensions.X + (dimensions.Width - texture.Width) / 2, dimensions.Y - 6, texture.Width, 6 ), new Rectangle( 0, 0, texture.Width, 6 ), color );
            spriteBatch.Draw( texture, new Rectangle( dimensions.X + (dimensions.Width - texture.Width) / 2, dimensions.Y, texture.Width, dimensions.Height ), new Rectangle( 0, 6, texture.Width, 4 ), color );
            spriteBatch.Draw( texture, new Rectangle( dimensions.X + (dimensions.Width - texture.Width) / 2, dimensions.Y + dimensions.Height, texture.Width, 6 ), new Rectangle( 0, texture.Height - 6, texture.Width, 6 ), color );
        }
    }
}