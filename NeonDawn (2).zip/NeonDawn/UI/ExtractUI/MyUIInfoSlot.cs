﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Systems;

using ReLogic.Graphics;

using Terraria;
using Terraria.GameContent;
using Terraria.UI;

namespace NeonDawn.UI.ExtractUI
{
    public class MyUIInfoSlot : UIElement
    {
        /// <summary>
        /// 框贴图
        /// </summary>
        public Texture2D SlotBackTexture { get; set; }
        /// <summary>
        /// 框内物品
        /// </summary>
        internal MaterialInfo ContainedInfo { get; set; }
        /// <summary>
        /// 框的绘制的拐角尺寸
        /// </summary>
        public Vector2 CornerSize { get; set; }
        /// <summary>
        /// 绘制颜色
        /// </summary>
        public Color DrawColor { get; set; }
        /// <summary>
        /// 介绍
        /// </summary>
        public string Tooltip { get; set; }
        /// <summary>
        /// 透明度
        /// </summary>
        public float Opacity { get; set; }
        /// <summary>
        /// 倍数
        /// </summary>
        public float Multiple;
        internal MyUIInfoSlot(MaterialInfo info, Texture2D texture = default(Texture2D)) : base()
        {
            Opacity = 0.6f;
            ContainedInfo = info.Clone();
            SlotBackTexture = texture == default(Texture2D) ? TextureAssets.InventoryBack.Value : texture;
            DrawColor = new Color(0x3f, 0x41, 0x97) * 0.75f;
            CornerSize = new Vector2(10, 10);
            Tooltip = "";
            Width.Set(50, 0);
            Height.Set(50, 0);
        }

        protected override void DrawSelf(SpriteBatch sb)
        {
            base.DrawSelf(sb);
            Main.instance.LoadItem(ContainedInfo.Type);
            float scale = Width.Pixels / 50f;
            DynamicSpriteFont font = NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value;
            //调用原版的介绍绘制
            if (ContainsPoint(Main.MouseScreen) && ContainedInfo.Type != 0)
            {
                Item item = new Item();
                item.SetDefaults(ContainedInfo.Type);
                Main.hoverItemName = item.Name;
                Main.HoverItem = item.Clone();
            }
            //获取当前UI部件的信息
            var DrawRectangle = GetDimensions();
            //绘制物品框
            DrawAdvBox(sb, (int)DrawRectangle.X, (int)DrawRectangle.Y,
                (int)DrawRectangle.Width, (int)DrawRectangle.Height,
                DrawColor * Opacity, SlotBackTexture, CornerSize, 1f);
            if (ContainedInfo.Type != 0)
            {
                var frame = Main.itemAnimations[ContainedInfo.Type] != null ? Main.itemAnimations[ContainedInfo.Type].GetFrame(TextureAssets.Item[ContainedInfo.Type].Value) : Item.GetDrawHitbox(ContainedInfo.Type, null);
                var size = frame.Size();
                var texScale = 1f;
                if (size.X > DrawRectangle.Width || size.Y > DrawRectangle.Height)
                {
                    texScale = size.X > size.Y ? size.X / DrawRectangle.Width : size.Y / DrawRectangle.Height;
                    texScale = 0.7f / texScale;
                    size *= texScale;
                }
                //绘制物品贴图
                sb.Draw(TextureAssets.Item[ContainedInfo.Type].Value, new Vector2(DrawRectangle.X + DrawRectangle.Width / 2f,
                    DrawRectangle.Y + DrawRectangle.Height / 2f) - /*TextureAssets.Item[ContainedInfo.Type].Value.Size() / 2f * scale*/new Vector2(frame.Width, frame.Height) / 2f * scale,
                    new Rectangle?(frame), Color.White * Opacity, 0f, Vector2.Zero, scale, 0, 0);
                //绘制物品左下角那个代表数量的数字
                if (ContainedInfo.MaxStack >= ContainedInfo.MinStack && ContainedInfo.MaxStack > 1)
                {
                    string text = $"({ContainedInfo.MinStack}~{ContainedInfo.MaxStack})*{Multiple}";
                    sb.DrawString(font, text, new Vector2(DrawRectangle.X + 4f, DrawRectangle.Y + DrawRectangle.Height - 20f), Color.White * Opacity, 0f, Vector2.Zero, scale * 0.5f, SpriteEffects.None, 0f);
                }
                if (ContainedInfo.Probability < 1f)
                {
                    string text = ((int)(ContainedInfo.Probability * 100f)) + "%";
                    sb.DrawString(font, text, new Vector2(DrawRectangle.X + DrawRectangle.Width / 2f, DrawRectangle.Y + DrawRectangle.Height / 2f) - font.MeasureString(text) / 2f * scale, Color.White, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                }
            }
        }
        /// <summary>
        /// 绘制物品框
        /// </summary>
        /// <param name="sp"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="w"></param>
        /// <param name="h"></param>
        /// <param name="c"></param>
        /// <param name="img"></param>
        /// <param name="size4"></param>
        /// <param name="scale"></param>
        public void DrawAdvBox(SpriteBatch sp, int x, int y, int w, int h, Color c, Texture2D img, Vector2 size4, float scale = 1f)
        {
            var box = img;
            var nw = (int)(w * scale);
            var nh = (int)(h * scale);
            x += (w - nw) / 2;
            y += (h - nh) / 2;
            w = nw;
            h = nh;
            var width = (int)size4.X;
            var height = (int)size4.Y;
            if (w < size4.X)
            {
                w = width;
            }
            if (h < size4.Y)
            {
                h = width;
            }
            sp.Draw(box, new Rectangle(x, y, width, height), new Rectangle(0, 0, width, height), c);
            sp.Draw(box, new Rectangle(x + width, y, w - width * 2, height), new Rectangle(width, 0, box.Width - width * 2, height), c);
            sp.Draw(box, new Rectangle((x + w) - width, y, width, height), new Rectangle(box.Width - width, 0, width, height), c);
            sp.Draw(box, new Rectangle(x, y + height, width, h - height * 2), new Rectangle(0, height, width, box.Height - height * 2), c);
            sp.Draw(box, new Rectangle(x + width, y + height, w - width * 2, h - height * 2), new Rectangle(width, height, box.Width - width * 2, box.Height - height * 2), c);
            sp.Draw(box, new Rectangle((x + w) - width, y + height, width, h - height * 2), new Rectangle(box.Width - width, height, width, box.Height - height * 2), c);
            sp.Draw(box, new Rectangle(x, (y + h) - height, width, height), new Rectangle(0, box.Height - height, width, height), c);
            sp.Draw(box, new Rectangle(x + width, (y + h) - height, w - width * 2, height), new Rectangle(width, box.Height - height, box.Width - width * 2, height), c);
            sp.Draw(box, new Rectangle((x + w) - width, (y + h) - height, width, height), new Rectangle(box.Width - width, box.Height - height, width, height), c);
        }
    }
}
