﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Systems;

using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;
using Terraria.UI;

namespace NeonDawn.UI.ExtractUI
{
    internal class ExtractItem : UIElement
    {
        public List<MyUIItemSlot> ItemSlots;
        public ExtractItem(Item[] items, int maxSlot)
        {
            ItemSlots = new List<MyUIItemSlot>();
            MyUIItemSlot itemSlot;
            for (int i = 0; i < items.Length; i++)
            {
                itemSlot = new MyUIItemSlot(ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value);
                itemSlot.Width.Pixels *= 1.6f;
                itemSlot.Height.Pixels *= 1.6f;
                itemSlot.Left.Set(0f, 1f / maxSlot * i);
                itemSlot.Top.Set(0f, 0f);
                itemSlot.DrawColor = Color.White;
                itemSlot.ContainedItem = items[i].Clone();
                itemSlot.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
                {
                    ((MyUIItemSlot)listeningElement).SlotBackTexture = ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot_1", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value;
                };
                itemSlot.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
                {
                    ((MyUIItemSlot)listeningElement).SlotBackTexture = ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value;
                };
                Append(itemSlot);
                ItemSlots.Add(itemSlot);
            }
        }
    }
    internal class ExtractInfo : UIElement
    {
        public List<MyUIInfoSlot> InfoSlots;
        public ExtractInfo(MaterialInfo[] infos, int maxSlot, float multiple = 1f)
        {
            InfoSlots = new List<MyUIInfoSlot>();
            MyUIInfoSlot itemSlot;
            for (int i = 0; i < infos.Length; i++)
            {
                itemSlot = new MyUIInfoSlot(infos[i], ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value);
                itemSlot.Width.Pixels *= 1.6f;
                itemSlot.Height.Pixels *= 1.6f;
                itemSlot.Left.Set(0f, 1f / maxSlot * i);
                itemSlot.Top.Set(0f, 0f);
                itemSlot.DrawColor = Color.White;
                itemSlot.Multiple = multiple;
                itemSlot.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
                {
                    ((MyUIInfoSlot)listeningElement).SlotBackTexture = ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot_1", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value;
                };
                itemSlot.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
                {
                    ((MyUIInfoSlot)listeningElement).SlotBackTexture = ModContent.Request<Texture2D>("NeonDawn/UI/Images/InfoSlot", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value;
                };
                Append(itemSlot);
                InfoSlots.Add(itemSlot);
            }
        }
    }
}
