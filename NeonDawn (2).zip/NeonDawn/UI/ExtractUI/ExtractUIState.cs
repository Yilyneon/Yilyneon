﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Systems;

using ReLogic.Content;
using ReLogic.Graphics;

using System.Collections.Generic;
using System.Reflection;

using Terraria;
using Terraria.GameContent.UI.Elements;
using Terraria.ModLoader;
using Terraria.UI;

namespace NeonDawn.UI.ExtractUI
{
    internal class ExtractUIState : UIState
    {
        internal bool Visible = false;
        internal UIList Components;
        internal MyUIItemSlot ItemSlot;
        private MyUIImage panel;
        private bool isExtract = false;
        private int nowPage;
        private List<ExtractRecipe> nowRecipe;
        private Vector2 offestValue = Vector2.Zero, startPoint = Vector2.Zero;
        private bool dragging = false;

        public override void OnInitialize()
        {
            nowRecipe = new List<ExtractRecipe>();

            UIElement element = new UIElement();
            element.Width.Set(0f, 1f);
            element.Height.Set(0f, 1f);
            Append(element);

            panel = new MyUIImage(ModContent.Request<Texture2D>("NeonDawn/UI/Images/ExtractPanel", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value);
            panel.Width.Pixels *= 2f;
            panel.Height.Pixels *= 2f;
            panel.Left.Set(-panel.Width.Pixels / 2f, 0.5f);
            panel.Top.Set(-panel.Height.Pixels / 2f, 0.5f);
            panel.OnLeftMouseDown += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                List<UIElement> uielements = typeof(UIElement).GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(listeningElement) as List<UIElement>;
                foreach (UIElement uielement in uielements)
                {
                    if (uielement != null && uielement.ContainsPoint(Main.MouseScreen))
                        return;
                }
                if (!dragging)
                {
                    dragging = true;
                    startPoint = Main.MouseScreen;
                }
            };
            panel.OnLeftMouseUp += delegate (UIMouseEvent evt, UIElement listeningElement)
             {
                 List<UIElement> uielements = typeof(UIElement).GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(listeningElement) as List<UIElement>;
                 foreach (UIElement uielement in uielements)
                 {
                     if (uielement != null && uielement.ContainsPoint(Main.MouseScreen))
                         return;
                 }
                 dragging = false;
             };
            panel.OnUpdate += delegate (UIElement affectedElement)
              {
                  if (startPoint != Main.MouseScreen && dragging)
                  {
                      offestValue = Main.MouseScreen - startPoint;
                      affectedElement.Left.Pixels += offestValue.X;
                      affectedElement.Top.Pixels += offestValue.Y;
                      startPoint = Main.MouseScreen;
                  }
              };
            panel.SetPadding(18);
            element.Append(panel);

            ItemSlot = new MyUIItemSlot(ModContent.Request<Texture2D>("NeonDawn/UI/Images/ItemSlot", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value);
            ItemSlot.Width.Pixels *= 2f;
            ItemSlot.Height.Pixels *= 2f;
            ItemSlot.Left.Set(-ItemSlot.Width.Pixels / 2f, 0.138f);
            ItemSlot.Top.Set(-ItemSlot.Height.Pixels / 2f, 0.34f);
            ItemSlot.DrawColor = Color.White;
            ItemSlot.PostExchangeItem += ItemSlot_PostExchangeItem;
            ItemSlot.CanPutInSlot += delegate (Item item)
              {
                  return !isExtract;
              };
            panel.Append(ItemSlot);

            UIElement extractItemPanel = new UIElement();
            extractItemPanel.Width.Set(0f, 0.7f);
            extractItemPanel.Height.Set(0f, 0.66f);
            extractItemPanel.Left.Set(0f, 0.3f);
            extractItemPanel.Top.Set(0f, 0.22f);
            extractItemPanel.SetPadding(16);
            panel.Append(extractItemPanel);

            Components = new UIList();
            Components.Width.Set(-25f, 1f);
            Components.Height.Set(0f, 1f);
            Components.ListPadding = 5f;
            extractItemPanel.Append(Components);

            MyUIScrollbar uiscrollbar = new MyUIScrollbar();
            uiscrollbar.SetView(100f, 1000f);
            uiscrollbar.Height.Set(0f, 1f);
            uiscrollbar.HAlign = 1f;
            extractItemPanel.Append(uiscrollbar);
            Components.SetScrollbar(uiscrollbar);

            MyUIImage extractButton = new MyUIImage(ModContent.Request<Texture2D>("NeonDawn/UI/Images/ExtractButton", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, 3);
            extractButton.Width.Pixels *= 2f;
            extractButton.Height.Pixels *= 2f;
            extractButton.Left.Set(-extractButton.Width.Pixels / 2f, 0.14f);
            extractButton.Top.Set(-extractButton.Height.Pixels / 2f, 0.66f);
            extractButton.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            extractButton.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 0;
            };
            extractButton.OnLeftMouseDown += delegate (UIMouseEvent evt, UIElement listeningElement)
              {
                  ((MyUIImage)listeningElement).Frame = 1;
              };
            extractButton.OnLeftMouseUp += delegate (UIMouseEvent evt, UIElement listeningElement)
              {
                  ((MyUIImage)listeningElement).Frame = 2;
              };
            extractButton.OnLeftClick += delegate (UIMouseEvent evt, UIElement listeningElement)
              {
                  if (!isExtract)
                  {
                      isExtract = true;
                      nowRecipe.Clear();
                      nowPage = 0;
                      ItemSlot.ContainedItem = new Item();
                      List<Item> list = new List<Item>();
                      Item item, item1;
                      foreach (ExtractInfo info in Components._items)
                      {
                          foreach (MyUIInfoSlot infoSlot in info.InfoSlots)
                          {
                              item = null;
                              for (int i = 0; i < infoSlot.Multiple; i++)
                              {
                                  if (item == null)
                                  {
                                      item = infoSlot.ContainedInfo.GetItem();
                                  }
                                  else
                                  {
                                      item1 = infoSlot.ContainedInfo.GetItem();
                                      if (item1 != null)
                                          item.stack += item1.stack;
                                  }
                              }
                              if (item != null)
                                  list.Add(item);
                          }
                      }
                      Components.Clear();
                      Components.AddRange(ItemsToUIElement(list));
                  }
                  else
                  {
                      TakeOutItem();
                      Components.Clear();
                      nowPage = 0;
                      nowRecipe.Clear();
                  }
              };
            panel.Append(extractButton);

            MyUIImage closeButton = new MyUIImage(ModContent.Request<Texture2D>("NeonDawn/UI/Images/ExtractClose", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, 3);
            closeButton.Width.Pixels *= 2f;
            closeButton.Height.Pixels *= 2f;
            closeButton.Left.Set(-extractButton.Width.Pixels / 2f, 0.998f);
            closeButton.Top.Set(-extractButton.Height.Pixels / 2f, 0.08f);
            closeButton.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            closeButton.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 0;
            };
            closeButton.OnLeftMouseDown += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 1;
            };
            closeButton.OnLeftMouseUp += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            closeButton.OnLeftClick += delegate (UIMouseEvent evt, UIElement listeningElement)
              {
                  Close();
              };
            panel.Append(closeButton);

            MyUIImage nextButton = new MyUIImage(ModContent.Request<Texture2D>("NeonDawn/UI/Images/NextPage", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, 3);
            nextButton.Left.Set(-nextButton.Width.Pixels / 2f, 0.94f);
            nextButton.Top.Set(-nextButton.Height.Pixels / 2f, 0.93f);
            nextButton.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            nextButton.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 0;
            };
            nextButton.OnLeftMouseDown += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 1;
            };
            nextButton.OnLeftMouseUp += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            nextButton.OnLeftClick += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ResetPage(nowPage + 1);
            };
            panel.Append(nextButton);

            MyUIImage lastButton = new MyUIImage(ModContent.Request<Texture2D>("NeonDawn/UI/Images/LastPage", ReLogic.Content.AssetRequestMode.ImmediateLoad).Value, 3);
            lastButton.Left.Set(-lastButton.Width.Pixels / 2f, 0.3f);
            lastButton.Top.Set(-lastButton.Height.Pixels / 2f, 0.93f);
            lastButton.OnMouseOver += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            lastButton.OnMouseOut += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 0;
            };
            lastButton.OnLeftMouseDown += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 1;
            };
            lastButton.OnLeftMouseUp += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ((MyUIImage)listeningElement).Frame = 2;
            };
            lastButton.OnLeftClick += delegate (UIMouseEvent evt, UIElement listeningElement)
            {
                ResetPage(nowPage - 1);
            };
            panel.Append(lastButton);
            base.OnInitialize();
        }

        private void ItemSlot_PostExchangeItem(UIElement target)
        {
            TakeOutItem();
            Components.Clear();
            nowPage = 0;
            nowRecipe.Clear();

            MyUIItemSlot slot = (MyUIItemSlot)target;
            if (slot.ContainedItem != null && slot.ContainedItem.type != 0)
            {
                nowRecipe = ExtractSystem.ExtractList.FindAll((x) => x.Dismantled.type == slot.ContainedItem.type && x.Dismantled.stack <= slot.ContainedItem.stack && slot.ContainedItem.stack % x.Dismantled.stack == 0);
                ResetPage(0);
            }
        }

        private void TakeOutItem()
        {
            if (Components.Count > 0)
            {
                ExtractItem extractItem;
                foreach (var element in Components)
                {
                    if (element is ExtractItem)
                    {
                        extractItem = element as ExtractItem;
                        foreach (var item in extractItem.ItemSlots)
                            if (item.ContainedItem != null && item.ContainedItem.type > 0)
                            {
                                Main.LocalPlayer.QuickSpawnItem(Main.LocalPlayer.GetSource_Death(), ItemSlot.ContainedItem);
                            }
                    }
                }
                Components.Clear();
            }
            if (isExtract)
                isExtract = false;
        }

        private void ResetPage(int page)
        {
            if (nowRecipe.Count == 0 || page >= nowRecipe.Count || page < 0)
                return;
            TakeOutItem();
            Components.Clear();

            nowPage = page;
            ExtractRecipe recipe = nowRecipe[nowPage];
            int multiple = ItemSlot.ContainedItem.stack / recipe.Dismantled.stack;

            Components.AddRange(InfosToUIElement(nowRecipe[nowPage].Materials, multiple > 1f ? multiple : 1f));
        }

        private List<ExtractItem> ItemsToUIElement(List<Item> items)
        {
            List<ExtractItem> list = new List<ExtractItem>();
            ExtractItem item;
            List<Item> itemList = new List<Item>();
            for (int i = 0; i < items.Count; i++)
            {
                itemList.Add(items[i]);
                if (itemList.Count == 5 || i == items.Count - 1)
                {
                    item = new ExtractItem(itemList.ToArray(), 5);
                    item.Width.Set(0f, 1f);
                    item.Height.Set(112f, 0f);
                    foreach (MyUIItemSlot slot in item.ItemSlots)
                    {
                        slot.CanTakeOutSlot += delegate (Item mouseItem)
                          {
                              return isExtract;
                          };
                        slot.CanPutInSlot += delegate (Item mouseItem)
                          {
                              return false;
                          };
                        slot.PostUpdate += delegate (UIElement element)
                          {
                              ((MyUIItemSlot)element).Opacity = isExtract ? 1f : 0.6f;
                          };
                    }
                    list.Add(item);

                    itemList.Clear();
                }
            }
            return list;
        }

        private List<ExtractInfo> InfosToUIElement(List<MaterialInfo> infos, float multiple = 1f)
        {
            List<ExtractInfo> list = new List<ExtractInfo>();
            ExtractInfo item;
            List<MaterialInfo> itemList = new List<MaterialInfo>();
            for (int i = 0; i < infos.Count; i++)
            {
                itemList.Add(infos[i]);
                if (itemList.Count == 5 || i == infos.Count - 1)
                {
                    item = new ExtractInfo(itemList.ToArray(), 5, multiple);
                    item.Width.Set(0f, 1f);
                    item.Height.Set(112f, 0f);
                    list.Add(item);

                    itemList.Clear();
                }
            }
            return list;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            Main.spriteBatch.End();
            Main.spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, null, null);
            base.Draw(spriteBatch);
            DynamicSpriteFont font = NeonDawn.Instance.Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", AssetRequestMode.ImmediateLoad).Value;
            string text = $"{nowPage + (nowRecipe.Count == 0 ? 0 : 1)}/{nowRecipe.Count}";
            CalculatedStyle style = panel.GetDimensions();
            Terraria.Utils.DrawBorderStringFourWay(spriteBatch, font, text, style.X + style.Width * 0.62f, style.Y + style.Height * 0.93f
                , Color.White, Color.Black, font.MeasureString(text) / 2f * 1.4f, 1.4f);
        }

        public void Close()
        {
            Visible = false;
            if (isExtract)
            {
                TakeOutItem();
            }
            else
            {
                if (ItemSlot.ContainedItem != null && ItemSlot.ContainedItem.type > 0)
                {
                    Main.LocalPlayer.QuickSpawnItem(Main.LocalPlayer.GetSource_Death(), ItemSlot.ContainedItem);
                    ItemSlot.ContainedItem = new Item();
                }
            }
            Components.Clear();
            nowRecipe.Clear();
            nowPage = 0;
        }

        public override void Update(GameTime gameTime)
        {
            if (panel.ContainsPoint(Main.MouseScreen))
                Main.LocalPlayer.mouseInterface = true;
            base.Update(gameTime);
        }
    }
}