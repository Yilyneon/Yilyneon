﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;
using System.Linq;

using Terraria;

namespace NeonDawn
{
    public static class StaticFunction
    {
        #region 为字符串染色
        /// <summary>
        /// 为字符串染色
        /// </summary>
        /// <param name="colors">需要染的颜色</param>
        /// <param name="texts">需要染色的字符串部位</param>
        /// <returns></returns>
        public static string[] StringToColorString(Color[] colors, string[] texts)
        {
            List<Color> sortColor = colors.ToList();
            sortColor.Sort((now, next) => (now.R * 0.299f + now.G * 0.587f + now.B * 0.114f).CompareTo(next.R * 0.299f + next.G * 0.587f + next.B * 0.114f));
            Color[] needColor = new Color[sortColor.Count];
            int iAdd = 0;
            int colorCount = needColor.Length / 2;
            for (int i = 0; i <= colorCount; i++)
            {
                if ((colorCount + i) < needColor.Length)
                {
                    needColor[colorCount + i] = sortColor[iAdd];
                }
                if (iAdd < (sortColor.Count - 1))
                    iAdd++;

                //if ((colorCount - i) > 0)
                {
                    needColor[colorCount - i] = sortColor[iAdd];
                }
                if (iAdd < (sortColor.Count - 1))
                    iAdd++;
            }
            List<string> s = new List<string>();
            string add;
            for (int x = 0; x < needColor.Length; x++)
            {
                add = "";
                for (int i = 0; i < texts.Length; i++)
                {
                    add += "[c/" + needColor[(x + i) % needColor.Length].Hex3() + ":" + texts[i] + "]";
                }
                s.Add(add);
            }
            return s.ToArray();
        }
        #endregion
        #region 将字符串分解为数组
        /// <summary>
        /// 将字符串分解为数组
        /// </summary>
        /// <param name="text">需要分解的字符串</param>
        /// <returns></returns>
        public static string[] StringToArray(string text)
        {
            string[] s = new string[text.Length];
            for (int i = 0; i < s.Length; i++)
                s[i] = text[i].ToString();
            return s;
        }
        #endregion

        private static float ColorTimer;
        public static Color LemonColor()
        {
            Color ColorA = new Color(255, 255, 255);
            Color ColorB = new Color(255, 248, 0);
            Color ColorC = new Color(255, 202, 0);
            Color ColorD = new Color(128, 255, 0);
            Color ColorE = new Color(160, 170, 0);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }
        public static Color AgeleSeekerColor()
        {
            Color ColorA = new Color(0, 0, 0);
            Color ColorB = new Color(42, 39, 82);
            Color ColorC = new Color(164, 82, 195);
            Color ColorD = new Color(203, 219, 252);
            Color ColorE = new Color(255, 255, 255);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }
        public static Color SAETColor()
        {
            Color ColorA = new Color(125, 34, 91);
            Color ColorB = new Color(255, 255, 255);
            Color ColorC = new Color(188, 62, 73);
            Color ColorD = new Color(255, 255, 255);
            Color ColorE = new Color(233, 154, 90);
            Color ColorF = new Color(255, 255, 255);
            Color ColorG = new Color(255, 229, 122);
            Color ColorH = new Color(255, 255, 255);
            Color ColorI = new Color(154, 225, 110);
            Color ColorJ = new Color(255, 255, 255);
            Color ColorK = new Color(65, 234, 242);
            Color ColorL = new Color(255, 255, 255);
            Color ColorM = new Color(255, 99, 239);
            Color ColorN = new Color(255, 255, 255);
            ColorTimer += 1f;
            if (ColorTimer >= 700)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 50)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 50);
            else if (ColorTimer < 100)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 50) / 50);
            else if (ColorTimer < 150)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 100) / 50);
            else if (ColorTimer < 200)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 150) / 50);
            else if (ColorTimer < 250)
                return Color.Lerp(ColorE, ColorF, (ColorTimer - 200) / 50);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorF, ColorG, (ColorTimer - 250) / 50);
            else if (ColorTimer < 350)
                return Color.Lerp(ColorG, ColorH, (ColorTimer - 300) / 50);
            else if (ColorTimer < 400)
                return Color.Lerp(ColorH, ColorI, (ColorTimer - 350) / 50);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorI, ColorJ, (ColorTimer - 400) / 50);
            else if (ColorTimer < 500)
                return Color.Lerp(ColorJ, ColorK, (ColorTimer - 450) / 50);
            else if (ColorTimer < 550)
                return Color.Lerp(ColorK, ColorL, (ColorTimer - 500) / 50);
            else if (ColorTimer < 600)
                return Color.Lerp(ColorL, ColorM, (ColorTimer - 550) / 50);
            else if (ColorTimer < 650)
                return Color.Lerp(ColorM, ColorN, (ColorTimer - 600) / 50);
            else
                return Color.Lerp(ColorN, ColorA, (ColorTimer - 650) / 50);
        }
        public static Color EnterVoucherColor()
        {
            Color ColorA = new Color(36, 35, 37);
            Color ColorB = new Color(74, 69, 70);
            Color ColorC = new Color(130, 119, 115);
            Color ColorD = new Color(64, 92, 108);
            Color ColorE = new Color(73, 164, 196);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }
    }
}
