﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Common.Systems;
using NeonDawn.Projs.Bosses;

using System;
using System.Collections.Generic;
using System.IO;

using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.GameContent.Bestiary;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

using Filters = Terraria.Graphics.Effects.Filters;

namespace NeonDawn.NPCs
{
    [AutoloadBossHead]
    public class MeleeMoon : ModNPC
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault(DownedBossSystem.downedSatellite1 ? "Lost Satellite A" : "Klios Automatic Head Defense Device");
            //DisplayName.AddTranslation((int)GameCulture.CultureName.Chinese, DownedBossSystem.downedSatellite1 ? "失落卫星A" : "克利俄斯号头部自动防卫装置");
            Main.npcFrameCount[NPC.type] = 1;
            var drawModifier = new NPCID.Sets.NPCBestiaryDrawModifiers(0)
            {
                CustomTexturePath = "NeonDawn/NPCs/MeleeMoon",
                Position = new Vector2(0f, 0f),
                PortraitPositionXOverride = 0f,
                PortraitPositionYOverride = 0f
            };
            NPCID.Sets.NPCBestiaryDrawOffset.Add(NPC.type, drawModifier);
            NPCID.Sets.TrailCacheLength[NPC.type] = 31;
            NPCID.Sets.TrailingMode[NPC.type] = 3;
            NPCDebuffImmunityData debuffData = new NPCDebuffImmunityData
            {
                ImmuneToAllBuffsThatAreNotWhips = true,
                ImmuneToWhips = false
            };
        }

        public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
        {
            string text = "English trans for Lost Satellite A here";
            if (Language.ActiveCulture.Name == "zh-Hans")
            {
                text = "失落卫星A的图鉴描述填在这里";
            }
            bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[]
            {
                BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Surface,
                BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Times.NightTime,//When and where do you want to summon the boss
                new FlavorTextBestiaryInfoElement(text)
            });
        }

        public override void SetDefaults()
        {
            NPC.damage = Main.expertMode ? (Main.masterMode ? 15 : 15) : 20;//NPC's contact damage is multiplied by 3 in mastermode and 2 in expertmode.
            NPC.width = 80;
            NPC.height = 80;
            NPC.defense = Main.expertMode ? (Main.masterMode ? 25 : 15) : 10;
            NPC.lifeMax = Main.expertMode ? (Main.masterMode ? 1620 : 2100) : 3650;//NPC's lifeMax will be multiplied by 2 in expertmode and 3 in mastermode.
            NPC.knockBackResist = 0f;
            NPC.value = Item.buyPrice(0, 2, 0, 0);
            NPC.aiStyle = -1;
            NPC.boss = true;
            NPC.lavaImmune = true;
            NPC.noGravity = true;
            NPC.noTileCollide = true;
            NPC.dontTakeDamage = false;
            NPCID.Sets.TrailCacheLength[NPC.type] = 32;
            NPCID.Sets.TrailingMode[NPC.type] = 3;
            NPC.netUpdate = true;
            NPC.netUpdate2 = true;
            NPC.netAlways = true;
            if (!Main.dedServ)
            {
                Music = MusicLoader.GetMusicSlot(Mod, "Sounds/Music/MoomFightOne");
            }
        }

        public enum NState//states' name
        {
            Spawn,
            NormalShoot,
            Dash,
            Strafe,
            Dialogue,
            Death
        }

        public NState State//bind the state switch to its ai[0] to automatically sync in multiplayer.
        {
            get { return (NState)(int)NPC.ai[0]; }
            set { NPC.ai[0] = (int)value; }
        }

        public void SwitchTo(NState state)
        {
            State = state;
        }

        public float SatelliteATimer
        {
            get => NPC.ai[1];
            set => NPC.ai[1] = value;
        }

        public float SpellTimer
        {
            get => NPC.ai[2];
            set => NPC.ai[2] = value;
        }

        public float CurrentPlayer
        {
            get => NPC.ai[3];
            set => NPC.ai[3] = value;
        }

        public static NPC MMoon = null;//register a static variable that stand for this NPC itself
        public bool Enraged = false;//register a boolean to judge if it's enraged or not
        public bool HalfLife = false;//register a boolean to judge if the NPC has carried out the dialogues below half life.
        public bool Death = false;//register a boolean to judge if the NPC has carried on the death animation.
        public bool Dialogued = false;//register a boolean to judge if the NPC has carried on the death dialogue.
        public float EnrageTimer = 0;//register a timer to count how long the enraged phase has been.

        public List<string> DeathDialogue => new()
        {
            "Death Dialogue 1",
            "Death Dialogue 2",
            "Death Dialogue 3",
            "Death Dialogue 4",
            "Death Dialogue 5",
            "Death Dialogue 6",
            "Death Dialogue 7",
            "Death Dialogue 8"
        }; //register a list containing strings for the death dialogue.

        public List<string> DeathDialogueCN => new()
        {
            "抉择语句1",
            "抉择语句2",
            "抉择语句3",
            "抉择语句4",
            "抉择语句5",
            "抉择语句6",
            "抉择语句7",
            "抉择语句8"
        };//register a list containing strings for the death dialogue(Chinese).

        public List<string> EnragedDeath => new()
        {
            Language.ActiveCulture.Name == "zh-Hans" ? "特殊结束语句1" : "Special Death Dialogue 1",
            Language.ActiveCulture.Name == "zh-Hans" ? "特殊结束语句2" : "Special Death Dialogue 2",
            Language.ActiveCulture.Name == "zh-Hans" ? "特殊结束语句3" : "Special Death Dialogue 3"
        };//register a list containing strings for enraged death dialogue.

        public List<string> ActualDeath => new()
        {
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句1" : "Actual Death Dialogue 1",
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句2" : "Actual Death Dialogue 2",
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句3" : "Actual Death Dialogue 3",
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句4" : "Actual Death Dialogue 4",
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句5" : "Actual Death Dialogue 5",
            Language.ActiveCulture.Name == "zh-Hans" ? "结束语句6" : "Actual Death Dialogue 6",
        };//register a list containing strings for actual death dialogue.

        public override void SendExtraAI(BinaryWriter writer)
        {
            writer.Write(NPC.dontTakeDamage);
            writer.Write(Enraged);
            writer.Write(HalfLife);
            writer.Write(Death);
            writer.Write(Dialogued);
            writer.Write(EnrageTimer);
        }//send message to server in multiplayer that may not be automatically synched

        public override void ReceiveExtraAI(BinaryReader reader)
        {
            NPC.dontTakeDamage = reader.ReadBoolean();
            Enraged = reader.ReadBoolean();
            HalfLife = reader.ReadBoolean();
            Death = reader.ReadBoolean();
            Dialogued = reader.ReadBoolean();
            EnrageTimer = reader.ReadSingle();
        }//receive the message sent to server

        public override void AI()
        {
            Lighting.AddLight(NPC.Center, 1, 1, 1);//Add light to let it visable at night
            if (Main.netMode != NetmodeID.MultiplayerClient)
            {
                if (SatelliteATimer > 240)
                {
                    if (!Main.raining)
                    {
                        Main.StartRain();
                    }
                    Main.maxRain = 250;
                    if (Main.windCounter < 10)
                    {
                        Main.windCounter += 1;
                    }
                    if (Main.windSpeedTarget <= 40)
                    {
                        Main.windSpeedTarget += .01f;
                    }
                }
            }
            if (NPC.localAI[0] == 0)
            {
                if (MMoon == null || !MMoon.active)
                {
                    MMoon = NPC;
                }
                NPC.TargetClosest(true);
                NPC.localAI[0] = 1;//set the static variable's value to this NPC itself
            }
            if (MMoon == null || !MMoon.active)
            {
                MMoon = NPC;
            }
            if (Main.netMode != NetmodeID.MultiplayerClient)
            {
                CurrentPlayer = 0;
                foreach (Player player in Main.player)
                {
                    if (player.active && !player.dead)
                    {
                        CurrentPlayer++;
                    }
                }
                if (CurrentPlayer == 0)
                {
                    NPC.active = false;
                }//foreach all of the players per frame. If there isn't at least one player alive, the NPC disppears instantly.
            }
            if (NPC.target < 0 || NPC.target == 255 || Main.player[NPC.target].dead || !Main.player[NPC.target].active)
            {
                NPC.TargetClosest(true);
            }//if target player is dead/not any targets/target player offline:try to target another player
            else
            {
                if (Vector2.Distance(Main.player[NPC.target].Center, NPC.Center) <= 900f)
                {
                    NPC.timeLeft = 600;
                }//if the target player get near the NPC, add its timeleft to prevent from disappearing
            }
            SatelliteATimer++;
            if (SatelliteATimer % 8 == 0 && Main.netMode != NetmodeID.Server)
            {
                if (State != NState.Spawn && NPC.velocity.Length() > 0)
                {
                    for (float r = 10; r <= 360; r += 10)
                    {
                        Vector2 dPos = NPC.Center + new Vector2((float)Math.Cos(MathHelper.ToRadians(r)) * 20f, -30f).RotatedBy(NPC.rotation - MathHelper.ToRadians(90));
                        Vector2 dVel = new Vector2(6f * (float)Math.Cos(MathHelper.ToRadians(r)), 3f * (float)Math.Sin(MathHelper.ToRadians(r)) - 6f).RotatedBy(NPC.rotation - MathHelper.ToRadians(90));
                        Dust dust = Dust.NewDustDirect(dPos, 1, 1, DustID.GreenTorch);
                        dust.noGravity = true;
                        dust.velocity = dVel;
                        dust.scale = 1.5f;
                    }//dust circle spray out at its tail
                }
            }
            if (NPC.life <= NPC.lifeMax / 2)
            {
                if (!HalfLife)
                {
                    if (Main.netMode != NetmodeID.MultiplayerClient)
                    {
                        HalfLife = true;
                        Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "半血语句1" : "Half Life Dialogue 1");
                        Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "半血语句2" : "Half Life Dialogue 2");
                    }
                }
            }
            if (Enraged)
            {
                if (Filters.Scene["GreenShader"].IsActive())
                {
                    Filters.Scene.Deactivate("GreenShader");
                }
                if (!Filters.Scene["RedShader"].IsActive())
                {
                    Filters.Scene.Activate("RedShader");
                }//activates RedShader and deactivates GreenShader in enraged phase.
                EnrageTimer++;
                if (Filters.Scene["RedShader"].IsActive())
                {
                    NeonDawn.RedShader.Parameters["EnrageTime"].SetValue(EnrageTimer);
                }//when the RedShader is active, pass the timer into it to let its color gradually swap to red.
                if (!Main.dedServ)
                {
                    Music = MusicLoader.GetMusicSlot(Mod, "Sounds/Music/MoomFightTwo");
                }
                if (EnrageTimer >= 3000)
                {
                    if (Main.netMode != NetmodeID.MultiplayerClient)
                    {
                        EnrageTimer = 0;
                        SpellTimer = 0;
                        NPC.velocity = Vector2.Zero;
                        SwitchTo(NState.Death);
                    }
                }
            }
            switch (State)
            {
                case NState.Spawn://spawn: fly above player's head, switching to other states after a few dialogues and summon the remote moon
                    {
                        NPC.dontTakeDamage = true;
                        SpellTimer++;
                        if (SpellTimer < 180)
                        {
                            if (Main.LocalPlayer == Main.player[NPC.target])
                            {
                                Main.LocalPlayer.velocity *= 0;
                                Main.LocalPlayer.position = Main.LocalPlayer.oldPosition;
                                Main.LocalPlayer.itemTime = Main.LocalPlayer.HeldItem.useTime - 1;
                                Main.LocalPlayer.gravity = 0;
                            }
                            if (NPC.velocity.Length() > 0)
                            {
                                NPC.rotation = NPC.velocity.ToRotation();
                            }
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                if (Main.player[NPC.target] != null && Main.player[NPC.target].active && !Main.player[NPC.target].dead)
                                {
                                    NPC.velocity = (Main.player[NPC.target].Center - new Vector2(0, 200) - NPC.Center) / 33f;
                                }//try to approach above the target player's head
                            }
                        }
                        else
                        {
                            NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .066f);
                        }
                        if (SpellTimer == 180)
                        {
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                NPC.velocity *= 0;
                            }
                        }
                        if (SpellTimer == 270)
                        {
                            Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "开局语句1" : "Spawn Dialogue 1");
                        }//spawn dialogue 1
                        if (SpellTimer == 390)
                        {
                            Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "开局语句2" : "Spawn Dialogue 2");
                        }//spawn dialogue 2
                        if (SpellTimer == 510)
                        {
                            Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "开局语句3" : "Spawn Dialogue 3");
                        }//spawn dialogue 3
                        if (SpellTimer == 630)
                        {
                            NPC.dontTakeDamage = false;
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                if (!Filters.Scene["GreenShader"].IsActive())
                                {
                                    Filters.Scene.Activate("GreenShader");
                                }//if the screenshader is not activated, activate it
                                if (!NPC.AnyNPCs(ModContent.NPCType<RemoteMoon>()))
                                {
                                    int remote = NPC.NewNPC(NPC.GetSource_FromAI(), (int)NPC.Center.X, (int)NPC.Center.Y - 100, ModContent.NPCType<RemoteMoon>());
                                    Main.npc[remote].realLife = NPC.whoAmI;
                                }//if the remote moon is not alive, summon it and set its realLife to this npc.whoAmI, so that the remote moon will be bound with it
                            }
                            SpellTimer = 0;
                            SwitchTo(NState.NormalShoot);
                        }
                        break;
                    }
                case NState.NormalShoot:
                    {
                        SpellTimer++;
                        NPC.rotation = (Main.player[NPC.target].Center - NPC.Center).ToRotation();//in this state, I let the NPC face directly at the player.
                        if (Main.netMode != NetmodeID.MultiplayerClient)
                        {
                            NPC.velocity = Vector2.Lerp(NPC.velocity, Utils.SafeNormalize(Main.player[NPC.target].Center - NPC.Center, Vector2.Zero) * 3f, .075f);
                        }//use lerp to make it move more smoothly.
                        if (SpellTimer >= 120 && SpellTimer % (Enraged ? 60 : 90) == 0)
                        {
                            SoundEngine.PlaySound(SoundID.Item33, NPC.Center);
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                for (float r = -30; r <= 30; r += 30)
                                {
                                    Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, Utils.SafeNormalize(Main.player[NPC.target].Center - NPC.Center, Vector2.UnitX).RotatedBy(MathHelper.ToRadians(r)) * 15f, ModContent.ProjectileType<Greenproj>(), Main.expertMode ? (Main.masterMode ? 8 : 18) : 24, .05f, Main.myPlayer);
                                    NPC.velocity -= new Vector2(Enraged ? 3f : 4f, 0).RotatedBy(NPC.rotation);//make it move backwards a bit after shooting the lasers
                                }
                            }
                        }
                        if (SpellTimer >= 440)
                        {
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                NPC.velocity *= 0;
                                SpellTimer = 0;
                                SwitchTo((NState)Main.rand.Next(new int[] { 2, 3 }));
                            }//switch to next attack after shooting 3 times of lasers, selecting between dashing attack and laser attack
                        }
                        break;
                    }
                case NState.Dash:
                    {
                        SpellTimer++;
                        if (NPC.velocity.Length() > 0)
                        {
                            NPC.rotation = NPC.velocity.ToRotation();
                        }//in this state, I let the NPC face where it goes.
                        if (SpellTimer > 40)
                        {
                            if (SpellTimer % (Enraged ? 50 : 75) == 0)
                            {
                                SoundEngine.PlaySound(new SoundStyle("NeonDawn/Sounds/Custom/Roar_0"), NPC.Center);
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity = Utils.SafeNormalize(Main.player[NPC.target].Center - NPC.Center, Vector2.UnitX) * 18f;
                                }
                            }
                            if (SpellTimer % (Enraged ? 50 : 75) > 40)
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity *= .95f;
                                }
                            }
                            if (SpellTimer % (Enraged ? 50 : 75) == (Enraged ? 40 : 60))
                            {
                                SoundEngine.PlaySound(SoundID.Item61, NPC.Center);
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    for (float r = -30; r <= 30; r += 60)
                                    {
                                        Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, new Vector2(6, 0).RotatedBy(NPC.rotation + MathHelper.ToRadians(r)), ModContent.ProjectileType<MoonRocket>(), Main.expertMode ? (Main.masterMode ? 8 : 18) : 24, .05f, NPC.target);
                                    }
                                }
                            }//when the dash nearly ends, let it shoot 2 rockets
                            if (SpellTimer >= (Enraged ? 140 : 200))
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity *= 0;
                                    SpellTimer = 0;
                                    SwitchTo((NState)Main.rand.Next(new int[] { 1, 3 }));
                                }//switch to next attack, selecting between shooting attack and laser attack
                            }
                        }
                        break;
                    }
                case NState.Strafe:
                    {
                        SpellTimer++;
                        if (SpellTimer < 120)
                        {
                            if (NPC.velocity.Length() > 0)
                            {
                                NPC.rotation = NPC.velocity.ToRotation();
                            }
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                if (Main.player[NPC.target] != null && Main.player[NPC.target].active && !Main.player[NPC.target].dead)
                                {
                                    NPC.velocity = (Main.player[NPC.target].Center - new Vector2(0, 300) - NPC.Center) / 12f;
                                }//before shooting lasers, I let the NPC going above player's head to avoid the attack being cheesed
                            }
                        }
                        else
                        {
                            if (SpellTimer == 120)
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity *= 0;
                                }
                            }
                            if (SpellTimer < 150)
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .33f);
                                }
                            }//let it align before shooting laser.
                            if (SpellTimer == 150)
                            {
                                SoundEngine.PlaySound(SoundID.Item13, NPC.Center);
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, Vector2.Zero, ModContent.ProjectileType<MeleeMoonLaser>(), Main.expertMode ? (Main.masterMode ? 12 : 28) : 40, .05f, Main.myPlayer, NPC.whoAmI);
                                }
                            }
                            if (SpellTimer > 150)
                            {
                                if (SpellTimer % 10 == 0)
                                {
                                    for (float r = 10; r <= 360; r += 10)
                                    {
                                        Vector2 dPos = NPC.Center + new Vector2((float)Math.Cos(MathHelper.ToRadians(r)) * 4f, -30f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                        Vector2 dVel = new Vector2(3f * (float)Math.Cos(MathHelper.ToRadians(r)), 2f * (float)Math.Sin(MathHelper.ToRadians(r)) - 4f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                        Dust dust = Dust.NewDustDirect(dPos, 1, 1, DustID.GreenTorch);
                                        dust.noGravity = true;
                                        dust.velocity = dVel;
                                        dust.scale = 1.2f;
                                        dust.fadeIn = .6f;
                                    }
                                }
                            }
                            if ((SpellTimer - 150) % (Enraged ? 180 : 240) <= (Enraged ? 45 : 60) || (SpellTimer - 150) % (Enraged ? 180 : 240) > (Enraged ? 135 : 180))
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.rotation -= MathHelper.ToRadians(Enraged ? 2 : 1.5f);
                                }
                            }
                            else
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.rotation += MathHelper.ToRadians(Enraged ? 2 : 1.5f);
                                }
                            }
                            if (((SpellTimer - 150) % (Enraged ? 180 : 240)) % (Enraged ? 66 : 88) == 0)
                            {
                                SoundEngine.PlaySound(SoundID.Item61, NPC.Center);
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    for (float r = -30; r <= 30; r += 60)
                                    {
                                        Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, new Vector2(6, 0).RotatedBy(NPC.rotation + MathHelper.ToRadians(r + 90)), ModContent.ProjectileType<MoonRocket>(), Main.expertMode ? (Main.masterMode ? 8 : 18) : 24, .05f, NPC.target);
                                    }
                                }//periodly shoots a pair of rockets
                            }
                            if (SpellTimer - 150 >= (Enraged ? 180 : 240))
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    foreach (Projectile proj in Main.projectile)
                                    {
                                        if (proj.type == ModContent.ProjectileType<MeleeMoonLaser>())
                                        {
                                            proj.Kill();
                                        }
                                    }
                                    NPC.velocity *= 0;
                                    SpellTimer = 0;
                                    SwitchTo((NState)Main.rand.Next(new int[] { 1, 2 }));
                                }//switch to next attack, selecting between shooting attack and dashing attack
                            }
                        }
                        break;
                    }
                case NState.Dialogue:
                    {
                        SpellTimer++;
                        if (SpellTimer == 120 || SpellTimer == 240 || SpellTimer == 360 || SpellTimer == 480 || SpellTimer == 600 || SpellTimer == 720 || SpellTimer == 840 || SpellTimer == 960)
                        {
                            Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? DeathDialogueCN[(int)SpellTimer / 120 - 1] : DeathDialogue[(int)SpellTimer / 120 - 1]);
                        }//select the target string from existing List, which will make it way more easier to do reiterated NewTexts.
                        if (Main.netMode != NetmodeID.MultiplayerClient)
                        {
                            Dialogued = true;
                            NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .1f);
                        }
                        if (SpellTimer == 960)
                        {
                            NPC.dontTakeDamage = false;
                        }
                        if (SpellTimer >= 1560)
                        {
                            NPC.dontTakeDamage = true;
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                foreach (Projectile proj in Main.projectile)
                                {
                                    if (proj.hostile)
                                    {
                                        proj.Kill();
                                    }
                                }
                                Enraged = true;
                                NPC.velocity *= 0;
                                SpellTimer = 0;
                                SwitchTo(NState.NormalShoot);
                            }
                        }
                        break;
                    }
                case NState.Death:
                    {
                        SpellTimer++;
                        if (Filters.Scene["RedShader"].IsActive())
                        {
                            Filters.Scene.Deactivate("RedShader");
                        }
                        if (!Enraged)
                        {
                            if (SpellTimer == 120 || SpellTimer == 240 || SpellTimer == 360 || SpellTimer == 480 || SpellTimer == 600 || SpellTimer == 720)
                            {
                                Main.NewText(ActualDeath[(int)(SpellTimer / 120 - 1)]);
                            }//select the target string from existing List, which will make it way more easier to do reiterated NewTexts.
                        }
                        else
                        {
                            if (SpellTimer == 240 || SpellTimer == 480 || SpellTimer == 720)
                            {
                                Main.NewText(EnragedDeath[(int)SpellTimer / 240 - 1]);
                            }//select the target string from existing List, which will make it way more easier to do reiterated NewTexts.
                        }
                        if (Main.netMode != NetmodeID.MultiplayerClient)
                        {
                            Death = true;
                            NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .1f);
                        }
                        if (SpellTimer > 1020 && Main.netMode != NetmodeID.MultiplayerClient)
                        {
                            NPC.Center += new Vector2(Main.rand.NextFloat(-7, 7), Main.rand.NextFloat(-7, 7));//trembling~
                        }
                        Dust dust = Dust.NewDustDirect(NPC.position, NPC.width, NPC.height, DustID.Smoke);
                        dust.noGravity = true;
                        dust.velocity = new Vector2(0, -6);
                        dust.scale = 1.5f;
                        dust.fadeIn = .75f;
                        if (SpellTimer >= 1320)
                        {
                            NPC.velocity *= 0;
                            SpellTimer = 0;
                            NPC.life = 0;
                            NPC.checkDead();
                        }
                        break;
                    }
            }
        }

        public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
        {
            Texture2D tex = ModContent.Request<Texture2D>("NeonDawn/NPCs/MeleeMoon").Value;
            Vector2 pos1 = NPC.Center - Main.screenPosition;
            Vector2 ori = new Vector2(40, 40);
            spriteBatch.End();
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.Additive, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);
            for (int i = 0; i <= 30; i += 2)
            {
                Vector2 pos2 = NPC.oldPos[i] + ori - Main.screenPosition;
                Color color = Color.Green * ((float)(NPC.oldPos.Length - i) / (NPC.oldPos.Length)) * .66f;
                spriteBatch.Draw(tex, pos2, null, color, NPC.oldRot[i], ori, 1f, (NPC.rotation >= MathHelper.PiOver2 || NPC.rotation <= -MathHelper.PiOver2) ? SpriteEffects.FlipVertically : SpriteEffects.None, 0f);
            }
            spriteBatch.End();
            spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);
            spriteBatch.Draw(tex, pos1, null, Color.White, NPC.rotation, ori, 1f, (NPC.rotation >= MathHelper.PiOver2 || NPC.rotation <= -MathHelper.PiOver2) ? SpriteEffects.FlipVertically : SpriteEffects.None, 0f);
            if (Enraged && State != NState.Death)
            {
                string Countdown = (Language.ActiveCulture.Name == "zh-Hans" ? "狂暴状态剩余：" : "Enrage Phase Timeleft: ") + (50 - (EnrageTimer - EnrageTimer % 60) / 60) + (Language.ActiveCulture.Name == "zh-Hans" ? " 秒" : " Seconds");
                Color stringcolor = new Color(255, (int)(255 * (float)((float)(3000f - EnrageTimer) / 3000f)), (int)(255 * (float)((float)(3000f - EnrageTimer) / 3000f)));
                if (Vector2.Distance(Main.LocalPlayer.Center, NPC.Center) <= 1500f)
                {
                    Vector2 stringpos = Main.LocalPlayer.Center - new Vector2(250, -10 + Main.screenHeight / 2) - Main.screenPosition;
                    Utils.DrawBorderString(Main.spriteBatch, Countdown, stringpos, stringcolor, 2f);
                }
            }
            return false;
        }

        public override bool CheckDead()
        {
            if (!Dialogued)
            {
                foreach (Projectile proj in Main.projectile)
                {
                    if (proj.hostile)
                    {
                        proj.Kill();
                    }
                }
                SpellTimer = 0;
                NPC.dontTakeDamage = true;
                NPC.life = 1;
                NPC.active = true;
                NPC.velocity *= 0;
                SwitchTo(NState.Dialogue);
            }//death check step 1: if hasn't carried out the dialogue, switch to it and return false
            else
            {
                if (!Death)
                {
                    foreach (Projectile proj in Main.projectile)
                    {
                        if (proj.hostile)
                        {
                            proj.Kill();
                        }
                    }
                    SpellTimer = 0;
                    NPC.dontTakeDamage = true;
                    NPC.life = 1;
                    NPC.active = true;
                    NPC.velocity *= 0;
                    SwitchTo(NState.Death);
                }//death check step 2: if hasn't carried out the death dialogue, switch to it and return false
                else
                {
                    foreach (Projectile proj in Main.projectile)
                    {
                        if (proj.hostile)
                        {
                            proj.Kill();
                        }
                    }
                    GNPCSystem.SpawnGore(NPC, 5, GoreID.Smoke1);
                    GNPCSystem.SpawnGore(NPC, 8, GoreID.Smoke2);
                    GNPCSystem.SpawnGore(NPC, 3, GoreID.Smoke3);//erupts gores on death
                    SoundEngine.PlaySound(new SoundStyle("NeonDawn/Sounds/Custom/se_enep01"), NPC.Center);//play sound on death
                    return true;
                }
            }
            return false;
        }

        public override bool PreKill()
        {
            if (Enraged)
            {
                if (!DownedBossSystem.downedEnragedSatellite)
                {
                    DownedBossSystem.downedEnragedSatellite = true;
                    NPC.NewNPC(NPC.GetSource_FromAI(), (int)NPC.Center.X, (int)NPC.Center.Y, NPCID.TravellingMerchant);//spawns NPC on death
                }
            }
            return base.PreKill();
        }

        public override void ModifyNPCLoot(NPCLoot npcLoot)
        {
            DownedBossSystem.downedSatellite1 = true;
            DownedBossSystem.downedSatellite2 = true;
        }
    }
}