﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using System;
using System.Collections.Generic;

using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.Graphics.Shaders;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

using Filters = Terraria.Graphics.Effects.Filters;

namespace NeonDawn.NPCs
{
    public class SatelliteSmall : ModNPC
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("Lost Satellite");
            //DisplayName.AddTranslation((int)GameCulture.CultureName.Chinese, "失落卫星");
            Main.npcFrameCount[NPC.type] = 1;
            NPCDebuffImmunityData debuffData = new NPCDebuffImmunityData
            {
                ImmuneToAllBuffsThatAreNotWhips = true,
                ImmuneToWhips = false
            };
        }

        public override void SetDefaults()
        {
            NPC.damage = 0;
            NPC.width = 1;
            NPC.height = 1;
            NPC.defense = 0;
            NPC.lifeMax = 10;
            NPC.knockBackResist = 0f;
            NPC.dontTakeDamage = true;
            NPC.value = Item.buyPrice(0, 0, 0, 0);
            NPC.aiStyle = -1;
            NPC.lavaImmune = true;
            NPC.noGravity = true;
            NPC.noTileCollide = true;
            NPC.netUpdate = true;
            NPC.netUpdate2 = true;
            NPC.netAlways = true;
        }

        public enum NState//states' name
        {
            Rise,
            Explode,
            Back,
            Countdown,
            Kill
        }

        public NState State//bind the state switch to its ai[0] to automatically sync in multiplayer.
        {
            get { return (NState)(int)NPC.ai[0]; }
            set { NPC.ai[0] = (int)value; }
        }

        public void SwitchTo(NState state)
        {
            State = state;
        }

        public float Timer
        {
            get => NPC.ai[1];
            set => NPC.ai[1] = value;
        }

        public float SpellTimer
        {
            get => NPC.ai[2];
            set => NPC.ai[2] = value;
        }

        public Player Owner
        {
            get => Main.player[(int)NPC.ai[3]];
            set => Main.player[(int)NPC.ai[3]] = value;
        }

        public static List<string> Dialogue => new()
        {
            Language.ActiveCulture.Name == "zh-Hans" ? "1" : "1",
            Language.ActiveCulture.Name == "zh-Hans" ? "2" : "2",
            Language.ActiveCulture.Name == "zh-Hans" ? "3" : "3",
            Language.ActiveCulture.Name == "zh-Hans" ? "4" : "4",
            Language.ActiveCulture.Name == "zh-Hans" ? "5" : "5"
        };

        public override bool CheckActive()
        {
            if (State != NState.Kill)
            {
                NPC.active = true;
                return false;
            }
            else
            {
                return base.CheckActive();
            }
        }

        public override bool CheckDead()
        {
            if (State == NState.Kill)
            {
                return true;
            }
            return false;
        }

        public override void AI()
        {
            Player player = Main.player[base.NPC.target];
            NPC.timeLeft++;
            Timer++;
            if (!Owner.active || Owner.dead)
            {
                NPC.life = 0;
                NPC.active = false;
            }
            else
            {
                switch (State)
                {
                    case NState.Rise:
                        {
                            SpellTimer += 1f;
                            if (NPC.Center.Y >= 2000)
                            {
                                for (int i = -1; i <= 1; i += 2)
                                {
                                    Vector2 dPos = new Vector2(i * (float)Math.Cos(MathHelper.ToRadians(SpellTimer * 6f)) * 40f, 0);
                                    Dust dust = Main.dust[Dust.NewDust(NPC.Center + dPos, 0, 0, 160, 0f, 0f, 0, (new Color(Main.DiscoR, Main.DiscoG, Main.DiscoB)), 1f)];
                                    dust.noGravity = true;
                                    dust.shader = GameShaders.Armor.GetSecondaryShader(player.cYorai, player);
                                    dust.color = Color.Green;
                                    dust.velocity = NPC.velocity;
                                    dust.scale = 2f;
                                    dust.fadeIn = .9f;
                                    dust.customData = NPC;
                                    if (dust.customData != null && dust.customData is NPC)
                                    {
                                        NPC NPC = (NPC)dust.customData;
                                        dust.position += NPC.position - NPC.oldPosition;
                                        dust.customData = null;
                                    }
                                }
                                Dust dustcenter = Main.dust[Dust.NewDust(NPC.Center, 0, 0, 160, 0f, 0f, 0, (new Color(Main.DiscoR, Main.DiscoG, Main.DiscoB)), 1f)];
                                dustcenter.noGravity = true;
                                dustcenter.color = Color.Green;
                                dustcenter.velocity = NPC.velocity;
                                dustcenter.scale = 2f;
                                dustcenter.fadeIn = .9f;

                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity.Y -= .1f;
                                }
                            }
                            else
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    SpellTimer = 0;
                                    NPC.velocity *= 0;
                                    SwitchTo(NState.Explode);
                                }
                            }
                            break;
                        }
                    case NState.Explode:
                        {
                            SpellTimer++;
                            if (SpellTimer < 30)
                            {
                                foreach (Dust dust in Main.dust)
                                {
                                    dust.velocity *= .5f;
                                }
                            }
                            if (SpellTimer == 30)
                            {
                                SoundEngine.PlaySound(new SoundStyle("NeonDawn/Sounds/Custom/se_enep01"), NPC.Center);
                                for (int i = 1; i <= 300; i++)
                                {
                                    Vector2 dVel = Main.rand.NextFloat(0, 6.28f).ToRotationVector2() * Main.rand.NextFloat(0, 30f);
                                    Dust dust = Dust.NewDustDirect(NPC.Center, 1, 1, DustID.GreenTorch);
                                    dust.noGravity = true;
                                    dust.velocity = dVel;
                                    dust.scale = Main.rand.NextFloat(1f, 3.6f);
                                }
                            }
                            if (SpellTimer == 90)
                            {
                                Main.NewText(Language.ActiveCulture.Name == "zh-Hans" ? "我有一种不祥的预感……" : "I have an ominous premonition......", Color.Purple);
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    SpellTimer = 0;
                                    SwitchTo(NState.Back);
                                }
                            }
                            break;
                        }
                    case NState.Back:
                        {
                            SpellTimer++;
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                NPC.velocity = Utils.SafeNormalize(Owner.Center - NPC.Center, Vector2.Zero) * (float)Math.Max(8f, (Owner.Center - NPC.Center).Length() / 50f);
                            }
                            if (Vector2.Distance(Owner.Center, NPC.Center) <= 20f)
                            {
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    NPC.velocity *= 0;
                                    SpellTimer = 0;
                                    SwitchTo(NState.Countdown);
                                }
                            }
                            break;
                        }
                    case NState.Countdown:
                        {
                            SpellTimer++;
                            if (SpellTimer == 1)
                            {
                                Filters.Scene.Activate("GradualGreenShader");
                            }
                            if (Filters.Scene["GradualGreenShader"].IsActive())
                            {
                                NeonDawn.GradualGreenShader.Parameters["Timer"].SetValue((float)SpellTimer);
                            }
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                NPC.Center = Owner.Center;
                            }
                            if (SpellTimer == 300 || SpellTimer == 600 || SpellTimer == 900 || SpellTimer == 1200 || SpellTimer == 1500)
                            {
                                Main.NewText(Dialogue[(int)(SpellTimer / 300) - 1]);
                            }
                            if (SpellTimer == 1800)
                            {
                                if (Filters.Scene["GradualGreenShader"].IsActive())
                                {
                                    Filters.Scene.Deactivate("GradualGreenShader");
                                }
                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                {
                                    SpellTimer = 0;
                                    SwitchTo(NState.Kill);
                                }
                            }
                            break;
                        }
                    case NState.Kill:
                        {
                            if (Main.netMode != NetmodeID.MultiplayerClient)
                            {
                                NPC.NewNPC(NPC.GetSource_FromAI(), (int)NPC.Center.X + 800, (int)NPC.Center.Y - 800, ModContent.NPCType<MeleeMoon>());
                            }
                            NPC.life = 0;
                            NPC.checkDead();
                            break;
                        }
                }
            }
        }

        public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
        {
            if (State == NState.Countdown)
            {
                string Countdown = (Language.ActiveCulture.Name == "zh-Hans" ? "剩余时间：" : "Timeleft: ") + (30 - (SpellTimer - SpellTimer % 60) / 60) + (Language.ActiveCulture.Name == "zh-Hans" ? " 秒" : " Seconds");
                Color stringcolor = new Color((int)(255 * (float)((float)(1800f - SpellTimer) / 1800f)), 255, (int)(255 * (float)((float)(1800f - SpellTimer) / 1800f)));
                if (Vector2.Distance(Main.LocalPlayer.Center, NPC.Center) <= 1500f)
                {
                    Vector2 stringpos = Main.LocalPlayer.Center - new Vector2(160, -10 + Main.screenHeight / 2) - Main.screenPosition;
                    Utils.DrawBorderString(Main.spriteBatch, Countdown, stringpos, stringcolor, 2f);
                }
            }
            return true;
        }
    }
}