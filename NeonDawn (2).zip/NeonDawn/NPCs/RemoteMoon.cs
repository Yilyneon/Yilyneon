﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Common.Systems;
using NeonDawn.Projs.Bosses;

using System;
using System.Collections.Generic;

using Terraria;
using Terraria.DataStructures;
using Terraria.GameContent.Bestiary;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace NeonDawn.NPCs
{
    public class RemoteMoon : ModNPC
    {
        private NPC Moon => MeleeMoon.MMoon;//register a NPC and bind to the Melee moon's static variable. => means it will be re-bound each time the NPC is used

        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault(DownedBossSystem.downedSatellite1 ? "Lost Satellite B" : "Klios Satellite");
            //DisplayName.AddTranslation((int)GameCulture.CultureName.Chinese, DownedBossSystem.downedSatellite1 ? "失落卫星B" : "克利俄斯号卫星");
            Main.npcFrameCount[NPC.type] = 1;
            var drawModifier = new NPCID.Sets.NPCBestiaryDrawModifiers(0)
            {
                CustomTexturePath = "NeonDawn/NPCs/RemoteMoon",
                Position = new Vector2(0f, 0f),
                PortraitPositionXOverride = 0f,
                PortraitPositionYOverride = 0f
            };
            NPCID.Sets.NPCBestiaryDrawOffset.Add(NPC.type, drawModifier);
            NPCID.Sets.TrailCacheLength[NPC.type] = 32;
            NPCID.Sets.TrailingMode[NPC.type] = 3;
            NPCDebuffImmunityData debuffData = new NPCDebuffImmunityData
            {
                ImmuneToAllBuffsThatAreNotWhips = true,
                ImmuneToWhips = false
            };
        }

        public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
        {
            string text = "English trans for Lost Satellite B here";
            if (Language.ActiveCulture.Name == "zh-Hans")
            {
                text = "失落卫星B的图鉴描述填在这里";
            }
            bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[]
            {
                BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Surface,
                BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Times.NightTime,//When and where do you want to summon the boss
                new FlavorTextBestiaryInfoElement(text)
            });
        }

        public override void SetDefaults()
        {
            NPC.damage = 0;
            NPC.width = 138;
            NPC.height = 62;
            NPC.defense = Main.expertMode ? (Main.masterMode ? 25 : 15) : 10;
            NPC.lifeMax = 10000;
            NPC.knockBackResist = 0f;
            NPC.dontTakeDamage = true;
            NPC.value = Item.buyPrice(0, 2, 0, 0);
            NPC.aiStyle = -1;
            NPC.boss = true;
            NPC.lavaImmune = true;
            NPC.noGravity = true;
            NPC.noTileCollide = true;
            NPCID.Sets.TrailCacheLength[NPC.type] = 32;
            NPCID.Sets.TrailingMode[NPC.type] = 3;
            NPC.netUpdate = true;
            NPC.netUpdate2 = true;
            NPC.netAlways = true;
            if (!Main.dedServ)
            {
                Music = MusicLoader.GetMusicSlot(Mod, "Sounds/Music/MoomFightOne");
            }
        }

        public NPC owner;//register its owner as an NPC

        public float SatelliteBTimer
        {
            get => NPC.ai[1];
            set => NPC.ai[1] = value;
        }

        public float RestrictionRadius//this variable I registered is for its restriction circle's radius
        {
            get => NPC.ai[2];
            set => NPC.ai[2] = value;
        }

        public override void AI()
        {
            Lighting.AddLight(NPC.Center, 1, 1, 1);//Add light to let it visable at night
            owner = Main.npc[NPC.realLife];//bind the NPC of its realLife to the owner variable
            if (!owner.active || owner.life < 1)
            {
                NPC.life = 0;
                NPC.checkDead();
            }//kill it if the "owner" dies or disappears anyway
            else
            {
                SatelliteBTimer++;
                NPC.timeLeft++;
                if (Main.netMode != NetmodeID.MultiplayerClient)
                {
                    if (owner != null && owner.active)//check if the melee moon is alive as normal
                    {
                        if (Main.player[owner.target] != null)
                        {
                            NPC.target = owner.target;
                        }//sync its target with the owner's
                        if (owner.ai[1] <= 100)
                        {
                            RestrictionRadius = Math.Min(SatelliteBTimer * 10f, 1400f);
                        }//first increase the radius to 800f(800 pix for the circle's radius)
                        else
                        {
                            if (owner.ai[0] != 5 && owner.ai[0] != 4)
                            {
                                if (owner.ai[0] != 0)
                                {
                                    if (!((MeleeMoon)Moon.ModNPC).Enraged)
                                    {
                                        if (SatelliteBTimer % 600 < 240)
                                        {
                                            if (Main.netMode != NetmodeID.MultiplayerClient)
                                            {
                                                NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .1f);
                                            }
                                        }
                                        else
                                        {
                                            if (SatelliteBTimer % 600 < 300)
                                            {
                                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                                {
                                                    NPC.rotation = MathHelper.Lerp(NPC.rotation, (Main.player[NPC.target].Center - NPC.Center).ToRotation() - MathHelper.PiOver2, .1f);
                                                }
                                            }
                                            if (SatelliteBTimer % 600 == 360)
                                            {
                                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                                {
                                                    Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, Vector2.Zero, ModContent.ProjectileType<MeleeMoonLaser>(), Main.expertMode ? (Main.masterMode ? 12 : 28) : 40, .05f, Main.myPlayer, NPC.whoAmI);
                                                }
                                            }
                                            if (SatelliteBTimer % 600 > 360 && SatelliteBTimer % 10 == 0)
                                            {
                                                for (float r = 10; r <= 360; r += 10)
                                                {
                                                    Vector2 dPos = NPC.Center + new Vector2((float)Math.Cos(MathHelper.ToRadians(r)) * 4f, -30f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                                    Vector2 dVel = new Vector2(3f * (float)Math.Cos(MathHelper.ToRadians(r)), 2f * (float)Math.Sin(MathHelper.ToRadians(r)) - 4f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                                    Dust dust = Dust.NewDustDirect(dPos, 1, 1, DustID.GreenTorch);
                                                    dust.noGravity = true;
                                                    dust.velocity = dVel;
                                                    dust.scale = 1.2f;
                                                    dust.fadeIn = .6f;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (!Main.dedServ)
                                        {
                                            Music = MusicLoader.GetMusicSlot(Mod, "Sounds/Music/MoomFightTwo");
                                        }
                                        if (SatelliteBTimer % 480 < 120)
                                        {
                                            if (Main.netMode != NetmodeID.MultiplayerClient)
                                            {
                                                NPC.rotation = MathHelper.Lerp(NPC.rotation, 0, .1f);
                                            }
                                        }
                                        else
                                        {
                                            if (SatelliteBTimer % 480 < 180)
                                            {
                                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                                {
                                                    NPC.rotation = MathHelper.Lerp(NPC.rotation, (Main.player[NPC.target].Center - NPC.Center).ToRotation() - MathHelper.PiOver2, .1f);
                                                }
                                            }
                                            if (SatelliteBTimer % 480 == 240)
                                            {
                                                if (Main.netMode != NetmodeID.MultiplayerClient)
                                                {
                                                    Projectile.NewProjectile(NPC.GetSource_FromAI(), NPC.Center, Vector2.Zero, ModContent.ProjectileType<MeleeMoonLaser>(), Main.expertMode ? (Main.masterMode ? 12 : 28) : 40, .05f, Main.myPlayer, NPC.whoAmI);
                                                }
                                            }
                                            if (SatelliteBTimer % 480 > 240 && SatelliteBTimer % 10 == 0)
                                            {
                                                for (float r = 10; r <= 360; r += 10)
                                                {
                                                    Vector2 dPos = NPC.Center + new Vector2((float)Math.Cos(MathHelper.ToRadians(r)) * 4f, -30f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                                    Vector2 dVel = new Vector2(3f * (float)Math.Cos(MathHelper.ToRadians(r)), 2f * (float)Math.Sin(MathHelper.ToRadians(r)) - 4f).RotatedBy(NPC.rotation - MathHelper.ToRadians(180));
                                                    Dust dust = Dust.NewDustDirect(dPos, 1, 1, DustID.GreenTorch);
                                                    dust.noGravity = true;
                                                    dust.velocity = dVel;
                                                    dust.scale = 1.2f;
                                                    dust.fadeIn = .6f;
                                                }
                                            }
                                        }
                                    }
                                }
                                if (((MeleeMoon)Moon.ModNPC).Enraged)
                                {
                                    RestrictionRadius -= .2f;
                                }
                                else
                                {
                                    RestrictionRadius = 1400f;
                                }
                            }//if the melee moon's state is not "Death" then check if its state is "Enraged". if not keep the radius at 800f, else let it decrease to 400f.
                            if (owner.ai[0] == 5)
                            {
                                RestrictionRadius -= 4;
                            }//if the melee moons state is "Death", decrease the radius to 0
                        }
                    }
                }
                if (Main.netMode != NetmodeID.Server)
                {
                    if (RestrictionRadius > 700f)//judge if the radius is large enough, if it is then carry out the following codes to drag people that try to escape back in the restriction circle.
                    {
                        Player player = Main.LocalPlayer;//the code just runs on player client rather than server client
                        if (Vector2.Distance(NPC.Center, player.Center) <= 1800f)//this can be adjusted, its target is not to affect people far away from the battle that's doing something else
                        {
                            if (Vector2.Distance(NPC.Center, player.Center) > RestrictionRadius)
                            {
                                for (int k = 1; k <= 4; k++)//playing dusts when dragging people back
                                {
                                    Dust dust = Dust.NewDustDirect(player.position, player.width, player.height, DustID.GreenTorch);
                                    dust.noGravity = true;
                                    dust.velocity = Vector2.Normalize(NPC.Center - player.Center) * -7.5f;
                                    dust.scale = 2f;
                                }
                                player.Center -= Vector2.Normalize(player.Center - NPC.Center) * 12f;
                                player.velocity = Vector2.Normalize(player.Center - NPC.Center) * -1f;
                                player.gravity = 0f;
                                player.itemTime = player.HeldItem.useTime - 1;
                                player.statLife -= 1;//drag people that escape out of the circle back in, while disables them using items and constantly losing health
                                if (player.statLife <= 0)
                                {
                                    string text = Language.ActiveCulture.Name == "zh-Hans" ? "试图逃跑。" : " tried to escape.";
                                    player.KillMe(PlayerDeathReason.ByCustomReason(player.name + text), 9999, 0, false);
                                }//the decrease on statLife will not kill the player even if their health drop below zero.So there requires a check for the dragged people's health, and kill them if that drops below 0.
                            }
                        }
                    }
                }
            }
        }

        public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
        {
            if (owner != null && Main.player[NPC.target] != null)
            {
                List<VertexInfo2> vertices = new List<VertexInfo2>();//declare that this drawing part requires vertex things
                Vector2 BossCenter = NPC.Center;
                for (float r = 0; r <= 360; r += 1)//0 degree to 360 degree as a circle
                {
                    vertices.Add(new VertexInfo2(BossCenter - Main.screenPosition + MathHelper.ToRadians(r + owner.ai[1] * 2f).ToRotationVector2() * (float)Math.Max(RestrictionRadius - 50f, 0), new Vector3(r / 360f, 0f, 1 - r / 360f), Color.Green * (RestrictionRadius / 900f * (.33f + .66f * (r / 360f)))));
                    vertices.Add(new VertexInfo2(BossCenter - Main.screenPosition + MathHelper.ToRadians(r + owner.ai[1] * 2f).ToRotationVector2() * (RestrictionRadius + 50f), new Vector3(r / 360f, 1f, 1 - r / 360f), Color.Green * (RestrictionRadius / 900f * (.33f + .66f * (r / 360f)))));
                }// for each degree I pass a pair of parameters to the vertexInfo2.
                 //each of the parameter includes 3 parts:position where you want to draw on screen, Vector3 which stands for the corrosponding point in the texture of the position you passed, and the color.
                 //the two positions undoubtly should be the NPC's center + degree-to-Vector2 then multiply the radius +/- 50f, for the radius should not be below zero, you should judge if the radius-50f is below  zero or not.
                spriteBatch.End();
                spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.Additive, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);//switch the BlendState to Additive, and pay attention to the SpriteSortMode should be Immediate.
                Main.graphics.GraphicsDevice.Textures[0] = ModContent.Request<Texture2D>("NeonDawn/Textures/Ex/Ex1").Value;//get the texture
                if (vertices.Count >= 3)//judge if there's 3 positions next to each other that can be connected into a triangle and be drawn.
                {
                    Main.graphics.GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleStrip, vertices.ToArray(), 0, vertices.Count - 2);//if yes, draw the triangle, for there should be just one triangle so the count should be (3-2) which is vertices.Count -2.
                }
                spriteBatch.End();
                spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend, SamplerState.AnisotropicClamp, DepthStencilState.None, RasterizerState.CullNone, null, Main.GameViewMatrix.TransformationMatrix);//switch the BlendState back to AlphaBlend.
                spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/NPCs/RemoteMoon").Value, NPC.Center - Main.screenPosition, null, Color.White, NPC.rotation, new Vector2(NPC.width / 2, NPC.height / 2), 1f, (NPC.rotation >= MathHelper.PiOver2 || NPC.rotation <= -MathHelper.PiOver2) ? SpriteEffects.FlipVertically : SpriteEffects.None, 0f);
            }
            return false;
        }

        public override bool CheckDead()
        {
            owner = Main.npc[NPC.realLife];
            if (!owner.active || owner == null)
            {
                return true;
            }
            return false;
        }
    }
}