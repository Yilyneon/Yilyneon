﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using Terraria;
using Terraria.ModLoader;
using NeonDawn.Items.Weapon.Melee;

namespace NeonDawn
{
    public class NeonDawnGlobalNPC : GlobalNPC
    {
		public override bool InstancePerEntity { get { return true; } }
        public override void ModifyGlobalLoot(GlobalLoot globalLoot)
        {
            if (Main.hardMode)
            {


            }

        }
    }
}
