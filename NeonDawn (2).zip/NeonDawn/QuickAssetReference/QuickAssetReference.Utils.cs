using Terraria.ModLoader;

namespace NeonDawn.QuickAssetReference;
public static class ModAssets_Utils
{
    public static Mod Mod => ModLoader.GetMod("NeonDawn");
}
