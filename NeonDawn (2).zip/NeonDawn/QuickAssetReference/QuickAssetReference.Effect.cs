using ReLogic.Content;
using Microsoft.Xna.Framework.Graphics;

namespace NeonDawn.QuickAssetReference;
public static class ModAssets_Effect
{
    public static Asset<Effect> GradualGreenShaderAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(GradualGreenShaderPath);
    public static Asset<Effect> GradualGreenShaderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(GradualGreenShaderPath, AssetRequestMode.ImmediateLoad);
    public const string GradualGreenShaderPath = "Effects/GradualGreenShader";
    public static Asset<Effect> GreenShaderAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(GreenShaderPath);
    public static Asset<Effect> GreenShaderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(GreenShaderPath, AssetRequestMode.ImmediateLoad);
    public const string GreenShaderPath = "Effects/GreenShader";
    public static Asset<Effect> NameShaderAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(NameShaderPath);
    public static Asset<Effect> NameShaderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(NameShaderPath, AssetRequestMode.ImmediateLoad);
    public const string NameShaderPath = "Effects/NameShader";
    public static Asset<Effect> RedShaderAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(RedShaderPath);
    public static Asset<Effect> RedShaderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Effect>(RedShaderPath, AssetRequestMode.ImmediateLoad);
    public const string RedShaderPath = "Effects/RedShader";
}

