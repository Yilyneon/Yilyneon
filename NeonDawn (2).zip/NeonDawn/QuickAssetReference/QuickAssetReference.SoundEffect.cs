using ReLogic.Content;
using Microsoft.Xna.Framework.Audio;

namespace NeonDawn.QuickAssetReference;
public static class ModAssets_SoundEffect
{
    public static class Items
    {
        public static Asset<SoundEffect> _8bitattackAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitattackPath);
        public static Asset<SoundEffect> _8bitattackImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitattackPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitattackPath = "Sounds/Items/8bitattack";
        public static Asset<SoundEffect> _8bitdeadAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitdeadPath);
        public static Asset<SoundEffect> _8bitdeadImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitdeadPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitdeadPath = "Sounds/Items/8bitdead";
        public static Asset<SoundEffect> _8bithighscoreAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bithighscorePath);
        public static Asset<SoundEffect> _8bithighscoreImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bithighscorePath, AssetRequestMode.ImmediateLoad);
        public const string _8bithighscorePath = "Sounds/Items/8bithighscore";
        public static Asset<SoundEffect> _8bitlowhealthAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitlowhealthPath);
        public static Asset<SoundEffect> _8bitlowhealthImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitlowhealthPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitlowhealthPath = "Sounds/Items/8bitlowhealth";
        public static Asset<SoundEffect> _8bitlowmanaAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitlowmanaPath);
        public static Asset<SoundEffect> _8bitlowmanaImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitlowmanaPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitlowmanaPath = "Sounds/Items/8bitlowmana";
        public static Asset<SoundEffect> _8bitSpawnAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitSpawnPath);
        public static Asset<SoundEffect> _8bitSpawnImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitSpawnPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitSpawnPath = "Sounds/Items/8bitSpawn";
        public static Asset<SoundEffect> _8bitspecialAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitspecialPath);
        public static Asset<SoundEffect> _8bitspecialImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(_8bitspecialPath, AssetRequestMode.ImmediateLoad);
        public const string _8bitspecialPath = "Sounds/Items/8bitspecial";
        public static Asset<SoundEffect> GraniteGunShootAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(GraniteGunShootPath);
        public static Asset<SoundEffect> GraniteGunShootImmediateAsset => ModAssets_Utils.Mod.Assets.Request<SoundEffect>(GraniteGunShootPath, AssetRequestMode.ImmediateLoad);
        public const string GraniteGunShootPath = "Sounds/Items/GraniteGunShoot";
    }

}

