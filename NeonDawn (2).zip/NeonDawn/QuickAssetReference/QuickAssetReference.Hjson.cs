namespace NeonDawn.QuickAssetReference;
public static class ModAssets_Hjson
{
    public static class Items
    {
        public static class KokomiArmor
        {
            public const string DisplayName = "Items.KokomiArmor.DisplayName";
            public const string Tooltip = "Items.KokomiArmor.Tooltip";
        }

        public static class KokomiHead
        {
            public const string DisplayName = "Items.KokomiHead.DisplayName";
            public const string Tooltip = "Items.KokomiHead.Tooltip";
        }

        public static class KokomiLegs
        {
            public const string DisplayName = "Items.KokomiLegs.DisplayName";
            public const string Tooltip = "Items.KokomiLegs.Tooltip";
        }

        public static class EnterVoucher
        {
            public const string DisplayName = "Items.EnterVoucher.DisplayName";
            public const string Tooltip = "Items.EnterVoucher.Tooltip";
        }

        public static class start
        {
            public const string DisplayName = "Items.start.DisplayName";
            public const string Tooltip = "Items.start.Tooltip";
        }

        public static class Satellites
        {
            public const string DisplayName = "Items.Satellites.DisplayName";
            public const string Tooltip = "Items.Satellites.Tooltip";
        }

        public static class BeanSand
        {
            public const string DisplayName = "Items.BeanSand.DisplayName";
            public const string Tooltip = "Items.BeanSand.Tooltip";
        }

        public static class Fiveren
        {
            public const string DisplayName = "Items.Fiveren.DisplayName";
            public const string Tooltip = "Items.Fiveren.Tooltip";
        }

        public static class MooncakeYoyo
        {
            public const string DisplayName = "Items.MooncakeYoyo.DisplayName";
            public const string Tooltip = "Items.MooncakeYoyo.Tooltip";
        }

        public static class Yolk
        {
            public const string DisplayName = "Items.Yolk.DisplayName";
            public const string Tooltip = "Items.Yolk.Tooltip";
        }

        public static class Miracleheart
        {
            public const string DisplayName = "Items.Miracleheart.DisplayName";
            public const string Tooltip = "Items.Miracleheart.Tooltip";
        }

        public static class WhiteMana
        {
            public const string DisplayName = "Items.WhiteMana.DisplayName";
            public const string Tooltip = "Items.WhiteMana.Tooltip";
        }

        public static class Activecellspheres
        {
            public const string DisplayName = "Items.Activecellspheres.DisplayName";
            public const string Tooltip = "Items.Activecellspheres.Tooltip";
        }

        public static class Magiccondensate
        {
            public const string DisplayName = "Items.Magiccondensate.DisplayName";
            public const string Tooltip = "Items.Magiccondensate.Tooltip";
        }

        public static class MagicGel
        {
            public const string DisplayName = "Items.MagicGel.DisplayName";
            public const string Tooltip = "Items.MagicGel.Tooltip";
        }

        public static class Scrap
        {
            public const string DisplayName = "Items.Scrap.DisplayName";
            public const string Tooltip = "Items.Scrap.Tooltip";
        }

        public static class ExtractTableItem
        {
            public const string DisplayName = "Items.ExtractTableItem.DisplayName";
            public const string Tooltip = "Items.ExtractTableItem.Tooltip";
        }

        public static class ui
        {
            public const string DisplayName = "Items.ui.DisplayName";
            public const string Tooltip = "Items.ui.Tooltip";
        }

        public static class G
        {
            public const string DisplayName = "Items.G.DisplayName";
            public const string Tooltip = "Items.G.Tooltip";
        }

        public static class VIIILaserGun
        {
            public const string DisplayName = "Items.VIIILaserGun.DisplayName";
            public const string Tooltip = "Items.VIIILaserGun.Tooltip";
        }

        public static class Hollyknight
        {
            public const string DisplayName = "Items.Hollyknight.DisplayName";
            public const string Tooltip = "Items.Hollyknight.Tooltip";
        }

        public static class Newknife
        {
            public const string DisplayName = "Items.Newknife.DisplayName";
            public const string Tooltip = "Items.Newknife.Tooltip";
        }

        public static class TheGlory
        {
            public const string DisplayName = "Items.TheGlory.DisplayName";
            public const string Tooltip = "Items.TheGlory.Tooltip";
        }

        public static class GraniteGun
        {
            public const string DisplayName = "Items.GraniteGun.DisplayName";
            public const string Tooltip = "Items.GraniteGun.Tooltip";
        }

        public static class PhoenixBlasterRemake
        {
            public const string DisplayName = "Items.PhoenixBlasterRemake.DisplayName";
            public const string Tooltip = "Items.PhoenixBlasterRemake.Tooltip";
        }

        public static class VenusMagnumRemake
        {
            public const string DisplayName = "Items.VenusMagnumRemake.DisplayName";
            public const string Tooltip = "Items.VenusMagnumRemake.Tooltip";
        }

    }

    public static class NPCs
    {
        public static class MeleeMoon
        {
            public const string DisplayName = "NPCs.MeleeMoon.DisplayName";
        }

        public static class RemoteMoon
        {
            public const string DisplayName = "NPCs.RemoteMoon.DisplayName";
        }

        public static class SatelliteSmall
        {
            public const string DisplayName = "NPCs.SatelliteSmall.DisplayName";
        }

    }

    public static class Projectiles
    {
        public static class Greenproj
        {
            public const string DisplayName = "Projectiles.Greenproj.DisplayName";
        }

        public static class MeleeMoonLaser
        {
            public const string DisplayName = "Projectiles.MeleeMoonLaser.DisplayName";
        }

        public static class MoonLaser
        {
            public const string DisplayName = "Projectiles.MoonLaser.DisplayName";
        }

        public static class MoonRocket
        {
            public const string DisplayName = "Projectiles.MoonRocket.DisplayName";
        }

        public static class MooncakeYoyoProj
        {
            public const string DisplayName = "Projectiles.MooncakeYoyoProj.DisplayName";
        }

        public static class ScrapMedium
        {
            public const string DisplayName = "Projectiles.ScrapMedium.DisplayName";
        }

        public static class ScrapSmall
        {
            public const string DisplayName = "Projectiles.ScrapSmall.DisplayName";
        }

        public static class VIIILaserGunPro
        {
            public const string DisplayName = "Projectiles.VIIILaserGunPro.DisplayName";
        }

        public static class HitEffect
        {
            public const string DisplayName = "Projectiles.HitEffect.DisplayName";
        }

        public static class Knifeproj
        {
            public const string DisplayName = "Projectiles.Knifeproj.DisplayName";
        }

        public static class Newknifep
        {
            public const string DisplayName = "Projectiles.Newknifep.DisplayName";
        }

        public static class TheGloryp
        {
            public const string DisplayName = "Projectiles.TheGloryp.DisplayName";
        }

        public static class TheGloryPro
        {
            public const string DisplayName = "Projectiles.TheGloryPro.DisplayName";
        }

        public static class TheGloryPro2
        {
            public const string DisplayName = "Projectiles.TheGloryPro2.DisplayName";
        }

        public static class CapsuleExplosion
        {
            public const string DisplayName = "Projectiles.CapsuleExplosion.DisplayName";
        }

        public static class SpaceCapsule
        {
            public const string DisplayName = "Projectiles.SpaceCapsule.DisplayName";
        }

        public static class Startproj
        {
            public const string DisplayName = "Projectiles.Startproj.DisplayName";
        }

        public static class GraniteGun_Pro
        {
            public const string DisplayName = "Projectiles.GraniteGun_Pro.DisplayName";
        }

    }

    public static class Configs
    {
        public static class NeonConfig
        {
            public const string DisplayName = "Configs.NeonConfig.DisplayName";
            public static class eyeseffectOpen
            {
                public const string Label = "Configs.NeonConfig.eyeseffectOpen.Label";
                public const string Tooltip = "Configs.NeonConfig.eyeseffectOpen.Tooltip";
            }

        }

    }

}

