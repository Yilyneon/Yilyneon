using ReLogic.Content;
using ReLogic.Graphics;

namespace NeonDawn.QuickAssetReference;
public static class ModAssets_Font
{
    public static class Fonts
    {
        public static Asset<DynamicSpriteFont> SourceHanSansFontAsset => ModAssets_Utils.Mod.Assets.Request<DynamicSpriteFont>(SourceHanSansFontPath);
        public static Asset<DynamicSpriteFont> SourceHanSansFontImmediateAsset => ModAssets_Utils.Mod.Assets.Request<DynamicSpriteFont>(SourceHanSansFontPath, AssetRequestMode.ImmediateLoad);
        public const string SourceHanSansFontPath = "Fonts/SourceHanSansFont.xnb";
        public static Asset<DynamicSpriteFont> ZhengQingkeButterBodyFontAsset => ModAssets_Utils.Mod.Assets.Request<DynamicSpriteFont>(ZhengQingkeButterBodyFontPath);
        public static Asset<DynamicSpriteFont> ZhengQingkeButterBodyFontImmediateAsset => ModAssets_Utils.Mod.Assets.Request<DynamicSpriteFont>(ZhengQingkeButterBodyFontPath, AssetRequestMode.ImmediateLoad);
        public const string ZhengQingkeButterBodyFontPath = "Fonts/ZhengQingkeButterBodyFont.xnb";
    }

}

