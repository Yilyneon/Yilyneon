using ReLogic.Content;
using Microsoft.Xna.Framework.Graphics;

namespace NeonDawn.QuickAssetReference;
public static class ModAssets_Texture2D
{
    public static Asset<Texture2D> iconAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(iconPath);
    public static Asset<Texture2D> iconImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(iconPath, AssetRequestMode.ImmediateLoad);
    public const string iconPath = "icon";
    public static Asset<Texture2D> icon_smallAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(icon_smallPath);
    public static Asset<Texture2D> icon_smallImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(icon_smallPath, AssetRequestMode.ImmediateLoad);
    public const string icon_smallPath = "icon_small";
    public static Asset<Texture2D> logoAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(logoPath);
    public static Asset<Texture2D> logoImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(logoPath, AssetRequestMode.ImmediateLoad);
    public const string logoPath = "logo";
    public static Asset<Texture2D> Moon_8Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Moon_8Path);
    public static Asset<Texture2D> Moon_8ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Moon_8Path, AssetRequestMode.ImmediateLoad);
    public const string Moon_8Path = "Moon_8";
    public static Asset<Texture2D> NeonDawnSunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NeonDawnSunPath);
    public static Asset<Texture2D> NeonDawnSunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NeonDawnSunPath, AssetRequestMode.ImmediateLoad);
    public const string NeonDawnSunPath = "NeonDawnSun";
    public static class Backgrounds
    {
        public static Asset<Texture2D> BiomeSurfaceCloseAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceClosePath);
        public static Asset<Texture2D> BiomeSurfaceCloseImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceClosePath, AssetRequestMode.ImmediateLoad);
        public const string BiomeSurfaceClosePath = "Backgrounds/BiomeSurfaceClose";
        public static Asset<Texture2D> BiomeSurfaceFarAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceFarPath);
        public static Asset<Texture2D> BiomeSurfaceFarImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceFarPath, AssetRequestMode.ImmediateLoad);
        public const string BiomeSurfaceFarPath = "Backgrounds/BiomeSurfaceFar";
        public static Asset<Texture2D> BiomeSurfaceMid13Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceMid13Path);
        public static Asset<Texture2D> BiomeSurfaceMid13ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BiomeSurfaceMid13Path, AssetRequestMode.ImmediateLoad);
        public const string BiomeSurfaceMid13Path = "Backgrounds/BiomeSurfaceMid13";
        public static Asset<Texture2D> CloudSurfaceClose_MenuAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceClose_MenuPath);
        public static Asset<Texture2D> CloudSurfaceClose_MenuImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceClose_MenuPath, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceClose_MenuPath = "Backgrounds/CloudSurfaceClose_Menu";
        public static Asset<Texture2D> CloudSurfaceFar_MenuAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceFar_MenuPath);
        public static Asset<Texture2D> CloudSurfaceFar_MenuImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceFar_MenuPath, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceFar_MenuPath = "Backgrounds/CloudSurfaceFar_Menu";
        public static Asset<Texture2D> CloudSurfaceMid0Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid0Path);
        public static Asset<Texture2D> CloudSurfaceMid0ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid0Path, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceMid0Path = "Backgrounds/CloudSurfaceMid0";
        public static Asset<Texture2D> CloudSurfaceMid3Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid3Path);
        public static Asset<Texture2D> CloudSurfaceMid3ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid3Path, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceMid3Path = "Backgrounds/CloudSurfaceMid3";
        public static Asset<Texture2D> CloudSurfaceMid4_MenuAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid4_MenuPath);
        public static Asset<Texture2D> CloudSurfaceMid4_MenuImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid4_MenuPath, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceMid4_MenuPath = "Backgrounds/CloudSurfaceMid4_Menu";
        public static Asset<Texture2D> CloudSurfaceMid_MenuAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid_MenuPath);
        public static Asset<Texture2D> CloudSurfaceMid_MenuImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CloudSurfaceMid_MenuPath, AssetRequestMode.ImmediateLoad);
        public const string CloudSurfaceMid_MenuPath = "Backgrounds/CloudSurfaceMid_Menu";
    }

    public static class Effects
    {
        public static Asset<Texture2D> EightbitAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EightbitPath);
        public static Asset<Texture2D> EightbitImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EightbitPath, AssetRequestMode.ImmediateLoad);
        public const string EightbitPath = "Effects/Eightbit";
        public static Asset<Texture2D> LightAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightPath);
        public static Asset<Texture2D> LightImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightPath, AssetRequestMode.ImmediateLoad);
        public const string LightPath = "Effects/Light";
        public static Asset<Texture2D> LightTransparentAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightTransparentPath);
        public static Asset<Texture2D> LightTransparentImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightTransparentPath, AssetRequestMode.ImmediateLoad);
        public const string LightTransparentPath = "Effects/LightTransparent";
        public static Asset<Texture2D> Ray3Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Ray3Path);
        public static Asset<Texture2D> Ray3ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Ray3Path, AssetRequestMode.ImmediateLoad);
        public const string Ray3Path = "Effects/Ray3";
        public static Asset<Texture2D> SparkAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SparkPath);
        public static Asset<Texture2D> SparkImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SparkPath, AssetRequestMode.ImmediateLoad);
        public const string SparkPath = "Effects/Spark";
        public static Asset<Texture2D> StartAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(StartPath);
        public static Asset<Texture2D> StartImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(StartPath, AssetRequestMode.ImmediateLoad);
        public const string StartPath = "Effects/Start";
        public static Asset<Texture2D> VoidStarAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VoidStarPath);
        public static Asset<Texture2D> VoidStarImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VoidStarPath, AssetRequestMode.ImmediateLoad);
        public const string VoidStarPath = "Effects/VoidStar";
    }

    public static class Gores
    {
        public static class SpaceCapsule
        {
            public static Asset<Texture2D> SpaceCapsuleGore1Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore1Path);
            public static Asset<Texture2D> SpaceCapsuleGore1ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore1Path, AssetRequestMode.ImmediateLoad);
            public const string SpaceCapsuleGore1Path = "Gores/SpaceCapsule/SpaceCapsuleGore1";
            public static Asset<Texture2D> SpaceCapsuleGore2Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore2Path);
            public static Asset<Texture2D> SpaceCapsuleGore2ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore2Path, AssetRequestMode.ImmediateLoad);
            public const string SpaceCapsuleGore2Path = "Gores/SpaceCapsule/SpaceCapsuleGore2";
            public static Asset<Texture2D> SpaceCapsuleGore3Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore3Path);
            public static Asset<Texture2D> SpaceCapsuleGore3ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore3Path, AssetRequestMode.ImmediateLoad);
            public const string SpaceCapsuleGore3Path = "Gores/SpaceCapsule/SpaceCapsuleGore3";
            public static Asset<Texture2D> SpaceCapsuleGore4Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore4Path);
            public static Asset<Texture2D> SpaceCapsuleGore4ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsuleGore4Path, AssetRequestMode.ImmediateLoad);
            public const string SpaceCapsuleGore4Path = "Gores/SpaceCapsule/SpaceCapsuleGore4";
        }

    }

    public static class Icons
    {
        public static Asset<Texture2D> Frameicon0Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon0Path);
        public static Asset<Texture2D> Frameicon0ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon0Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon0Path = "Icons/Frameicon0";
        public static Asset<Texture2D> Frameicon1Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon1Path);
        public static Asset<Texture2D> Frameicon1ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon1Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon1Path = "Icons/Frameicon1";
        public static Asset<Texture2D> Frameicon10Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon10Path);
        public static Asset<Texture2D> Frameicon10ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon10Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon10Path = "Icons/Frameicon10";
        public static Asset<Texture2D> Frameicon11Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon11Path);
        public static Asset<Texture2D> Frameicon11ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon11Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon11Path = "Icons/Frameicon11";
        public static Asset<Texture2D> Frameicon12Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon12Path);
        public static Asset<Texture2D> Frameicon12ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon12Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon12Path = "Icons/Frameicon12";
        public static Asset<Texture2D> Frameicon13Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon13Path);
        public static Asset<Texture2D> Frameicon13ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon13Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon13Path = "Icons/Frameicon13";
        public static Asset<Texture2D> Frameicon14Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon14Path);
        public static Asset<Texture2D> Frameicon14ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon14Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon14Path = "Icons/Frameicon14";
        public static Asset<Texture2D> Frameicon15Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon15Path);
        public static Asset<Texture2D> Frameicon15ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon15Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon15Path = "Icons/Frameicon15";
        public static Asset<Texture2D> Frameicon16Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon16Path);
        public static Asset<Texture2D> Frameicon16ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon16Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon16Path = "Icons/Frameicon16";
        public static Asset<Texture2D> Frameicon17Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon17Path);
        public static Asset<Texture2D> Frameicon17ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon17Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon17Path = "Icons/Frameicon17";
        public static Asset<Texture2D> Frameicon18Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon18Path);
        public static Asset<Texture2D> Frameicon18ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon18Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon18Path = "Icons/Frameicon18";
        public static Asset<Texture2D> Frameicon19Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon19Path);
        public static Asset<Texture2D> Frameicon19ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon19Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon19Path = "Icons/Frameicon19";
        public static Asset<Texture2D> Frameicon2Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon2Path);
        public static Asset<Texture2D> Frameicon2ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon2Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon2Path = "Icons/Frameicon2";
        public static Asset<Texture2D> Frameicon20Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon20Path);
        public static Asset<Texture2D> Frameicon20ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon20Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon20Path = "Icons/Frameicon20";
        public static Asset<Texture2D> Frameicon21Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon21Path);
        public static Asset<Texture2D> Frameicon21ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon21Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon21Path = "Icons/Frameicon21";
        public static Asset<Texture2D> Frameicon22Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon22Path);
        public static Asset<Texture2D> Frameicon22ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon22Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon22Path = "Icons/Frameicon22";
        public static Asset<Texture2D> Frameicon23Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon23Path);
        public static Asset<Texture2D> Frameicon23ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon23Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon23Path = "Icons/Frameicon23";
        public static Asset<Texture2D> Frameicon24Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon24Path);
        public static Asset<Texture2D> Frameicon24ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon24Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon24Path = "Icons/Frameicon24";
        public static Asset<Texture2D> Frameicon25Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon25Path);
        public static Asset<Texture2D> Frameicon25ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon25Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon25Path = "Icons/Frameicon25";
        public static Asset<Texture2D> Frameicon26Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon26Path);
        public static Asset<Texture2D> Frameicon26ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon26Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon26Path = "Icons/Frameicon26";
        public static Asset<Texture2D> Frameicon27Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon27Path);
        public static Asset<Texture2D> Frameicon27ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon27Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon27Path = "Icons/Frameicon27";
        public static Asset<Texture2D> Frameicon28Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon28Path);
        public static Asset<Texture2D> Frameicon28ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon28Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon28Path = "Icons/Frameicon28";
        public static Asset<Texture2D> Frameicon29Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon29Path);
        public static Asset<Texture2D> Frameicon29ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon29Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon29Path = "Icons/Frameicon29";
        public static Asset<Texture2D> Frameicon3Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon3Path);
        public static Asset<Texture2D> Frameicon3ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon3Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon3Path = "Icons/Frameicon3";
        public static Asset<Texture2D> Frameicon30Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon30Path);
        public static Asset<Texture2D> Frameicon30ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon30Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon30Path = "Icons/Frameicon30";
        public static Asset<Texture2D> Frameicon31Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon31Path);
        public static Asset<Texture2D> Frameicon31ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon31Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon31Path = "Icons/Frameicon31";
        public static Asset<Texture2D> Frameicon32Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon32Path);
        public static Asset<Texture2D> Frameicon32ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon32Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon32Path = "Icons/Frameicon32";
        public static Asset<Texture2D> Frameicon33Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon33Path);
        public static Asset<Texture2D> Frameicon33ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon33Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon33Path = "Icons/Frameicon33";
        public static Asset<Texture2D> Frameicon34Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon34Path);
        public static Asset<Texture2D> Frameicon34ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon34Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon34Path = "Icons/Frameicon34";
        public static Asset<Texture2D> Frameicon35Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon35Path);
        public static Asset<Texture2D> Frameicon35ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon35Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon35Path = "Icons/Frameicon35";
        public static Asset<Texture2D> Frameicon36Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon36Path);
        public static Asset<Texture2D> Frameicon36ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon36Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon36Path = "Icons/Frameicon36";
        public static Asset<Texture2D> Frameicon37Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon37Path);
        public static Asset<Texture2D> Frameicon37ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon37Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon37Path = "Icons/Frameicon37";
        public static Asset<Texture2D> Frameicon38Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon38Path);
        public static Asset<Texture2D> Frameicon38ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon38Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon38Path = "Icons/Frameicon38";
        public static Asset<Texture2D> Frameicon39Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon39Path);
        public static Asset<Texture2D> Frameicon39ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon39Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon39Path = "Icons/Frameicon39";
        public static Asset<Texture2D> Frameicon4Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon4Path);
        public static Asset<Texture2D> Frameicon4ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon4Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon4Path = "Icons/Frameicon4";
        public static Asset<Texture2D> Frameicon40Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon40Path);
        public static Asset<Texture2D> Frameicon40ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon40Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon40Path = "Icons/Frameicon40";
        public static Asset<Texture2D> Frameicon41Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon41Path);
        public static Asset<Texture2D> Frameicon41ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon41Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon41Path = "Icons/Frameicon41";
        public static Asset<Texture2D> Frameicon42Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon42Path);
        public static Asset<Texture2D> Frameicon42ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon42Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon42Path = "Icons/Frameicon42";
        public static Asset<Texture2D> Frameicon43Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon43Path);
        public static Asset<Texture2D> Frameicon43ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon43Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon43Path = "Icons/Frameicon43";
        public static Asset<Texture2D> Frameicon44Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon44Path);
        public static Asset<Texture2D> Frameicon44ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon44Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon44Path = "Icons/Frameicon44";
        public static Asset<Texture2D> Frameicon5Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon5Path);
        public static Asset<Texture2D> Frameicon5ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon5Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon5Path = "Icons/Frameicon5";
        public static Asset<Texture2D> Frameicon6Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon6Path);
        public static Asset<Texture2D> Frameicon6ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon6Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon6Path = "Icons/Frameicon6";
        public static Asset<Texture2D> Frameicon7Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon7Path);
        public static Asset<Texture2D> Frameicon7ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon7Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon7Path = "Icons/Frameicon7";
        public static Asset<Texture2D> Frameicon8Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon8Path);
        public static Asset<Texture2D> Frameicon8ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon8Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon8Path = "Icons/Frameicon8";
        public static Asset<Texture2D> Frameicon9Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon9Path);
        public static Asset<Texture2D> Frameicon9ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Frameicon9Path, AssetRequestMode.ImmediateLoad);
        public const string Frameicon9Path = "Icons/Frameicon9";
    }

    public static class Images
    {
        public static Asset<Texture2D> ReloadIconAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ReloadIconPath);
        public static Asset<Texture2D> ReloadIconImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ReloadIconPath, AssetRequestMode.ImmediateLoad);
        public const string ReloadIconPath = "Images/ReloadIcon";
        public static Asset<Texture2D> Trail1Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Trail1Path);
        public static Asset<Texture2D> Trail1ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Trail1Path, AssetRequestMode.ImmediateLoad);
        public const string Trail1Path = "Images/Trail1";
        public static class Book
        {
            public static Asset<Texture2D> apretrue_bAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(apretrue_bPath);
            public static Asset<Texture2D> apretrue_bImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(apretrue_bPath, AssetRequestMode.ImmediateLoad);
            public const string apretrue_bPath = "Images/Book/apretrue b";
            public static Asset<Texture2D> apretrue_wAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(apretrue_wPath);
            public static Asset<Texture2D> apretrue_wImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(apretrue_wPath, AssetRequestMode.ImmediateLoad);
            public const string apretrue_wPath = "Images/Book/apretrue w";
            public static Asset<Texture2D> ButtonAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ButtonPath);
            public static Asset<Texture2D> ButtonImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ButtonPath, AssetRequestMode.ImmediateLoad);
            public const string ButtonPath = "Images/Book/Button";
            public static Asset<Texture2D> Button_UsedAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Button_UsedPath);
            public static Asset<Texture2D> Button_UsedImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Button_UsedPath, AssetRequestMode.ImmediateLoad);
            public const string Button_UsedPath = "Images/Book/Button_Used";
            public static Asset<Texture2D> close_v2Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(close_v2Path);
            public static Asset<Texture2D> close_v2ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(close_v2Path, AssetRequestMode.ImmediateLoad);
            public const string close_v2Path = "Images/Book/close v2";
            public static Asset<Texture2D> CloseAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ClosePath);
            public static Asset<Texture2D> CloseImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ClosePath, AssetRequestMode.ImmediateLoad);
            public const string ClosePath = "Images/Book/Close";
            public static Asset<Texture2D> OKAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OKPath);
            public static Asset<Texture2D> OKImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OKPath, AssetRequestMode.ImmediateLoad);
            public const string OKPath = "Images/Book/OK";
            public static Asset<Texture2D> OK_UsedAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OK_UsedPath);
            public static Asset<Texture2D> OK_UsedImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OK_UsedPath, AssetRequestMode.ImmediateLoad);
            public const string OK_UsedPath = "Images/Book/OK_Used";
            public static Asset<Texture2D> PanelAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelPath);
            public static Asset<Texture2D> PanelImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelPath, AssetRequestMode.ImmediateLoad);
            public const string PanelPath = "Images/Book/Panel";
            public static Asset<Texture2D> Slider_v2Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Slider_v2Path);
            public static Asset<Texture2D> Slider_v2ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Slider_v2Path, AssetRequestMode.ImmediateLoad);
            public const string Slider_v2Path = "Images/Book/Slider v2";
            public static Asset<Texture2D> SliderAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliderPath);
            public static Asset<Texture2D> SliderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliderPath, AssetRequestMode.ImmediateLoad);
            public const string SliderPath = "Images/Book/Slider";
            public static Asset<Texture2D> SliderInnerAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliderInnerPath);
            public static Asset<Texture2D> SliderInnerImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliderInnerPath, AssetRequestMode.ImmediateLoad);
            public const string SliderInnerPath = "Images/Book/SliderInner";
        }

        public static class Original
        {
            public static Asset<Texture2D> HeartMiracleAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HeartMiraclePath);
            public static Asset<Texture2D> HeartMiracleImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HeartMiraclePath, AssetRequestMode.ImmediateLoad);
            public const string HeartMiraclePath = "Images/Original/HeartMiracle";
            public static Asset<Texture2D> HeartOriginalAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HeartOriginalPath);
            public static Asset<Texture2D> HeartOriginalImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HeartOriginalPath, AssetRequestMode.ImmediateLoad);
            public const string HeartOriginalPath = "Images/Original/HeartOriginal";
            public static Asset<Texture2D> ManaWhiteAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ManaWhitePath);
            public static Asset<Texture2D> ManaWhiteImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ManaWhitePath, AssetRequestMode.ImmediateLoad);
            public const string ManaWhitePath = "Images/Original/ManaWhite";
            public static Asset<Texture2D> MiracleHeartLeftAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartLeftPath);
            public static Asset<Texture2D> MiracleHeartLeftImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartLeftPath, AssetRequestMode.ImmediateLoad);
            public const string MiracleHeartLeftPath = "Images/Original/MiracleHeartLeft";
            public static Asset<Texture2D> MiracleHeartMiddleAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartMiddlePath);
            public static Asset<Texture2D> MiracleHeartMiddleImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartMiddlePath, AssetRequestMode.ImmediateLoad);
            public const string MiracleHeartMiddlePath = "Images/Original/MiracleHeartMiddle";
            public static Asset<Texture2D> MiracleHeartRightAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartRightPath);
            public static Asset<Texture2D> MiracleHeartRightImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartRightPath, AssetRequestMode.ImmediateLoad);
            public const string MiracleHeartRightPath = "Images/Original/MiracleHeartRight";
            public static Asset<Texture2D> MiracleHeartRightFancyAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartRightFancyPath);
            public static Asset<Texture2D> MiracleHeartRightFancyImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleHeartRightFancyPath, AssetRequestMode.ImmediateLoad);
            public const string MiracleHeartRightFancyPath = "Images/Original/MiracleHeartRightFancy";
        }

        public static class UIModItem
        {
            public static Asset<Texture2D> PanelBackgroundAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelBackgroundPath);
            public static Asset<Texture2D> PanelBackgroundImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelBackgroundPath, AssetRequestMode.ImmediateLoad);
            public const string PanelBackgroundPath = "Images/UIModItem/PanelBackground";
            public static Asset<Texture2D> PanelBorderAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelBorderPath);
            public static Asset<Texture2D> PanelBorderImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PanelBorderPath, AssetRequestMode.ImmediateLoad);
            public const string PanelBorderPath = "Images/UIModItem/PanelBorder";
            public static Asset<Texture2D> UIModItemBackgroundAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(UIModItemBackgroundPath);
            public static Asset<Texture2D> UIModItemBackgroundImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(UIModItemBackgroundPath, AssetRequestMode.ImmediateLoad);
            public const string UIModItemBackgroundPath = "Images/UIModItem/UIModItemBackground";
        }

    }

    public static class Items
    {
        public static class Armors
        {
            public static Asset<Texture2D> KokomiArmorAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiArmorPath);
            public static Asset<Texture2D> KokomiArmorImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiArmorPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiArmorPath = "Items/Armors/KokomiArmor";
            public static Asset<Texture2D> KokomiArmor_BodyAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiArmor_BodyPath);
            public static Asset<Texture2D> KokomiArmor_BodyImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiArmor_BodyPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiArmor_BodyPath = "Items/Armors/KokomiArmor_Body";
            public static Asset<Texture2D> KokomiHeadAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHeadPath);
            public static Asset<Texture2D> KokomiHeadImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHeadPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiHeadPath = "Items/Armors/KokomiHead";
            public static Asset<Texture2D> KokomiHead_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHead_GlowPath);
            public static Asset<Texture2D> KokomiHead_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHead_GlowPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiHead_GlowPath = "Items/Armors/KokomiHead_Glow";
            public static Asset<Texture2D> KokomiHead_HeadAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHead_HeadPath);
            public static Asset<Texture2D> KokomiHead_HeadImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiHead_HeadPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiHead_HeadPath = "Items/Armors/KokomiHead_Head";
            public static Asset<Texture2D> KokomiLegsAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiLegsPath);
            public static Asset<Texture2D> KokomiLegsImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiLegsPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiLegsPath = "Items/Armors/KokomiLegs";
            public static Asset<Texture2D> KokomiLegs_LegsAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiLegs_LegsPath);
            public static Asset<Texture2D> KokomiLegs_LegsImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KokomiLegs_LegsPath, AssetRequestMode.ImmediateLoad);
            public const string KokomiLegs_LegsPath = "Items/Armors/KokomiLegs_Legs";
        }

        public static class Bags
        {
            public static Asset<Texture2D> EnterVoucherAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EnterVoucherPath);
            public static Asset<Texture2D> EnterVoucherImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EnterVoucherPath, AssetRequestMode.ImmediateLoad);
            public const string EnterVoucherPath = "Items/Bags/EnterVoucher";
            public static Asset<Texture2D> EnterVoucher_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EnterVoucher_GlowPath);
            public static Asset<Texture2D> EnterVoucher_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(EnterVoucher_GlowPath, AssetRequestMode.ImmediateLoad);
            public const string EnterVoucher_GlowPath = "Items/Bags/EnterVoucher_Glow";
            public static Asset<Texture2D> startAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(startPath);
            public static Asset<Texture2D> startImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(startPath, AssetRequestMode.ImmediateLoad);
            public const string startPath = "Items/Bags/start";
            public static Asset<Texture2D> start_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(start_GlowPath);
            public static Asset<Texture2D> start_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(start_GlowPath, AssetRequestMode.ImmediateLoad);
            public const string start_GlowPath = "Items/Bags/start_Glow";
            public static Asset<Texture2D> WeaponboxAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WeaponboxPath);
            public static Asset<Texture2D> WeaponboxImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WeaponboxPath, AssetRequestMode.ImmediateLoad);
            public const string WeaponboxPath = "Items/Bags/Weaponbox";
        }

        public static class BossSummons
        {
            public static Asset<Texture2D> SatellitesAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SatellitesPath);
            public static Asset<Texture2D> SatellitesImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SatellitesPath, AssetRequestMode.ImmediateLoad);
            public const string SatellitesPath = "Items/BossSummons/Satellites";
        }

        public static class Food
        {
            public static Asset<Texture2D> BeanSandAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BeanSandPath);
            public static Asset<Texture2D> BeanSandImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(BeanSandPath, AssetRequestMode.ImmediateLoad);
            public const string BeanSandPath = "Items/Food/BeanSand";
            public static Asset<Texture2D> FiverenAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(FiverenPath);
            public static Asset<Texture2D> FiverenImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(FiverenPath, AssetRequestMode.ImmediateLoad);
            public const string FiverenPath = "Items/Food/Fiveren";
            public static Asset<Texture2D> MooncakeYoyoAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MooncakeYoyoPath);
            public static Asset<Texture2D> MooncakeYoyoImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MooncakeYoyoPath, AssetRequestMode.ImmediateLoad);
            public const string MooncakeYoyoPath = "Items/Food/MooncakeYoyo";
            public static Asset<Texture2D> YolkAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(YolkPath);
            public static Asset<Texture2D> YolkImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(YolkPath, AssetRequestMode.ImmediateLoad);
            public const string YolkPath = "Items/Food/Yolk";
        }

        public static class Fruit
        {
            public static Asset<Texture2D> MiracleheartAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleheartPath);
            public static Asset<Texture2D> MiracleheartImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MiracleheartPath, AssetRequestMode.ImmediateLoad);
            public const string MiracleheartPath = "Items/Fruit/Miracleheart";
            public static Asset<Texture2D> WhiteManaAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WhiteManaPath);
            public static Asset<Texture2D> WhiteManaImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WhiteManaPath, AssetRequestMode.ImmediateLoad);
            public const string WhiteManaPath = "Items/Fruit/WhiteMana";
        }

        public static class MagicCraftItem
        {
            public static Asset<Texture2D> ActivecellspheresAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ActivecellspheresPath);
            public static Asset<Texture2D> ActivecellspheresImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ActivecellspheresPath, AssetRequestMode.ImmediateLoad);
            public const string ActivecellspheresPath = "Items/MagicCraftItem/Activecellspheres";
            public static Asset<Texture2D> Activecellspheres_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Activecellspheres_GlowPath);
            public static Asset<Texture2D> Activecellspheres_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Activecellspheres_GlowPath, AssetRequestMode.ImmediateLoad);
            public const string Activecellspheres_GlowPath = "Items/MagicCraftItem/Activecellspheres_Glow";
            public static Asset<Texture2D> MagiccondensateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagiccondensatePath);
            public static Asset<Texture2D> MagiccondensateImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagiccondensatePath, AssetRequestMode.ImmediateLoad);
            public const string MagiccondensatePath = "Items/MagicCraftItem/Magiccondensate";
            public static Asset<Texture2D> MagicGelAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagicGelPath);
            public static Asset<Texture2D> MagicGelImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagicGelPath, AssetRequestMode.ImmediateLoad);
            public const string MagicGelPath = "Items/MagicCraftItem/MagicGel";
            public static Asset<Texture2D> MagicGel_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagicGel_GlowPath);
            public static Asset<Texture2D> MagicGel_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MagicGel_GlowPath, AssetRequestMode.ImmediateLoad);
            public const string MagicGel_GlowPath = "Items/MagicCraftItem/MagicGel_Glow";
            public static Asset<Texture2D> MeteoritesEssenceAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeteoritesEssencePath);
            public static Asset<Texture2D> MeteoritesEssenceImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeteoritesEssencePath, AssetRequestMode.ImmediateLoad);
            public const string MeteoritesEssencePath = "Items/MagicCraftItem/MeteoritesEssence";
        }

        public static class Materials
        {
            public static Asset<Texture2D> ScrapAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapPath);
            public static Asset<Texture2D> ScrapImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapPath, AssetRequestMode.ImmediateLoad);
            public const string ScrapPath = "Items/Materials/Scrap";
        }

        public static class Placeable
        {
            public static Asset<Texture2D> ExtractTableItemAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTableItemPath);
            public static Asset<Texture2D> ExtractTableItemImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTableItemPath, AssetRequestMode.ImmediateLoad);
            public const string ExtractTableItemPath = "Items/Placeable/ExtractTableItem";
            public static Asset<Texture2D> ExtractTableItem_FrameAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTableItem_FramePath);
            public static Asset<Texture2D> ExtractTableItem_FrameImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTableItem_FramePath, AssetRequestMode.ImmediateLoad);
            public const string ExtractTableItem_FramePath = "Items/Placeable/ExtractTableItem_Frame";
        }

        public static class StoryData
        {
            public static Asset<Texture2D> uiAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(uiPath);
            public static Asset<Texture2D> uiImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(uiPath, AssetRequestMode.ImmediateLoad);
            public const string uiPath = "Items/StoryData/ui";
        }

        public static class Weapon
        {
            public static class Gun
            {
                public static class G0
                {
                    public static Asset<Texture2D> GAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GPath);
                    public static Asset<Texture2D> GImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GPath, AssetRequestMode.ImmediateLoad);
                    public const string GPath = "Items/Weapon/Gun/G0/G";
                    public static Asset<Texture2D> G_BulletAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(G_BulletPath);
                    public static Asset<Texture2D> G_BulletImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(G_BulletPath, AssetRequestMode.ImmediateLoad);
                    public const string G_BulletPath = "Items/Weapon/Gun/G0/G_Bullet";
                }

            }

            public static class Magic
            {
                public static Asset<Texture2D> VIIILaserGunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGunPath);
                public static Asset<Texture2D> VIIILaserGunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGunPath, AssetRequestMode.ImmediateLoad);
                public const string VIIILaserGunPath = "Items/Weapon/Magic/VIIILaserGun";
                public static Asset<Texture2D> VIIILaserGun_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGun_GlowPath);
                public static Asset<Texture2D> VIIILaserGun_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGun_GlowPath, AssetRequestMode.ImmediateLoad);
                public const string VIIILaserGun_GlowPath = "Items/Weapon/Magic/VIIILaserGun_Glow";
            }

            public static class Melee
            {
                public static Asset<Texture2D> HollyknightAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HollyknightPath);
                public static Asset<Texture2D> HollyknightImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HollyknightPath, AssetRequestMode.ImmediateLoad);
                public const string HollyknightPath = "Items/Weapon/Melee/Hollyknight";
                public static Asset<Texture2D> NewknifeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NewknifePath);
                public static Asset<Texture2D> NewknifeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NewknifePath, AssetRequestMode.ImmediateLoad);
                public const string NewknifePath = "Items/Weapon/Melee/Newknife";
                public static Asset<Texture2D> TheGloryAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryPath);
                public static Asset<Texture2D> TheGloryImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryPath, AssetRequestMode.ImmediateLoad);
                public const string TheGloryPath = "Items/Weapon/Melee/TheGlory";
                public static Asset<Texture2D> TheGlory_OutGlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGlory_OutGlowPath);
                public static Asset<Texture2D> TheGlory_OutGlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGlory_OutGlowPath, AssetRequestMode.ImmediateLoad);
                public const string TheGlory_OutGlowPath = "Items/Weapon/Melee/TheGlory_OutGlow";
            }

            public static class NailGun
            {
                public static Asset<Texture2D> ElectricNailGunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ElectricNailGunPath);
                public static Asset<Texture2D> ElectricNailGunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ElectricNailGunPath, AssetRequestMode.ImmediateLoad);
                public const string ElectricNailGunPath = "Items/Weapon/NailGun/ElectricNailGun";
                public static Asset<Texture2D> GasNailGunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GasNailGunPath);
                public static Asset<Texture2D> GasNailGunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GasNailGunPath, AssetRequestMode.ImmediateLoad);
                public const string GasNailGunPath = "Items/Weapon/NailGun/GasNailGun";
                public static Asset<Texture2D> IronModernNailgunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(IronModernNailgunPath);
                public static Asset<Texture2D> IronModernNailgunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(IronModernNailgunPath, AssetRequestMode.ImmediateLoad);
                public const string IronModernNailgunPath = "Items/Weapon/NailGun/IronModernNailgun";
                public static Asset<Texture2D> NailRifleAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NailRiflePath);
                public static Asset<Texture2D> NailRifleImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NailRiflePath, AssetRequestMode.ImmediateLoad);
                public const string NailRiflePath = "Items/Weapon/NailGun/NailRifle";
                public static Asset<Texture2D> OldNailGunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OldNailGunPath);
                public static Asset<Texture2D> OldNailGunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OldNailGunPath, AssetRequestMode.ImmediateLoad);
                public const string OldNailGunPath = "Items/Weapon/NailGun/OldNailGun";
                public static class Nails
                {
                    public static Asset<Texture2D> NanoSpikeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NanoSpikePath);
                    public static Asset<Texture2D> NanoSpikeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NanoSpikePath, AssetRequestMode.ImmediateLoad);
                    public const string NanoSpikePath = "Items/Weapon/NailGun/Nails/NanoSpike";
                    public static Asset<Texture2D> OldSpikeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OldSpikePath);
                    public static Asset<Texture2D> OldSpikeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(OldSpikePath, AssetRequestMode.ImmediateLoad);
                    public const string OldSpikePath = "Items/Weapon/NailGun/Nails/OldSpike";
                    public static Asset<Texture2D> PoisonSpikeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PoisonSpikePath);
                    public static Asset<Texture2D> PoisonSpikeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PoisonSpikePath, AssetRequestMode.ImmediateLoad);
                    public const string PoisonSpikePath = "Items/Weapon/NailGun/Nails/PoisonSpike";
                    public static Asset<Texture2D> SliverSpikeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliverSpikePath);
                    public static Asset<Texture2D> SliverSpikeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SliverSpikePath, AssetRequestMode.ImmediateLoad);
                    public const string SliverSpikePath = "Items/Weapon/NailGun/Nails/SliverSpike";
                    public static Asset<Texture2D> WoodenSpikeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WoodenSpikePath);
                    public static Asset<Texture2D> WoodenSpikeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(WoodenSpikePath, AssetRequestMode.ImmediateLoad);
                    public const string WoodenSpikePath = "Items/Weapon/NailGun/Nails/WoodenSpike";
                }

            }

            public static class Ranged
            {
                public static Asset<Texture2D> GraniteGunAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGunPath);
                public static Asset<Texture2D> GraniteGunImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGunPath, AssetRequestMode.ImmediateLoad);
                public const string GraniteGunPath = "Items/Weapon/Ranged/GraniteGun";
                public static Asset<Texture2D> GraniteGun_ExtraAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_ExtraPath);
                public static Asset<Texture2D> GraniteGun_ExtraImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_ExtraPath, AssetRequestMode.ImmediateLoad);
                public const string GraniteGun_ExtraPath = "Items/Weapon/Ranged/GraniteGun_Extra";
                public static Asset<Texture2D> GraniteGun_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_GlowPath);
                public static Asset<Texture2D> GraniteGun_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_GlowPath, AssetRequestMode.ImmediateLoad);
                public const string GraniteGun_GlowPath = "Items/Weapon/Ranged/GraniteGun_Glow";
            }

            public static class ValliaRemake
            {
                public static Asset<Texture2D> PhoenixBlasterRemakeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PhoenixBlasterRemakePath);
                public static Asset<Texture2D> PhoenixBlasterRemakeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PhoenixBlasterRemakePath, AssetRequestMode.ImmediateLoad);
                public const string PhoenixBlasterRemakePath = "Items/Weapon/ValliaRemake/PhoenixBlasterRemake";
                public static Asset<Texture2D> PhoenixBlasterRemake_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PhoenixBlasterRemake_GlowPath);
                public static Asset<Texture2D> PhoenixBlasterRemake_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PhoenixBlasterRemake_GlowPath, AssetRequestMode.ImmediateLoad);
                public const string PhoenixBlasterRemake_GlowPath = "Items/Weapon/ValliaRemake/PhoenixBlasterRemake_Glow";
                public static Asset<Texture2D> VenusMagnumRemakeAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VenusMagnumRemakePath);
                public static Asset<Texture2D> VenusMagnumRemakeImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VenusMagnumRemakePath, AssetRequestMode.ImmediateLoad);
                public const string VenusMagnumRemakePath = "Items/Weapon/ValliaRemake/VenusMagnumRemake";
            }

        }

    }

    public static class NPCs
    {
        public static Asset<Texture2D> MeleeMoonAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoonPath);
        public static Asset<Texture2D> MeleeMoonImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoonPath, AssetRequestMode.ImmediateLoad);
        public const string MeleeMoonPath = "NPCs/MeleeMoon";
        public static Asset<Texture2D> MeleeMoon_Head_BossAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoon_Head_BossPath);
        public static Asset<Texture2D> MeleeMoon_Head_BossImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoon_Head_BossPath, AssetRequestMode.ImmediateLoad);
        public const string MeleeMoon_Head_BossPath = "NPCs/MeleeMoon_Head_Boss";
        public static Asset<Texture2D> RemoteMoonAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(RemoteMoonPath);
        public static Asset<Texture2D> RemoteMoonImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(RemoteMoonPath, AssetRequestMode.ImmediateLoad);
        public const string RemoteMoonPath = "NPCs/RemoteMoon";
        public static Asset<Texture2D> SatelliteSmallAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SatelliteSmallPath);
        public static Asset<Texture2D> SatelliteSmallImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SatelliteSmallPath, AssetRequestMode.ImmediateLoad);
        public const string SatelliteSmallPath = "NPCs/SatelliteSmall";
    }

    public static class Projs
    {
        public static Asset<Texture2D> TrailAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TrailPath);
        public static Asset<Texture2D> TrailImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TrailPath, AssetRequestMode.ImmediateLoad);
        public const string TrailPath = "Projs/Trail";
        public static Asset<Texture2D> TrailWhiteAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TrailWhitePath);
        public static Asset<Texture2D> TrailWhiteImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TrailWhitePath, AssetRequestMode.ImmediateLoad);
        public const string TrailWhitePath = "Projs/TrailWhite";
        public static class Bosses
        {
            public static Asset<Texture2D> GreenprojAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GreenprojPath);
            public static Asset<Texture2D> GreenprojImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GreenprojPath, AssetRequestMode.ImmediateLoad);
            public const string GreenprojPath = "Projs/Bosses/Greenproj";
            public static Asset<Texture2D> MeleeMoonLaserAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoonLaserPath);
            public static Asset<Texture2D> MeleeMoonLaserImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MeleeMoonLaserPath, AssetRequestMode.ImmediateLoad);
            public const string MeleeMoonLaserPath = "Projs/Bosses/MeleeMoonLaser";
            public static Asset<Texture2D> MoonLaserAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MoonLaserPath);
            public static Asset<Texture2D> MoonLaserImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MoonLaserPath, AssetRequestMode.ImmediateLoad);
            public const string MoonLaserPath = "Projs/Bosses/MoonLaser";
            public static Asset<Texture2D> MoonRocketAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MoonRocketPath);
            public static Asset<Texture2D> MoonRocketImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MoonRocketPath, AssetRequestMode.ImmediateLoad);
            public const string MoonRocketPath = "Projs/Bosses/MoonRocket";
        }

        public static class Food
        {
            public static Asset<Texture2D> MooncakeYoyoProjAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MooncakeYoyoProjPath);
            public static Asset<Texture2D> MooncakeYoyoProjImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(MooncakeYoyoProjPath, AssetRequestMode.ImmediateLoad);
            public const string MooncakeYoyoProjPath = "Projs/Food/MooncakeYoyoProj";
            public static Asset<Texture2D> ScrapMediumAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapMediumPath);
            public static Asset<Texture2D> ScrapMediumImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapMediumPath, AssetRequestMode.ImmediateLoad);
            public const string ScrapMediumPath = "Projs/Food/ScrapMedium";
            public static Asset<Texture2D> ScrapSmallAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapSmallPath);
            public static Asset<Texture2D> ScrapSmallImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrapSmallPath, AssetRequestMode.ImmediateLoad);
            public const string ScrapSmallPath = "Projs/Food/ScrapSmall";
        }

        public static class Magic
        {
            public static Asset<Texture2D> VIIILaserGunProAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGunProPath);
            public static Asset<Texture2D> VIIILaserGunProImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(VIIILaserGunProPath, AssetRequestMode.ImmediateLoad);
            public const string VIIILaserGunProPath = "Projs/Magic/VIIILaserGunPro";
        }

        public static class Melee
        {
            public static Asset<Texture2D> HitEffectAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HitEffectPath);
            public static Asset<Texture2D> HitEffectImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(HitEffectPath, AssetRequestMode.ImmediateLoad);
            public const string HitEffectPath = "Projs/Melee/HitEffect";
            public static Asset<Texture2D> KnifeprojAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KnifeprojPath);
            public static Asset<Texture2D> KnifeprojImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(KnifeprojPath, AssetRequestMode.ImmediateLoad);
            public const string KnifeprojPath = "Projs/Melee/Knifeproj";
            public static Asset<Texture2D> NewknifepAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NewknifepPath);
            public static Asset<Texture2D> NewknifepImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NewknifepPath, AssetRequestMode.ImmediateLoad);
            public const string NewknifepPath = "Projs/Melee/Newknifep";
            public static Asset<Texture2D> TheGlorypAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGlorypPath);
            public static Asset<Texture2D> TheGlorypImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGlorypPath, AssetRequestMode.ImmediateLoad);
            public const string TheGlorypPath = "Projs/Melee/TheGloryp";
            public static Asset<Texture2D> TheGloryProAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryProPath);
            public static Asset<Texture2D> TheGloryProImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryProPath, AssetRequestMode.ImmediateLoad);
            public const string TheGloryProPath = "Projs/Melee/TheGloryPro";
            public static Asset<Texture2D> TheGloryPro2Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryPro2Path);
            public static Asset<Texture2D> TheGloryPro2ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheGloryPro2Path, AssetRequestMode.ImmediateLoad);
            public const string TheGloryPro2Path = "Projs/Melee/TheGloryPro2";
        }

        public static class NoSort
        {
            public static Asset<Texture2D> CapsuleExplosionAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CapsuleExplosionPath);
            public static Asset<Texture2D> CapsuleExplosionImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(CapsuleExplosionPath, AssetRequestMode.ImmediateLoad);
            public const string CapsuleExplosionPath = "Projs/NoSort/CapsuleExplosion";
            public static Asset<Texture2D> SpaceCapsuleAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsulePath);
            public static Asset<Texture2D> SpaceCapsuleImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(SpaceCapsulePath, AssetRequestMode.ImmediateLoad);
            public const string SpaceCapsulePath = "Projs/NoSort/SpaceCapsule";
            public static Asset<Texture2D> StartprojAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(StartprojPath);
            public static Asset<Texture2D> StartprojImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(StartprojPath, AssetRequestMode.ImmediateLoad);
            public const string StartprojPath = "Projs/NoSort/Startproj";
        }

        public static class Ranged
        {
            public static Asset<Texture2D> GraniteGun_ProAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_ProPath);
            public static Asset<Texture2D> GraniteGun_ProImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_ProPath, AssetRequestMode.ImmediateLoad);
            public const string GraniteGun_ProPath = "Projs/Ranged/GraniteGun_Pro";
            public static Asset<Texture2D> GraniteGun_Pro_ExtraAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_Pro_ExtraPath);
            public static Asset<Texture2D> GraniteGun_Pro_ExtraImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(GraniteGun_Pro_ExtraPath, AssetRequestMode.ImmediateLoad);
            public const string GraniteGun_Pro_ExtraPath = "Projs/Ranged/GraniteGun_Pro_Extra";
            public static Asset<Texture2D> LightAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightPath);
            public static Asset<Texture2D> LightImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LightPath, AssetRequestMode.ImmediateLoad);
            public const string LightPath = "Projs/Ranged/Light";
            public static Asset<Texture2D> TheoryValueAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheoryValuePath);
            public static Asset<Texture2D> TheoryValueImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(TheoryValuePath, AssetRequestMode.ImmediateLoad);
            public const string TheoryValuePath = "Projs/Ranged/TheoryValue";
        }

        public static class Whips
        {
            public static Asset<Texture2D> PeavineProjAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PeavineProjPath);
            public static Asset<Texture2D> PeavineProjImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PeavineProjPath, AssetRequestMode.ImmediateLoad);
            public const string PeavineProjPath = "Projs/Whips/PeavineProj";
        }

    }

    public static class Textures
    {
        public static class Ex
        {
            public static Asset<Texture2D> Ex1Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Ex1Path);
            public static Asset<Texture2D> Ex1ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(Ex1Path, AssetRequestMode.ImmediateLoad);
            public const string Ex1Path = "Textures/Ex/Ex1";
        }

    }

    public static class Tiles
    {
        public static Asset<Texture2D> ExtractTableAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTablePath);
        public static Asset<Texture2D> ExtractTableImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTablePath, AssetRequestMode.ImmediateLoad);
        public const string ExtractTablePath = "Tiles/ExtractTable";
        public static Asset<Texture2D> ExtractTable_GlowAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTable_GlowPath);
        public static Asset<Texture2D> ExtractTable_GlowImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTable_GlowPath, AssetRequestMode.ImmediateLoad);
        public const string ExtractTable_GlowPath = "Tiles/ExtractTable_Glow";
        public static Asset<Texture2D> ExtractTable_HighlightAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTable_HighlightPath);
        public static Asset<Texture2D> ExtractTable_HighlightImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractTable_HighlightPath, AssetRequestMode.ImmediateLoad);
        public const string ExtractTable_HighlightPath = "Tiles/ExtractTable_Highlight";
    }

    public static class UI
    {
        public static class Images
        {
            public static Asset<Texture2D> ExtractButtonAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractButtonPath);
            public static Asset<Texture2D> ExtractButtonImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractButtonPath, AssetRequestMode.ImmediateLoad);
            public const string ExtractButtonPath = "UI/Images/ExtractButton";
            public static Asset<Texture2D> ExtractCloseAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractClosePath);
            public static Asset<Texture2D> ExtractCloseImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractClosePath, AssetRequestMode.ImmediateLoad);
            public const string ExtractClosePath = "UI/Images/ExtractClose";
            public static Asset<Texture2D> ExtractIconAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractIconPath);
            public static Asset<Texture2D> ExtractIconImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractIconPath, AssetRequestMode.ImmediateLoad);
            public const string ExtractIconPath = "UI/Images/ExtractIcon";
            public static Asset<Texture2D> ExtractPanelAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractPanelPath);
            public static Asset<Texture2D> ExtractPanelImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ExtractPanelPath, AssetRequestMode.ImmediateLoad);
            public const string ExtractPanelPath = "UI/Images/ExtractPanel";
            public static Asset<Texture2D> InfoSlotAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(InfoSlotPath);
            public static Asset<Texture2D> InfoSlotImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(InfoSlotPath, AssetRequestMode.ImmediateLoad);
            public const string InfoSlotPath = "UI/Images/InfoSlot";
            public static Asset<Texture2D> InfoSlot_1Asset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(InfoSlot_1Path);
            public static Asset<Texture2D> InfoSlot_1ImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(InfoSlot_1Path, AssetRequestMode.ImmediateLoad);
            public const string InfoSlot_1Path = "UI/Images/InfoSlot_1";
            public static Asset<Texture2D> ItemSlotAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ItemSlotPath);
            public static Asset<Texture2D> ItemSlotImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ItemSlotPath, AssetRequestMode.ImmediateLoad);
            public const string ItemSlotPath = "UI/Images/ItemSlot";
            public static Asset<Texture2D> LastPageAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LastPagePath);
            public static Asset<Texture2D> LastPageImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(LastPagePath, AssetRequestMode.ImmediateLoad);
            public const string LastPagePath = "UI/Images/LastPage";
            public static Asset<Texture2D> NextPageAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NextPagePath);
            public static Asset<Texture2D> NextPageImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(NextPagePath, AssetRequestMode.ImmediateLoad);
            public const string NextPagePath = "UI/Images/NextPage";
            public static Asset<Texture2D> ScrollbarAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrollbarPath);
            public static Asset<Texture2D> ScrollbarImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrollbarPath, AssetRequestMode.ImmediateLoad);
            public const string ScrollbarPath = "UI/Images/Scrollbar";
            public static Asset<Texture2D> ScrollbarInnerAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrollbarInnerPath);
            public static Asset<Texture2D> ScrollbarInnerImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(ScrollbarInnerPath, AssetRequestMode.ImmediateLoad);
            public const string ScrollbarInnerPath = "UI/Images/ScrollbarInner";
        }

        public static class Propaganda
        {
            public static Asset<Texture2D> PropagandaUIElementAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PropagandaUIElementPath);
            public static Asset<Texture2D> PropagandaUIElementImmediateAsset => ModAssets_Utils.Mod.Assets.Request<Texture2D>(PropagandaUIElementPath, AssetRequestMode.ImmediateLoad);
            public const string PropagandaUIElementPath = "UI/Propaganda/PropagandaUIElement";
        }

    }

}

