using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.ScreenShaderDatas;
using NeonDawn.Systems;
using NeonDawn.UI;
using NeonDawn.UI.BookUI;
using NeonDawn.UI.ExtractUI;
using NeonDawn.UI.Propaganda;

using ReLogic.Content;
using ReLogic.Graphics;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;

using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.UI.Elements;
using Terraria.GameContent.UI.ResourceSets;
using Terraria.Graphics.Effects;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;
using Terraria.UI.Chat;

namespace NeonDawn
{
    public class NeonDawn : Mod
    {
        public static GameCulture Chinese = GameCulture.FromCultureName(GameCulture.CultureName.Chinese);
        public static string VanillaVersion = Main.versionNumber;
        public static string VanillaVersion2 = Main.versionNumber2;
        public static GameCulture English = GameCulture.FromCultureName(GameCulture.CultureName.English);
        public static Effect DefaultEffect;
        public static Texture2D MainColor;
        public static Texture2D MainShape;
        public static Texture2D MaskColor;
        public static Effect GreenShader;
        public static Effect RedShader;
        public static Effect GradualGreenShader;
        public static DynamicSpriteFont ZhengQingkeButterBodyFont, SourceHanSansFont;
        public static NeonDawn Instance;
        internal UI.Propaganda.PropagandaUIState PropagandaUIState;
        internal UserInterface PropagandaUI, ExtractUI, Book;
        internal ExtractUIState ExtractUIState;
        internal BookState BookState;

        public static int AloneSlot;
        private int nameFrame = 0, time = 0, iconFrame = 1;
        private static Asset<Texture2D>[] icon = new Asset<Texture2D>[44];

        private UIImage IconImage;
        private ModNameText ModName;
        public NeonDawn()
        {
            Instance = this;
        }

        public override void PostSetupContent()
        {
            GreenShader = ModContent.Request<Effect>("NeonDawn/Effects/GreenShader").Value;
            Filters.Scene["GreenShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/GreenShader").Value), "GreenShader"), EffectPriority.Medium);
            Filters.Scene["GreenShader"].Load();
            RedShader = ModContent.Request<Effect>("NeonDawn/Effects/RedShader").Value;
            Filters.Scene["RedShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/RedShader").Value), "RedShader"), EffectPriority.Medium);
            Filters.Scene["RedShader"].Load();
            GradualGreenShader = ModContent.Request<Effect>("NeonDawn/Effects/GradualGreenShader").Value;
            Filters.Scene["GradualGreenShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/GradualGreenShader").Value), "GreenShader"), EffectPriority.Medium);
            Filters.Scene["GradualGreenShader"].Load();
        }

        internal static Dictionary<string, int> MyGlows;
        private List<Asset<Texture2D>> assets;

        public static Vector2 WeaponVector(float radius, float theta)
        {
            return new Vector2((float)Math.Cos(theta), (float)Math.Sin(theta)) * radius;
        }

        public override void Load()
        {
            MyGlows = new Dictionary<string, int>();
            assets = new List<Asset<Texture2D>>();
            string assetsPath;
            int ia = 0;
            foreach (Type type in typeof(NeonDawn).Assembly.GetTypes().OrderBy((Type t) => t.FullName, StringComparer.InvariantCulture))
            {
                assetsPath = type.FullName.Replace('.', '/') + "_Glow";
                if (!type.IsAbstract && type.IsSubclassOf(typeof(ModItem)) && ModContent.HasAsset(assetsPath))
                {
                    ia++;
                    assets.Add(ModContent.Request<Texture2D>(assetsPath));
                    MyGlows.Add(type.Name, TextureAssets.GlowMask.Length - 1 + ia);
                }
            }
            List<Asset<Texture2D>> assetsGlow = new List<Asset<Texture2D>>(TextureAssets.GlowMask);
            assetsGlow.AddRange(assets);
            TextureAssets.GlowMask = assetsGlow.ToArray();

            Main.versionNumber = "v1.5.0.1";
            Main.highVersionColor = Color.Black;
            Main.tileCut[231] = false;
            if (!Main.dedServ)
            {
                GreenShader = ModContent.Request<Effect>("NeonDawn/Effects/GreenShader").Value;
                Filters.Scene["GreenShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/GreenShader").Value), "GreenShader"), EffectPriority.Medium);
                Filters.Scene["GreenShader"].Load();
                RedShader = ModContent.Request<Effect>("NeonDawn/Effects/RedShader").Value;
                Filters.Scene["RedShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/RedShader").Value), "RedShader"), EffectPriority.Medium);
                Filters.Scene["RedShader"].Load();
                GradualGreenShader = ModContent.Request<Effect>("NeonDawn/Effects/GradualGreenShader").Value;
                Filters.Scene["GradualGreenShader"] = new Filter(new TestScreenShaderData(new Ref<Effect>(ModContent.Request<Effect>("NeonDawn/Effects/GradualGreenShader").Value), "GreenShader"), EffectPriority.Medium);
                Filters.Scene["GradualGreenShader"].Load();
                const string SOUND = "Sounds/Music/";
                MusicLoader.AddMusic(this, SOUND + "MoomFightOne");
                MusicLoader.AddMusic(this, SOUND + "MoomFightTwo");
                MusicLoader.AddMusic(this, "Sounds/Music/Glimmers Of Vibrance");
                string[] s = StringToArray(Name + " v" + ((Version != null) ? Version.ToString() : null));
                myNewName = StaticFunction.StringToColorString(
                     //��������ɫ
                     new Color[] { new Color(245, 255, 237), new Color(207, 219, 252), new Color(155, 173, 183) },
                     s);
                myNewName = StringToColorString(
                    new Color[] { new Color(245, 255, 237), new Color(207, 219, 252), new Color(155, 173, 183) }, s);
                for (int i = 0; i < icon.Length; i++)
                {
                    icon[i] = ModContent.Request<Texture2D>("NeonDawn/Icons/Frameicon" + i);
                }
                PropagandaUIState = new PropagandaUIState();
                PropagandaUIState.Activate();
                PropagandaUI = new UserInterface();
                PropagandaUI.SetState(PropagandaUIState);

                ExtractUIState = new ExtractUIState();
                ExtractUIState.Activate();
                ExtractUI = new UserInterface();
                ExtractUI.SetState(ExtractUIState);

                BookState = new BookState();
                BookState.Activate();
                Book = new UserInterface();
                Book.SetState(BookState);

                On_Main.DrawMenu += On_Main_DrawMenu;
            }
            base.Load();
        }

        private void On_Main_DrawMenu(On_Main.orig_DrawMenu orig, Main self, GameTime gameTime)
        {
            if ((PropagandaUI == null || PropagandaUIState == null) && Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont").Value != null)
            {
                PropagandaUIState = new PropagandaUIState();
                PropagandaUIState.Activate();
                PropagandaUI = new UserInterface();
                PropagandaUI.SetState(PropagandaUIState);
            }

            if (Main.menuMode == 0 && MyMenu.IsSelect)
            {
                PropagandaUI?.Update(gameTime);
                PropagandaUI?.Draw(Main.spriteBatch, gameTime);
            }

            if (ModName != null && IconImage != null)
            {
                ModName.Text = myNewName[myNewName.Length - 1 - nameFrame];
                IconImage.SetImage(icon[iconFrame]);
            }
            else
            {
                FieldInfo uiStateField = Main.MenuUI.GetType().GetField("_history", BindingFlags.NonPublic | BindingFlags.Instance);
                List<UIState> _history = (List<UIState>)uiStateField.GetValue(Main.MenuUI);
                UIState myMod = new UIState();
                for (int x = 0; x < _history.Count; x++)
                {
                    myMod = _history[x];
                    if (myMod.GetType().FullName == "Terraria.ModLoader.UI.UIMods")
                    {
                        List<UIElement> elements = (List<UIElement>)myMod.GetType().GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(myMod);
                        List<UIElement> uiElements = (List<UIElement>)elements[0].GetType().GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(elements[0]);
                        UIPanel uiPanel = (UIPanel)uiElements[0];
                        List<UIElement> myModUIPanel = uiPanel.GetType().GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(uiPanel) as List<UIElement>;
                        UIList uiList = (UIList)myModUIPanel[0];
                        List<UIElement> myUIModItem;
                        for (int i = 0; i < uiList._items.Count; i++)
                        {
                            if (uiList._items[i].GetType().GetField("_mod", BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(uiList._items[i]).ToString() == Name)
                            {
                                typeof(UIPanel).GetField("_borderTexture", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(uiList._items[i], Assets.Request<Texture2D>("Images/UIModItem/PanelBorder", AssetRequestMode.ImmediateLoad));
                                typeof(UIPanel).GetField("_backgroundTexture", BindingFlags.NonPublic | BindingFlags.Instance).SetValue(uiList._items[i], Assets.Request<Texture2D>("Images/UIModItem/PanelBackground", AssetRequestMode.ImmediateLoad));
                                ((UIPanel)uiList._items[i]).BackgroundColor = Color.White;
                                ((UIPanel)uiList._items[i]).BorderColor = Color.White;

                                myUIModItem = (List<UIElement>)uiList._items[i].GetType().GetField("Elements", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(uiList._items[i]);

                                if (!(myUIModItem.First() is MyUIImage))
                                {
                                    MyUIImage myUIImage = new MyUIImage(Assets.Request<Texture2D>("Images/UIModItem/UIModItemBackground", AssetRequestMode.ImmediateLoad).Value);
                                    typeof(UIElement).GetProperty("Parent").GetSetMethod(true).Invoke(myUIImage, new object[] { uiList._items[i] });
                                    myUIModItem.Insert(0, myUIImage);
                                    myUIImage.Recalculate();
                                }
                                float _modIconAdjust = (ModContent.Request<Texture2D>("NeonDawn/icon").Value == null ? 0 : 85);
                                UIElement badUnloader = myUIModItem.Find((UIElement e) => e.GetType().FullName == "Terraria.ModLoader.UI.UIHoverImage" && e.Top.Pixels == 3);
                                for (int j = 0; j < myUIModItem.Count; j++)
                                {
                                    string name = DisplayName + " v" + ((Version != null) ? Version.ToString() : null),
                                        myName = myNewName[myNewName.Length - 1 - nameFrame];

                                    if (((myUIModItem[j] is UIText) && (myUIModItem[j] as UIText).Text == name) || (badUnloader != null && myUIModItem[j] is ModNameText))
                                    {
                                        myUIModItem.RemoveAt(j);
                                        ModNameText modNameText = new ModNameText(myName, 1f, Color.White, Assets.Request<DynamicSpriteFont>("Fonts/SourceHanSansFont", AssetRequestMode.ImmediateLoad).Value);
                                        modNameText.Left = new StyleDimension(_modIconAdjust + (badUnloader == null ? 0f : 35f), 0f);
                                        modNameText.Top.Pixels = 5f;
                                        uiList._items[i].Append(modNameText);
                                        ModName = modNameText;
                                    }
                                    else if (myUIModItem[j] is ModNameText)
                                    {
                                        ((ModNameText)myUIModItem[j]).Text = myName;
                                    }
                                    if (myUIModItem[j] is UIImage)
                                    {
                                        if (myUIModItem[j].Width.Pixels == 80 && myUIModItem[j].Height.Pixels == 80)
                                        {
                                            IconImage = myUIModItem[j] as UIImage;
                                            IconImage.SetImage(icon[iconFrame]);
                                        }
                                    }
                                }
                                uiList._items[i].Recalculate();
                            }
                        }
                    }
                }
            }

            time++;
            if (time % 10 == 0)
            {
                nameFrame++;
                iconFrame++;
                time = 0;
            }
            if (nameFrame >= myNewName.Length)
                nameFrame = 0;
            if (iconFrame > 43)
                iconFrame = 0;
            orig(self, gameTime);
        }

        private static string[] myNewName;

        public override void Unload()
        {
            Main.versionNumber = VanillaVersion;
            Main.versionNumber2 = VanillaVersion2;
            List<Asset<Texture2D>> assetsGlow = new List<Asset<Texture2D>>(TextureAssets.GlowMask);
            assetsGlow.RemoveAll(x => assets.Find(y => y == x) != default(Asset<Texture2D>));
            TextureAssets.GlowMask = assetsGlow.ToArray();
            On_Main.DrawMenu -= On_Main_DrawMenu;
            Dictionary<string, IPlayerResourcesDisplaySet> _sets =
                    (Dictionary<string, IPlayerResourcesDisplaySet>)
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                    GetValue(Main.ResourceSetsManager);
            string str = "Images\\UI\\PlayerResourceSets\\FancyClassic";
            //�޸�ħ������ͼ����ԭ��
            _sets["New"].GetType().GetField("_starFill", BindingFlags.Instance | BindingFlags.NonPublic).
                SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Star_Fill"));
            //�޸�����(����ˮ��)����ͼ����ԭ��
            // _sets["New"].GetType().GetField("_heartFill", BindingFlags.Instance | BindingFlags.NonPublic).
            //SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Fill"));
            //�޸�����(������)����ͼ����ԭ��
            _sets["New"].GetType().GetField("_heartFillHoney", BindingFlags.Instance | BindingFlags.NonPublic).
                     SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Fill_B"));
            _sets["New"].GetType().GetField("_heartLeft", BindingFlags.Instance | BindingFlags.NonPublic).
               SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Left"));
            _sets["New"].GetType().GetField("_heartMiddle", BindingFlags.Instance | BindingFlags.NonPublic).
               SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Middle"));
            _sets["New"].GetType().GetField("_heartRight", BindingFlags.Instance | BindingFlags.NonPublic).
               SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Right"));
            _sets["New"].GetType().GetField("_heartRightFancy", BindingFlags.Instance | BindingFlags.NonPublic).
               SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Right_Fancy"));
            typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                SetValue(Main.ResourceSetsManager, _sets);
            base.Unload();
        }

        private class ModNameText : Terraria.UI.UIElement
        {
            public string Text;
            public float Size;
            public Color Color;
            public DynamicSpriteFont DynamicSpriteFont;

            public ModNameText(string text, float size, Color color, DynamicSpriteFont dynamicSpriteFont)
            {
                Text = text;
                Size = size;
                Color = color;
                DynamicSpriteFont = dynamicSpriteFont;
            }

            public override void Draw(SpriteBatch spriteBatch)
            {
                CalculatedStyle dimensions = GetDimensions();
                Effect effect = NeonDawnUtils.GetEffect("NameShader");
                effect.Parameters["uTime"].SetValue(-Main.GlobalTimeWrappedHourly);
                effect.Parameters["uColor"].SetValue(new Color(255, 1, 203).ToVector3());
                effect.Parameters["uSecondaryColor"].SetValue(new Color(108, 133, 161).ToVector3());
                Main.spriteBatch.End();
                Main.spriteBatch.Begin(0, BlendState.Additive, null, null, null, effect, Main.UIScaleMatrix);
                ChatManager.DrawColorCodedStringWithShadow(spriteBatch, this.DynamicSpriteFont, "NeonDawn", new Vector2(dimensions.X, dimensions.Y), Color.White, 0f, Vector2.Zero, new Vector2(this.Size), -1f, 2f);
                Main.spriteBatch.End();
                Main.spriteBatch.Begin(0, null, null, null, null, null, Main.UIScaleMatrix);
                Main.spriteBatch.End();
                Main.spriteBatch.Begin(0, BlendState.Additive, null, null, null, effect, Main.UIScaleMatrix);
                for (float i = -0.00000001f; i <= 0.000000014f; i += 0.00000017f)
                {
                    ChatManager.DrawColorCodedStringWithShadow(spriteBatch, this.DynamicSpriteFont, "NeonDawn", new Vector2(dimensions.X, dimensions.Y) + Utils.RotatedBy(Utils.ToRotationVector2(i), (double)(Main.GlobalTimeWrappedHourly * 1f), default(Vector2)) * Helper.Osc(1f, 2f, 2f, 0f), Color.Lerp(Color.DarkViolet, Color.DarkCyan, Helper.Osc01(1f, 0f)) * 1.9f, 0f + Main.rand.NextFloatRange(0f), Vector2.Zero, new Vector2(this.Size), -1f, 2f);
                }
                for (float j = -0.00000001f; j <= 0.000000014f; j += 0.00000017f)
                {
                    ChatManager.DrawColorCodedStringWithShadow(spriteBatch, this.DynamicSpriteFont, "NeonDawn", new Vector2(dimensions.X, dimensions.Y) + Utils.RotatedBy(Utils.ToRotationVector2(j), -(double)Main.GlobalTimeWrappedHourly * 2.0, default(Vector2)) * Helper.Osc(3f, 2f, 1f, 0.5f), Color.Lerp(Color.DarkViolet, Color.DarkCyan, Helper.Osc01(3f, 0f)) * 0.9f, 0f + Main.rand.NextFloatRange(0f), Vector2.Zero, new Vector2(this.Size), 0f, 1f);
                }
                Main.spriteBatch.End();
                Main.spriteBatch.Begin(0, BlendState.Additive, null, null, null, effect, Main.UIScaleMatrix);
                effect.Parameters["uColor"].SetValue(new Color(30, 135, 165).ToVector3());
                effect.Parameters["uSecondaryColor"].SetValue(new Color(132, 1, 83).ToVector3());
                Main.spriteBatch.End();
                Main.spriteBatch.Begin(0, null, null, null, null, null, Main.UIScaleMatrix);
                base.Draw(spriteBatch);
            }
        }

        public static string[] StringToColorString(Color[] colors, string[] texts)
        {
            List<Color> sortColor = colors.ToList();
            sortColor.Sort((now, next) => (now.R * 0.299f + now.G * 0.587f + now.B * 0.114f).CompareTo(next.R * 0.299f + next.G * 0.587f + next.B * 0.114f));
            Color[] needColor = new Color[sortColor.Count];
            int iAdd = 0;
            int colorCount = needColor.Length / 2;
            for (int i = 0; i <= colorCount; i++)
            {
                if ((colorCount + i) < needColor.Length)
                {
                    needColor[colorCount + i] = sortColor[iAdd];
                }
                if (iAdd < (sortColor.Count - 1))
                    iAdd++;

                needColor[colorCount - i] = sortColor[iAdd];
                if (iAdd < (sortColor.Count - 1))
                    iAdd++;
            }
            List<string> s = new List<string>();
            string add;
            for (int x = 0; x < needColor.Length; x++)
            {
                add = "";
                for (int i = 0; i < texts.Length; i++)
                {
                    add += "[c/" + needColor[(x + i) % needColor.Length].Hex3() + ":" + texts[i] + "]";
                }
                s.Add(add);
            }
            return s.ToArray();
        }

        [Obsolete]
        public override void AddRecipes()
        {
            base.AddRecipes();
            ExtractSystem.Load();
        }

        public static string[] StringToArray(string text)
        {
            string[] s = new string[text.Length];
            for (int i = 0; i < s.Length; i++)
                s[i] = text[i].ToString();
            return s;
        }

        private static float ColorTimer;

        public static Color LemonColor()
        {
            Color ColorA = new Color(255, 255, 255);
            Color ColorB = new Color(255, 248, 0);
            Color ColorC = new Color(255, 202, 0);
            Color ColorD = new Color(128, 255, 0);
            Color ColorE = new Color(160, 170, 0);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }

        public static Color MagicCraftItemColor()
        {
            Color ColorA = new Color(245, 154, 220);
            Color ColorB = new Color(175, 174, 237);
            Color ColorC = new Color(133, 132, 205);
            Color ColorD = new Color(97, 96, 161);
            Color ColorE = new Color(111, 161, 188);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }

        public static Color AgeleSeekerColor()
        {
            Color ColorA = new Color(0, 0, 0);
            Color ColorB = new Color(42, 39, 82);
            Color ColorC = new Color(164, 82, 195);
            Color ColorD = new Color(203, 219, 252);
            Color ColorE = new Color(255, 255, 255);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }

        public static Color SAETColor()
        {
            Color ColorA = new Color(125, 34, 91);
            Color ColorB = new Color(255, 255, 255);
            Color ColorC = new Color(188, 62, 73);
            Color ColorD = new Color(255, 255, 255);
            Color ColorE = new Color(233, 154, 90);
            Color ColorF = new Color(255, 255, 255);
            Color ColorG = new Color(255, 229, 122);
            Color ColorH = new Color(255, 255, 255);
            Color ColorI = new Color(154, 225, 110);
            Color ColorJ = new Color(255, 255, 255);
            Color ColorK = new Color(65, 234, 242);
            Color ColorL = new Color(255, 255, 255);
            Color ColorM = new Color(255, 99, 239);
            Color ColorN = new Color(255, 255, 255);
            ColorTimer += 1f;
            if (ColorTimer >= 700)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 50)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 50);
            else if (ColorTimer < 100)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 50) / 50);
            else if (ColorTimer < 150)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 100) / 50);
            else if (ColorTimer < 200)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 150) / 50);
            else if (ColorTimer < 250)
                return Color.Lerp(ColorE, ColorF, (ColorTimer - 200) / 50);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorF, ColorG, (ColorTimer - 250) / 50);
            else if (ColorTimer < 350)
                return Color.Lerp(ColorG, ColorH, (ColorTimer - 300) / 50);
            else if (ColorTimer < 400)
                return Color.Lerp(ColorH, ColorI, (ColorTimer - 350) / 50);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorI, ColorJ, (ColorTimer - 400) / 50);
            else if (ColorTimer < 500)
                return Color.Lerp(ColorJ, ColorK, (ColorTimer - 450) / 50);
            else if (ColorTimer < 550)
                return Color.Lerp(ColorK, ColorL, (ColorTimer - 500) / 50);
            else if (ColorTimer < 600)
                return Color.Lerp(ColorL, ColorM, (ColorTimer - 550) / 50);
            else if (ColorTimer < 650)
                return Color.Lerp(ColorM, ColorN, (ColorTimer - 600) / 50);
            else
                return Color.Lerp(ColorN, ColorA, (ColorTimer - 650) / 50);
        }

        public static Color EnterVoucherColor()
        {
            Color ColorA = new Color(36, 35, 37);
            Color ColorB = new Color(74, 69, 70);
            Color ColorC = new Color(130, 119, 115);
            Color ColorD = new Color(64, 92, 108);
            Color ColorE = new Color(73, 164, 196);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }

        public static Color VIII()
        {
            Color ColorA = new Color(44, 232, 245);
            Color ColorB = new Color(0, 149, 233);
            Color ColorC = new Color(18, 73, 137);
            Color ColorD = new Color(18, 41, 137);
            Color ColorE = new Color(151, 179, 247);
            ColorTimer += 1f;
            if (ColorTimer >= 750)
            {
                ColorTimer = 0;
            }
            if (ColorTimer < 150)
                return Color.Lerp(ColorA, ColorB, ColorTimer / 150);
            else if (ColorTimer < 300)
                return Color.Lerp(ColorB, ColorC, (ColorTimer - 150) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorC, ColorD, (ColorTimer - 300) / 150);
            else if (ColorTimer < 450)
                return Color.Lerp(ColorD, ColorE, (ColorTimer - 450) / 150);
            else
                return Color.Lerp(ColorE, ColorA, (ColorTimer - 600) / 150);
        }

        public static Color TheGutsAndGlory()
        {
            return Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 1f;
        }

        public class ModColor
        {
            public static Color RGBColor(bool NoAuto = false, float Time = 0f)
            {
                Color ColorA;
                ColorA = new Color(255, 0, 0);
                Color ColorB;
                ColorB = new Color(255, 255, 0);
                Color ColorC;
                ColorC = new Color(0, 255, 0);
                Color ColorD;
                ColorD = new Color(0, 255, 255);
                Color ColorE;
                ColorE = new Color(0, 0, 255);
                Color ColorF;
                ColorF = new Color(255, 0, 255);
                NeonDawn.ModColor.specialColorTimer[0] += 1f;
                if (NoAuto)
                {
                    NeonDawn.ModColor.specialColorTimer[5] = Time;
                }
                while (NeonDawn.ModColor.specialColorTimer[5] >= 600f)
                {
                    NeonDawn.ModColor.specialColorTimer[5] -= 600f;
                }
                while (NeonDawn.ModColor.specialColorTimer[5] < 0f)
                {
                    NeonDawn.ModColor.specialColorTimer[5] += 600f;
                }
                if (NeonDawn.ModColor.specialColorTimer[5] < 100f)
                {
                    return Color.Lerp(ColorA, ColorB, NeonDawn.ModColor.specialColorTimer[5] / 100f);
                }
                if (NeonDawn.ModColor.specialColorTimer[5] < 200f)
                {
                    return Color.Lerp(ColorB, ColorC, (NeonDawn.ModColor.specialColorTimer[5] - 100f) / 100f);
                }
                if (NeonDawn.ModColor.specialColorTimer[5] < 300f)
                {
                    return Color.Lerp(ColorC, ColorD, (NeonDawn.ModColor.specialColorTimer[5] - 200f) / 100f);
                }
                if (NeonDawn.ModColor.specialColorTimer[5] < 400f)
                {
                    return Color.Lerp(ColorD, ColorE, (NeonDawn.ModColor.specialColorTimer[5] - 300f) / 100f);
                }
                if (NeonDawn.ModColor.specialColorTimer[5] < 500f)
                {
                    return Color.Lerp(ColorE, ColorF, (NeonDawn.ModColor.specialColorTimer[5] - 400f) / 100f);
                }
                return Color.Lerp(ColorF, ColorA, (NeonDawn.ModColor.specialColorTimer[5] - 500f) / 100f);
            }

            private static readonly float[] specialColorTimer = new float[1];
        }
    }

    public static class NeonDawnUtils
    {
        public static Effect GetEffect(string path)
        {
            return ModContent.Request<Effect>("NeonDawn/Effects/" + path, AssetRequestMode.ImmediateLoad).Value;
        }
    }

    public static class fxxksptml
    {
    }
}