﻿using Microsoft.Xna.Framework;
using ReLogic.Utilities;
using System;
using System.Runtime.CompilerServices;
using Terraria;
using Terraria.Audio;
using Terraria.Utilities;

namespace NeonDawn
{
    public static class Helper
    {
        public static SlotId PlaySound(SoundStyle style, Vector2 position, float volume = 1f, float pitch = 0f, float pitchVariance = 0f)
        {
            style = style.WithVolumeScale(volume);
            style = style.WithPitchOffset(pitch);
            style.PitchVariance = pitchVariance;
            return SoundEngine.PlaySound(style, position);
        }
        public static SlotId PlaySound(SoundStyle style, float posX, float posY, float volume = 1f, float pitch = 0f)
        {
            return PlaySound(style, new Vector2(posX, posY), volume, pitch);
        }
        public static double GaussianRandom(double mu, double sigma, UnifiedRandom random = null)
        {
            double num = -2.0 * Math.Log(random.NextDouble());
            double v = 6.283185307179586 * random.NextDouble();
            return Math.Sqrt(num) * Math.Cos(v) * sigma + mu;
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Osc(float from, float to, float speed = 1f, float offset = 0f)
        {
            float dif = (to - from) / 2f;
            return from + dif + dif * (float)Math.Sin((double)(Main.GlobalTimeWrappedHourly * speed + offset));
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Osc01(float speed = 1f, float offset = 0f)
        {
            return Helper.Osc(0f, 1f, speed, offset);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector2 Normalized(this Vector2 vec)
        {
            return Utils.SafeNormalize(vec, Vector2.Zero);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void NewDust(Rectangle rect, Vector2 speed, int type, int count = 1, int chance = 100, float size = 1f, Color color = default(Color), int alpha = 0, bool noGrav = true, bool noLight = false, Action<Dust> callback = null)
        {
            for (int i = 0; i < count; i++)
            {
                if (Main.rand.Next(100) <= chance)
                {
                    Dust dust = Dust.NewDustDirect(rect.GetPosition(), rect.Width, rect.Height, type, speed.X, speed.Y, alpha, color, size);
                    dust.noGravity = noGrav;
                    dust.noLight = noLight;
                    if (callback != null)
                    {
                        callback(dust);
                    }
                }
            }
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void NewDust(Vector2 position, Vector2 speed, int type, int count = 1, int chance = 100, float size = 1f, int w = 1, int h = 1, Color color = default(Color), int alpha = 0, bool noGrav = true, bool noLight = false, Action<Dust> callback = null)
        {
            Helper.NewDust(new Rectangle((int)position.X, (int)position.Y, w, h), speed, type, count, chance, size, color, alpha, noGrav, noLight, callback);
        }
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector2 GetPosition(this Rectangle rect)
        {
            return new Vector2((float)rect.X, (float)rect.Y);
        }
        public static Color MultiplyAlpha(this Color c, float alpha)
        {
            return new Color((int)c.R, (int)c.G, (int)c.B, (int)((float)c.A / 255f * MathHelper.Clamp(alpha, 0f, 1f) * 255f));
        }
        public static float NextFloatRange(this UnifiedRandom rng, float range)
        {
            return Utils.NextFloat(rng, -range, range);
        }
    }
}
