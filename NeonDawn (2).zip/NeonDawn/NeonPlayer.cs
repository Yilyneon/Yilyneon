﻿using System.Collections.Generic;
using System.Reflection;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.NPCs;

using Terraria;
using Terraria.GameContent.UI.ResourceSets;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;

namespace NeonDawn
{
    public class NeonPlayer : ModPlayer
    {
        public bool Dragged;

        public override void OnEnterWorld()
        {
            base.OnEnterWorld();
            MeleeMoon.MMoon = null;
        }

        public static NeonPlayer ModPlayer(Player player)
        {
            return player.GetModPlayer<NeonPlayer>();
        }

        public override void SaveData(TagCompound tagCompound)
        {
            List<string> boost = new List<string>();
            if (this.Miracleheart)
            {
                boost.Add("miracleheart");
            }
            if (this.WhiteMana)
            {
                boost.Add("whiteMana");
            }
            tagCompound.Add("boost", boost);

            base.SaveData(tagCompound);
        }

        public override void ModifyScreenPosition()
        {
            if (NPC.AnyNPCs(ModContent.NPCType<SatelliteSmall>()))
            {
                foreach (NPC npc in Main.npc)
                {
                    if (npc.type == ModContent.NPCType<SatelliteSmall>())
                    {
                        if (npc.active && npc.life > 0)
                        {
                            if (npc.ai[3] == Main.LocalPlayer.whoAmI)
                            {
                                Main.screenPosition = npc.Center - new Vector2(Main.screenWidth / 2, Main.screenHeight / 2);
                            }
                        }
                    }
                }
            }
        }

        public override void LoadData(TagCompound tag)
        {
            IList<string> boost = tag.GetList<string>("boost");
            this.Miracleheart = boost.Contains("miracleheart");
            this.WhiteMana = boost.Contains("whiteMana");
        }

        public override void OnRespawn()
        {
            base.OnRespawn();
            Player.statLife = Player.statLifeMax;
        }

        public override void PostUpdateMiscEffects()
        {
            Player.statLifeMax2 += (this.Miracleheart ? 50 : 0);
            Player.statManaMax2 += (this.WhiteMana ? 50 : 0);
            if (base.Player.whoAmI == Main.myPlayer)
            {
                int HealthBoost = (this.Miracleheart ? 1 : 0);
                int ManaBoost = (this.WhiteMana ? 1 : 0);
                if (HealthBoost == 1)
                {
                    Dictionary<string, IPlayerResourcesDisplaySet> _sets =
                    (Dictionary<string, IPlayerResourcesDisplaySet>)
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                    GetValue(Main.ResourceSetsManager);
                    //修改生命(生命果)的贴图
                    _sets["New"].GetType().GetField("_heartLeft", BindingFlags.Instance | BindingFlags.NonPublic).
                        SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/MiracleHeartLeft"));
                    _sets["New"].GetType().GetField("_heartMiddle", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/MiracleHeartMiddle"));
                    _sets["New"].GetType().GetField("_heartRight", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/MiracleHeartRight"));
                    _sets["New"].GetType().GetField("_heartRightFancy", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/MiracleHeartRightFancy"));
                    _sets["New"].GetType().GetField("_heartFillHoney", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/HeartMiracle"));
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                        SetValue(Main.ResourceSetsManager, _sets);
                }
                else
                {
                    string str = "Images\\UI\\PlayerResourceSets\\FancyClassic";
                    Dictionary<string, IPlayerResourcesDisplaySet> _sets =
                    (Dictionary<string, IPlayerResourcesDisplaySet>)
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                    GetValue(Main.ResourceSetsManager);
                    //修改生命(生命果)的贴图换回原版
                    _sets["New"].GetType().GetField("_heartFillHoney", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Fill_B"));
                    _sets["New"].GetType().GetField("_heartLeft", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Left"));
                    _sets["New"].GetType().GetField("_heartMiddle", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Middle"));
                    _sets["New"].GetType().GetField("_heartRight", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Right"));
                    _sets["New"].GetType().GetField("_heartRightFancy", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Heart_Right_Fancy"));
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                        SetValue(Main.ResourceSetsManager, _sets);
                }
                if (ManaBoost == 1)
                {
                    Dictionary<string, IPlayerResourcesDisplaySet> _sets =
                   (Dictionary<string, IPlayerResourcesDisplaySet>)
                   typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                    GetValue(Main.ResourceSetsManager);
                    //修改魔力的贴图
                    _sets["New"].GetType().GetField("_starFill", BindingFlags.Instance | BindingFlags.NonPublic).
                        SetValue(_sets["New"], Mod.Assets.Request<Texture2D>("Images/Original/ManaWhite"));
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                       SetValue(Main.ResourceSetsManager, _sets);
                }
                else
                {
                    string str = "Images\\UI\\PlayerResourceSets\\FancyClassic";
                    Dictionary<string, IPlayerResourcesDisplaySet> _sets =
                   (Dictionary<string, IPlayerResourcesDisplaySet>)
                   typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                    GetValue(Main.ResourceSetsManager);
                    //修改魔力的贴图换回原版
                    _sets["New"].GetType().GetField("_starFill", BindingFlags.Instance | BindingFlags.NonPublic).
                        SetValue(_sets["New"], Main.Assets.Request<Texture2D>(str + "\\Star_Fill"));
                    typeof(PlayerResourceSetsManager).GetField("_sets", BindingFlags.Instance | BindingFlags.NonPublic).
                     SetValue(Main.ResourceSetsManager, _sets);
                }
            }
        }

        public bool Miracleheart = false;
        public bool WhiteMana = false;
        public bool Miraclehearttrue;
        public int VenusStage;

        public override void ResetEffects()
        {
            if (Miracleheart)
            {
                Miraclehearttrue = true;
            }
            if (Miraclehearttrue)
            {
            }
            else
            {
            }
            Dragged = false;
        }
    }
}