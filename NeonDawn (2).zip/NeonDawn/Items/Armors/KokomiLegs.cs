﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Items.Armors
{
    [AutoloadEquip(EquipType.Legs)]
    public class KokomiLegs : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "珊瑚木履");
            //Tooltip.AddTranslation(7,
            //    "绝佳的cosplay饰品");

            //DisplayName.AddTranslation(1, "Cather Legs");
            //Tooltip.AddTranslation(1,
            //    "Great cosplay Costume");

            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 174, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            Item.maxStack = 1;
            base.Item.vanity = true;
            Item.value = Item.sellPrice(1, 2);
        }

        public override void AddRecipes()
        {
            CreateRecipe().

                Register();
        }
    }
}