﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Items.Armors
{
    [AutoloadEquip(EquipType.Body)]
    public class KokomiArmor : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "珍珠仙衣");
            //DisplayName.AddTranslation(1, "CatherArmor");
            //Tooltip.AddTranslation(7,
            //    "绝佳的cosplay饰品");
            //Tooltip.AddTranslation(1, "Pearl skirt" +
            //    "Great cosplay Costume");

            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 174, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            Item.maxStack = 1;
            base.Item.vanity = true;
            Item.value = Item.sellPrice(2, 2);
        }

        public override void UpdateEquip(Player player)
        {
            if (player.statLife < 50)
            {
                player.moveSpeed += 0.05f;
                player.endurance += 0.02f;
            }
        }

        public override void AddRecipes()
        {
            CreateRecipe().

                Register();
        }
    }
}