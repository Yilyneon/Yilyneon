﻿using Microsoft.Xna.Framework;

using System;
using System.Collections.Generic;

using Terraria;
using Terraria.Graphics.Shaders;
using Terraria.ModLoader;

namespace NeonDawn.Items.Armors
{
    [AutoloadEquip(new EquipType[] { EquipType.Head })]
    public class KokomiHead : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "海龙之角");
            //Tooltip.AddTranslation(7,
            //    "绝佳的cosplay饰品");

            //DisplayName.AddTranslation(1, "Cather Head");
            //Tooltip.AddTranslation(1,
            //"Great cosplay Costume");

            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 174, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            Item.maxStack = 1;
            base.Item.vanity = true;
            Item.value = Item.sellPrice(0, 5);
        }

        public override void UpdateEquip(Player player)
        {
            if (ModContent.GetInstance<NeonConfig>().eyeseffectOpen)
            {
                int num = 0;
                num += player.bodyFrame.Y / 56;
                if (num >= Main.OffsetsPlayerHeadgear.Length)
                {
                    num = 0;
                }
                Vector2 vector = new Vector2((float)(player.width / 2), (float)(player.height / 2)) + Main.OffsetsPlayerHeadgear[num] + (player.MountedCenter - player.Center);
                Vector2 value;
                float y;
                player.sitting.GetSittingOffsetInfo(player, out value, out y);
                vector += value + new Vector2(0f, y);
                float num2 = -11.5f * player.gravDir;
                if (player.gravDir == -1f)
                {
                    num2 -= 4f;
                }
                Vector2 vector2 = new Vector2((float)(3 * player.direction - ((player.direction == 1) ? 1 : 0)), num2) + Vector2.UnitY * player.gfxOffY + vector;
                Vector2 vector3 = new Vector2((float)(3 * player.shadowDirection[1] - ((player.direction == 1) ? 1 : 0)), num2) + vector;
                Vector2 vector4 = Vector2.Zero;
                if (player.mount.Active && player.mount.Cart)
                {
                    int num3 = Math.Sign(player.velocity.X);
                    if (num3 == 0)
                    {
                        num3 = player.direction;
                    }
                    vector4 = new Vector2(MathHelper.Lerp(0f, -8f, player.fullRotation / 0.7853982f), MathHelper.Lerp(0f, 2f, Math.Abs(player.fullRotation / 0.7853982f))).RotatedBy((double)player.fullRotation, default(Vector2));
                    if (num3 == Math.Sign(player.fullRotation))
                    {
                        vector4 *= MathHelper.Lerp(1f, 0.6f, Math.Abs(player.fullRotation / 0.7853982f));
                    }
                }
                if (player.fullRotation != 0f)
                {
                    vector2 = vector2.RotatedBy((double)player.fullRotation, player.fullRotationOrigin);
                    vector3 = vector3.RotatedBy((double)player.fullRotation, player.fullRotationOrigin);
                }
                float num4 = 0f;
                Vector2 vector5 = player.position + vector2 + vector4;
                Vector2 vector6 = player.oldPosition + vector3 + vector4;
                vector6.Y -= num4 / 2f;
                vector5.Y -= num4 / 2f;
                float num5 = 1f;

                int num6 = (int)Vector2.Distance(vector5, vector6) / 3 + 1;
                if (Vector2.Distance(vector5, vector6) % 3f != 0f)
                {
                    num6++;
                }
                for (float num7 = 1f; num7 <= (float)num6; num7 += 1f)
                {
                    Dust dust = Main.dust[Dust.NewDust(player.Center, 0, 0, 181, 0f, 0f, 0, (new Color(Main.DiscoR, 174, 255)), 1f)];
                    dust.position = Vector2.Lerp(vector6, vector5, num7 / (float)num6);
                    dust.noGravity = true;
                    dust.velocity = Vector2.Zero;
                    dust.customData = player;
                    dust.scale = num5;
                    dust.shader = GameShaders.Armor.GetSecondaryShader(player.cYorai, player);
                    if (dust.customData != null && dust.customData is Player)
                    {
                        Player player3 = (Player)dust.customData;
                        dust.position += player3.position - player3.oldPosition;
                        dust.customData = null;
                    }
                }
            }
        }

        public override void UpdateVanity(Player player)
        {
            if (ModContent.GetInstance<NeonConfig>().eyeseffectOpen)
            {
                int num = 0;
                num += player.bodyFrame.Y / 56;
                if (num >= Main.OffsetsPlayerHeadgear.Length)
                {
                    num = 0;
                }
                Vector2 vector = new Vector2((float)(player.width / 2), (float)(player.height / 2)) + Main.OffsetsPlayerHeadgear[num] + (player.MountedCenter - player.Center);
                Vector2 value;
                float y;
                player.sitting.GetSittingOffsetInfo(player, out value, out y);
                vector += value + new Vector2(0f, y);
                float num2 = -11.5f * player.gravDir;
                if (player.gravDir == -1f)
                {
                    num2 -= 4f;
                }
                Vector2 vector2 = new Vector2((float)(3 * player.direction - ((player.direction == 1) ? 1 : 0)), num2) + Vector2.UnitY * player.gfxOffY + vector;
                Vector2 vector3 = new Vector2((float)(3 * player.shadowDirection[1] - ((player.direction == 1) ? 1 : 0)), num2) + vector;
                Vector2 vector4 = Vector2.Zero;
                if (player.mount.Active && player.mount.Cart)
                {
                    int num3 = Math.Sign(player.velocity.X);
                    if (num3 == 0)
                    {
                        num3 = player.direction;
                    }
                    vector4 = new Vector2(MathHelper.Lerp(0f, -8f, player.fullRotation / 0.7853982f), MathHelper.Lerp(0f, 2f, Math.Abs(player.fullRotation / 0.7853982f))).RotatedBy((double)player.fullRotation, default(Vector2));
                    if (num3 == Math.Sign(player.fullRotation))
                    {
                        vector4 *= MathHelper.Lerp(1f, 0.6f, Math.Abs(player.fullRotation / 0.7853982f));
                    }
                }
                if (player.fullRotation != 0f)
                {
                    vector2 = vector2.RotatedBy((double)player.fullRotation, player.fullRotationOrigin);
                    vector3 = vector3.RotatedBy((double)player.fullRotation, player.fullRotationOrigin);
                }
                float num4 = 0f;
                Vector2 vector5 = player.position + vector2 + vector4;
                Vector2 vector6 = player.oldPosition + vector3 + vector4;
                vector6.Y -= num4 / 2f;
                vector5.Y -= num4 / 2f;
                float num5 = 1f;

                int num6 = (int)Vector2.Distance(vector5, vector6) / 3 + 1;
                if (Vector2.Distance(vector5, vector6) % 3f != 0f)
                {
                    num6++;
                }
                for (float num7 = 1f; num7 <= (float)num6; num7 += 1f)
                {
                    Dust dust = Main.dust[Dust.NewDust(player.Center, 0, 0, 181, 0f, 0f, 0, (new Color(Main.DiscoR, 174, 255)), 1f)];
                    dust.position = Vector2.Lerp(vector6, vector5, num7 / (float)num6);
                    dust.noGravity = true;
                    dust.velocity = Vector2.Zero;
                    dust.customData = player;
                    dust.scale = num5;
                    dust.shader = GameShaders.Armor.GetSecondaryShader(player.cYorai, player);
                    if (dust.customData != null && dust.customData is Player)
                    {
                        Player player3 = (Player)dust.customData;
                        dust.position += player3.position - player3.oldPosition;
                        dust.customData = null;
                    }
                }
            }
        }

        public override void AddRecipes()
        {
            CreateRecipe().

                Register();
        }
    }
}