﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Items.MagicCraftItem
{
    public class MagicGel : ModItem
    {
        public override void SetStaticDefaults()
        {
            //base.DisplayName.SetDefault("魔法凝胶");
            //Tooltip.SetDefault("用来制作强化活性细胞\n" +
            //    "尝起来是蓝莓味的");
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 149, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            Item.COverride().MagicCraftItem = true;
            Item.glowMask = (short)NeonDawn.MyGlows["MagicGel"];
            base.Item.width = 22;
            base.Item.height = 32;
            base.Item.maxStack = 9999;
            Item.value = Item.sellPrice(0, 0, 50, 0);
            base.Item.rare = 3;
        }

        public override void AddRecipes()
        {
            base.CreateRecipe(5)
            .AddIngredient(75, 1)
            .AddIngredient(23, 5)
            .AddTile(16)
            .Register();
        }
    }
}