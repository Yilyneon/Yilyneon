﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.MagicCraftItem
{
    public class Activecellspheres : ModItem
    {
        public override void SetStaticDefaults()
        {
            //base.DisplayName.SetDefault("活性细胞");
            //Tooltip.SetDefault("用来强化饰品，武器，以及制作魔法凝聚锭");
            ItemID.Sets.ItemNoGravity[base.Item.type] = true;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 149, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            Item.COverride().MagicCraftItem = true;
            Item.glowMask = (short)NeonDawn.MyGlows["Activecellspheres"];
            base.Item.width = 28;
            base.Item.height = 28;
            base.Item.maxStack = 999;
            Item.value = Item.sellPrice(0, 10, 0, 0);
            base.Item.rare = 3;
        }

        public override void AddRecipes()
        {
            base.CreateRecipe(3)
            .AddIngredient(547, 1)
            .AddIngredient(548, 1)
            .AddIngredient(549, 1)
            .AddIngredient(ModContent.ItemType<MagicGel>(), 5)
            .AddTile(TileID.MythrilAnvil)
            .Register();
        }
    }
}