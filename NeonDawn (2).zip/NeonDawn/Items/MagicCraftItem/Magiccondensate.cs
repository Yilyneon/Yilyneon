﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.MagicCraftItem
{
    public class Magiccondensate : ModItem
    {
        public override void SetStaticDefaults()
        {
            //base.DisplayName.SetDefault("魔法凝胶锭");
            //Tooltip.SetDefault("用来强化，武器，制作魔法核心");
            Main.RegisterItemAnimation(base.Item.type, new DrawAnimationVertical(12, 7, false));
            ItemID.Sets.ItemNoGravity[base.Item.type] = true;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(Main.DiscoR, 149, 255));
                }
            }
        }

        public override void SetDefaults()
        {
            base.Item.width = 30;
            base.Item.height = 24;
            base.Item.maxStack = 999;
            base.Item.value = 58750;
            base.Item.rare = 3;
        }

        public override void AddRecipes()
        {
            base.CreateRecipe(1)
            .AddIngredient(3456, 1)
            .AddIngredient(3457, 1)
            .AddIngredient(3458, 1)
            .AddIngredient(3459, 1)
            .AddIngredient(3467, 1)
            .AddIngredient(ModContent.ItemType<Activecellspheres>(), 2)
            .AddTile(TileID.LunarCraftingStation)
            .Register();
        }
    }
}