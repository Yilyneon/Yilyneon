﻿
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ModLoader;

namespace NeonDawn.Items
{
	public class NDGItem : GlobalItem
    {
    }
}
