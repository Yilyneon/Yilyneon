﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Fruit
{
    public class WhiteMana : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();

            //DisplayName.SetDefault("冰星糖果");
        }

        public override void SetDefaults()
        {
            base.Item.width = 32;
            base.Item.height = 30;
            base.Item.useAnimation = 30;
            base.Item.useTime = 30;
            base.Item.useStyle = 4;
            base.Item.UseSound = SoundID.Item4;
            base.Item.consumable = true;
        }

        public override bool CanUseItem(Player player)
        {
            return player.statManaMax >= 200;
        }

        public override bool? UseItem(Player player)
        {
            player.statManaMax2 += 50;
            player.statMana += 50;
            player.ManaEffect(50);
            player.GetModPlayer<NeonPlayer>().WhiteMana = true;

            return true;
        }
    }
}