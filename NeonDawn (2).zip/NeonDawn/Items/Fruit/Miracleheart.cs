﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Fruit
{
    public class Miracleheart : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();

            //DisplayName.SetDefault("奇迹果");
        }

        public override void SetDefaults()
        {
            base.Item.width = 32;
            base.Item.height = 30;
            base.Item.useAnimation = 30;
            base.Item.useTime = 30;
            base.Item.useStyle = 4;
            base.Item.UseSound = SoundID.Item4;
            base.Item.consumable = true;
        }

        public override bool CanUseItem(Player player)
        {
            return player.statLifeMax >= 500;
        }

        public override bool? UseItem(Player player)
        {
            player.statLifeMax2 += 50;
            player.statLife += 50;
            player.HealEffect(50, true);
            player.GetModPlayer<NeonPlayer>().Miracleheart = true;

            return true;
        }
    }
}