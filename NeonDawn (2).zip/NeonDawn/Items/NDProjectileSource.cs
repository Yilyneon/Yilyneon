﻿namespace NeonDawn.Items
{
    public class NDProjectileSource : IProjectileSource
    {
    }

    public interface IProjectileSource
    {
    }
}
