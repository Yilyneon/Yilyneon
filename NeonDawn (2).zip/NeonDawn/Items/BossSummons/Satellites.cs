﻿using NeonDawn.NPCs;

using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace NeonDawn.Items.BossSummons
{
    public class Satellites : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault(Language.ActiveCulture.Name == "zh-Hans" ? "1" : "1");
            //Tooltip.SetDefault(Language.ActiveCulture.Name == "zh-Hans" ? "2" : "2");
        }

        public override void SetDefaults()
        {
            Item.width = 42;
            Item.height = 44;
            Item.maxStack = 20;
            Item.value = 1;
            Item.rare = ItemRarityID.Green;
            Item.useTime = 20;
            Item.useAnimation = 20;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = 0;
            Item.UseSound = SoundID.Item44;
        }

        public override bool CanUseItem(Player player)
        {
            if (NPC.CountNPCS(ModContent.NPCType<MeleeMoon>()) < 1 && NPC.CountNPCS(ModContent.NPCType<RemoteMoon>()) < 1 && NPC.CountNPCS(ModContent.NPCType<SatelliteSmall>()) < 1 && !Main.dayTime)
            {
                NPC.NewNPC(null, (int)player.Center.X, (int)player.Center.Y, ModContent.NPCType<SatelliteSmall>(), 0, 0f, 0f, 0f, player.whoAmI);
                Item.stack--;
                return true;
            }
            return false;
        }

        public override void AddRecipes()
        {
            Recipe recipe = CreateRecipe();
            recipe.Register();
        }
    }
}