﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.StoryData
{
    public class ui_GetItemOnStart : ModPlayer
    {
        public override IEnumerable<Item> AddStartingItems( bool mediumCoreDeath )
        {
            List<Item> item = new List<Item>();
            Item i = new Item( );
            i.SetDefaults( ModContent.ItemType<ui>() );
            item.Add( i );
            return item;
        }
    }
    public class ui : ModItem
    {
        public override void SetDefaults( )
        {
            Item.width = 30;
            Item.height = 48;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.useTime = 18;
            Item.useAnimation = 18;
            Item.shoot = ProjectileID.WoodenArrowFriendly;
            Item.shootSpeed = 1;
            base.SetDefaults( );
        }
        public override bool Shoot( Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback )
        {
            NeonDawn.Instance.BookState.Visible = true;
            return false;
        }
        public override void ModifyShootStats( Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback )
        {
            base.ModifyShootStats( player, ref position, ref velocity, ref type, ref damage, ref knockback );
        }
    }
}
