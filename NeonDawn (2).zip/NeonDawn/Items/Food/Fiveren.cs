﻿using Terraria;
using Terraria.Audio;
using Terraria.ModLoader;
using Terraria.ID;

namespace NeonDawn.Items.Food
{
    public class Fiveren : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();

            //DisplayName.SetDefault("五仁");
        }

        public override void SetDefaults()
        {
            base.Item.width = 16;
            base.Item.height = 16;
            base.Item.maxStack = 1;
        }

        public override bool ItemSpace(Player player)
        {
            return true;
        }

        public override bool OnPickup(Player player)
        {
            SoundEngine.PlaySound(SoundID.Item2, player.Center);
            player.AddBuff(26, 900, true);
            player.AddBuff(3, 600, true);
            return false;
        }
    }
}