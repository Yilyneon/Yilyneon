﻿using Terraria.Audio;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;

namespace NeonDawn.Items.Food
{
    public class Yolk : ModItem
    {
        public override void SetStaticDefaults()
        {
            base.SetStaticDefaults();

            //DisplayName.SetDefault("蛋黄");
        }

        public override void SetDefaults()
        {
            base.Item.width = 16;
            base.Item.height = 16;
            base.Item.maxStack = 1;
        }

        public override bool ItemSpace(Player player)
        {
            return true;
        }

        public override bool OnPickup(Player player)
        {
            SoundEngine.PlaySound(SoundID.Item2, player.Center);
            player.AddBuff(58, 600, true);
            player.AddBuff(5, 300, true);
            return false;
        }
    }
}