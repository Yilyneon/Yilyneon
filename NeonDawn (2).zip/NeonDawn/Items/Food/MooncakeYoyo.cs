﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using NeonDawn.Items.MagicCraftItem;
using NeonDawn.Projs.Food;

namespace NeonDawn.Items.Food
{
    public class MooncakeYoyo : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("月饼悠悠球");
            //Tooltip.SetDefault("“共赏圆月一轮，喜迎中秋良宵”\n" +
            //	"月饼打到敌人会掉渣，造成微弱的伤害\n" +
            //	"月饼并不很硬，砸到敌人15次之后会碎开来\n" +
            //	"碎开后爆出三种馅料，玩家可以捡起开吃掉（？\n" +
            //	"蛋黄会给你10秒回血加成，并能让你得到5秒铁皮药水的效果。\n" +
            //	"豆沙会让你的近战攻击命中敌人附上中毒，持续10秒。\n" +
            //	"五仁馅会让你获得15秒吃的好buff，并且获得10秒速度药水。\n" +
            //	"每一口都是不同的风味。\n" +
            //	"满月时增加5%的近战攻击力与近战暴击率。\n" +
            //	"[c/FFDAA520:*2020中秋节纪念武器*]");
        }

        public override void SetDefaults()
        {
            base.Item.CloneDefaults(3278);
            base.Item.damage = 20;
            base.Item.value = Item.sellPrice(0, 5, 50, 0);
            base.Item.rare = 2;
            base.Item.knockBack = 2.5f;
            base.Item.channel = true;
            base.Item.useStyle = 5;
            Item.shoot = ModContent.ProjectileType<MooncakeYoyoProj>();
            base.Item.useAnimation = 30;
            base.Item.useTime = 30;
        }

        public override void HoldItem(Player player)
        {
            player.yoyoString = true;
            player.stringColor = 2;
        }

        public override void UpdateInventory(Player player)
        {
            if (!Main.dayTime && Main.moonPhase == 0)
            {
                player.GetCritChance(DamageClass.Melee) += 5f;
                player.GetDamage(DamageClass.Melee) += 0.05f;
            }
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(255, 152, 71));
                }
            }
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2?(new Vector2(0f, -2f));
        }

        public override void AddRecipes()
        {
            base.CreateRecipe(1)
                .AddIngredient(ItemID.Pumpkin, 25)
                .AddIngredient(ItemID.HealingPotion, 2)
                .AddIngredient(ItemID.PumpkinPie, 1)
                .AddIngredient(ItemID.Valor, 1)
                .AddIngredient(ModContent.ItemType<MagicGel>(), 20)
                .AddTile(TileID.CookingPots)
                .Register();
        }
    }
}