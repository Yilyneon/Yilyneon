﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;
using System.IO;

using Terraria;
using Terraria.ModLoader;
using Terraria.UI.Chat;

namespace NeonDawn.Items
{
    public static class Override
    {
        public static ColorOverride COverride(this Item item)
        {
            return item.GetGlobalItem<ColorOverride>();
        }
    }
    public class ColorOverride : GlobalItem
    {
        public bool MagicCraftItem = false;
        public bool SAETMode = false;
        public bool LemonColorMode = false;
        public bool AgeleSeekerMode = false;
        public bool TheGutsAndGlory = false;
        public bool EnterVoucherMode = false;
        public bool VIII = false;
        public bool RGB = false;
        public int ColorOverrideType = 0;
        public override void NetSend(Item item, BinaryWriter writer)
        {
            writer.Write(ColorOverrideType);
        }
        public override void NetReceive(Item item, BinaryReader reader)
        {
            ColorOverrideType = reader.ReadInt32();
        }
        public override bool InstancePerEntity
        {
            get
            {
                return true;
            }
        }

        public static void RGBDrawTooltipLine(DrawableTooltipLine line)
        {
            ColorOverride.RGBtooltip += 1f;
            if (ColorOverride.RGBtooltip > 600f)
            {
                ColorOverride.RGBtooltip = 0f;
            }
            for (int i = 0; i < line.Text.Length; i++)
            {
                float dis = 0f;
                for (int j = 0; j < i; j++)
                {
                    dis += line.Font.MeasureString(line.Text[j].ToString()).X;
                }
                ChatManager.DrawColorCodedStringWithShadow(Main.spriteBatch, line.Font, line.Text[i].ToString(), new Vector2((float)line.X + dis, (float)line.Y), NeonDawn.ModColor.RGBColor(true, ColorOverride.RGBtooltip + (float)(600 / line.Text.Length * i)), line.Rotation, line.Origin, line.BaseScale, line.MaxWidth, line.Spread);
            }
        }
        public override void ModifyTooltips(Item item, List<TooltipLine> tooltips)
        {
            if (ColorOverrideType > 0)//特殊颜色
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        switch (ColorOverrideType)
                        {
                            case 1://柠檬颜色
                                line2.OverrideColor = new Color(195, 210, 255);
                                break;
                        }
                    }
                }
            }
            if (LemonColorMode)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.LemonColor();
                    }
                }
                string text1 = "柠檬系列";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.LemonColor()
                };
                tooltips.Add(line);
            }
            if (AgeleSeekerMode)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.AgeleSeekerColor();
                    }
                }
                string text1 = "“and in that light，I find deliverance.”";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.AgeleSeekerColor()
                };
                tooltips.Add(line);
            }
            if (SAETMode)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.SAETColor();
                    }
                }
                string text1 = "“智障”-->cametek";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.SAETColor()
                };
                tooltips.Add(line);
            }
            if (EnterVoucherMode)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.EnterVoucherColor();
                    }
                }
                string text1 = "“{旅行者身份凭证}”";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.EnterVoucherColor()
                };
                tooltips.Add(line);
            }
            if (MagicCraftItem)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.MagicCraftItemColor();
                    }
                }
                string text1 = "“通用制作材料，用来制作所有特殊武器”";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.MagicCraftItemColor()
                };
                tooltips.Add(line);
            }
            if (TheGutsAndGlory)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.TheGutsAndGlory();
                    }
                }
                string text1 = "“你已经有了荣耀，可惜你没有足够勇气”\n“要不要带着你的儿子，骑上自行车，参加一场百亿美金的死亡竞赛来证明下自己？”";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.TheGutsAndGlory()
                };
                tooltips.Add(line);
            }
            if (VIII)
            {
                foreach (TooltipLine line2 in tooltips)
                {
                    if (line2.Mod == "Terraria" && line2.Name == "ItemName")
                    {
                        line2.OverrideColor = NeonDawn.VIII();
                    }
                }
                string text1 = "“你感觉这把武器里有一丝古老的电流在流淌... ”";
                TooltipLine line = new TooltipLine(Mod, "text1", text1)
                {
                    OverrideColor = NeonDawn.VIII()
                };
                tooltips.Add(line);
            }
        }
        private static float RGBtooltip;
    }
}