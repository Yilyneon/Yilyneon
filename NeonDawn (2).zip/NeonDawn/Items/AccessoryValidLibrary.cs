﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

using NeonDawn.Items.Bags;

using Terraria;
using Terraria.DataStructures;
using Terraria.GameInput;
using Terraria.ModLoader;

namespace NeonDawn.Items
{
    public class AccessoryValidLibrary : ModPlayer
    {
        public bool EnterVoucher = false;
        public bool RespawnSound = false;
        public int eightbitnote = 0;
        public int eightbitmananote = 0;
        public int eightbitstart = 0;

        public override void ResetEffects()
        {
            EnterVoucher = false;
        }

        public override void PostUpdate()
        {
            if (eightbitnote > 0) eightbitnote--;
            if (eightbitmananote > 0) eightbitmananote--;
            if (eightbitstart > 0) eightbitstart--;
        }

        public override void PostUpdateMiscEffects()
        {
            if (EnterVoucher)
            {
                base.Player.accWatch = 3;
                base.Player.accDepthMeter = 1;
                base.Player.accCompass = 1;
            }
        }

        public override void ProcessTriggers(TriggersSet triggersSet)
        {
            base.ProcessTriggers(triggersSet);
        }

        public override void MeleeEffects(Item item, Rectangle hitbox)
        {
        }

        public override bool PreKill(double damage, int hitDirection, bool pvp, ref bool playSound, ref bool genGore, ref PlayerDeathReason damageSource)
        {
            return true;
        }

        public override void OnRespawn()
        {
            eightbitstart = 50;
        }
    }
}