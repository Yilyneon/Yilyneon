﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Items.MagicCraftItem;
using NeonDawn.Items.Materials;

using ReLogic.Content;

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Placeable
{
    internal class ExtractTableItem : ModItem
    {
        private int frame = 0, frameCount = 0;

        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "212计划 --“重建”");
            //Tooltip.AddTranslation(7, "可用于转换与拆解几乎任何物品\n" +
            //    "左键将此机械放置下来，右键打开操作面板。 \n" +
            //    "具体操作说明请使用此机械自带的说明书（在此机械的环境下就可以免费制作\n" +
            //    "分解，毁灭，转化，重组");
            //DisplayName.AddTranslation(1, "project212--Reconstruction");
            //Tooltip.AddTranslation(1,
            //    "Leftclick to deploy the machine， Rightclick to open the UI\n" +
            //    "If you want to learn more information about this machine, please read the instructions\n" +
            //    "Creation,Domination,Transformation,Reconstruction");
            base.SetStaticDefaults();
        }

        public override void SetDefaults()
        {
            Item.width = 52;
            Item.height = 46;
            Item.maxStack = 999;
            Item.useTurn = true;
            Item.autoReuse = true;
            Item.useAnimation = 15;
            Item.useTime = 10;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.consumable = true;
            Item.noUseGraphic = true;
            Item.rare = ItemRarityID.Red;
            Item.value = Item.buyPrice(0, 10, 0, 0);
            Item.createTile = ModContent.TileType<Tiles.ExtractTable>();
        }

        public override bool PreDrawInInventory(SpriteBatch spriteBatch, Vector2 position, Rectangle frame, Color drawColor, Color itemColor, Vector2 origin, float scale)
        {
            frameCount++;
            if (frameCount % 10 == 0)
            {
                frameCount = 0;
                this.frame++;
            }
            if (this.frame == 6)
            {
                this.frame = 0;
            }
            spriteBatch.Draw(Mod.Assets.Request<Texture2D>("Items/Placeable/ExtractTableItem_Frame", AssetRequestMode.ImmediateLoad).Value, position, new Rectangle(0, this.frame * 46, 52, 46), drawColor, 0f, origin, scale, 0, 0f);
            return false;
        }

        public override bool PreDrawInWorld(SpriteBatch spriteBatch, Color lightColor, Color alphaColor, ref float rotation, ref float scale, int whoAmI)
        {
            frameCount++;
            if (frameCount % 10 == 0)
            {
                frameCount = 0;
                frame++;
            }
            if (frame == 6)
            {
                frame = 0;
            }
            spriteBatch.Draw(Mod.Assets.Request<Texture2D>("Items/Placeable/ExtractTableItem_Frame", AssetRequestMode.ImmediateLoad).Value, Item.position - Main.screenPosition, new Rectangle(0, frame * 46, 52, 46), lightColor, rotation, Vector2.Zero, scale, 0, 0f);
            return false;
        }

        public override void AddRecipes()
        {
            base.CreateRecipe()
            .AddIngredient(22, 50)
            .AddIngredient(109, 2)
            .AddIngredient(ModContent.ItemType<MagicGel>(), 30)
            .AddIngredient(ModContent.ItemType<Scrap>(), 25)
            .AddTile(16)
            .Register();
            base.CreateRecipe()
            .AddIngredient(704, 50)
            .AddIngredient(109, 2)
            .AddIngredient(ModContent.ItemType<MagicGel>(), 30)
            .AddIngredient(ModContent.ItemType<Scrap>(), 25)
            .AddTile(16)
            .Register();
        }
    }
}