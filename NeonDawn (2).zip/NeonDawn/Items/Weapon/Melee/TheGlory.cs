﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Projs.Melee;

using System.Collections.Generic;

using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Weapon.Melee
{
    public class TheGlory : ModItem
    {
        public override void SetStaticDefaults()
        {
            //base.DisplayName.SetDefault("勇气与荣耀");
            //Tooltip.SetDefault("神圣的荣光终将落在这把长枪上\n" +
            //    "左键使用这把长矛进行戳刺，发射长矛追踪且攻击敌人。\n" +
            //    "右键将这把长矛扔出去，追踪且攻击敌人，击中敌人后会分裂出3根长矛。\n" +
            //    "击败某个丑恶的boss来强化这把武器的攻击效果");
            //DisplayName.AddTranslation(7,"勇气与荣耀");
            //Tooltip.AddTranslation(7,"神圣的荣光终将落在这把长枪上\n" +
            //    "左键使用这把长矛进行戳刺，发射长矛追踪且攻击敌人。\n" +
            //    "右键将这把长矛扔出去，追踪且攻击敌人，击中敌人后会分裂出3根长矛。\n" +
            //    "击败某个丑恶的boss来强化这把武器的攻击效果");
        }

        public override void SetDefaults()
        {
            Item.COverride().TheGutsAndGlory = true;
            Item.damage = 20;
            Item.width = 64;
            Item.DamageType = DamageClass.Melee;
            Item.crit = 4;
            Item.noMelee = true;
            Item.useTurn = false;
            Item.noUseGraphic = true;
            Item.useAnimation = (Item.useTime = 12);
            Item.useStyle = 5;
            Item.knockBack = 1.5f;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.height = 64;
            Item.value = Item.buyPrice(0, 60, 0, 0);
            Item.shoot = ModContent.ProjectileType<TheGloryp>();
            Item.shootSpeed = 1.5f;
            base.Item.rare = 3;
        }

        public override void HoldItem(Player player)
        {
            //注意护甲穿透分职业了
            player.GetArmorPenetration(DamageClass.Melee) += 15;
        }

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        public override void ModifyWeaponDamage(Player player, ref StatModifier damage)
        {
            Item.damage = 20;
            if (Main.hardMode)
                Item.damage += 24;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.altFunctionUse == 2)
            {
                Projectile.NewProjectile(null, position, velocity, ModContent.ProjectileType<TheGloryPro2>(), (int)((double)damage * 1.25), Item.knockBack, player.whoAmI, 0f, 0f);
            }
            else
            {
                Projectile.NewProjectile(null, position, velocity, ModContent.ProjectileType<TheGloryp>(), damage, Item.knockBack, player.whoAmI, 0f, 0f);
            }
            return false;
        }

        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                Item.shootSpeed = 15f;
            }
            else
            {
                Item.shootSpeed = 2f;
            }
            return player.ownedProjectileCounts[Item.shoot] < 1;
        }

        public override void PostDrawInInventory(SpriteBatch sb, Vector2 position, Rectangle frame, Color drawColor, Color ItemColor, Vector2 origin, float scale)
        {
            sb.Draw(ModContent.Request<Texture2D>("NeonDawn/Items/Weapon/Melee/TheGlory_OutGlow").Value, position, frame, Color.Lerp(Color.GhostWhite, Color.Gold, Helper.Osc01(3f, 0f)) * 0.9f, 0f, origin, scale, SpriteEffects.None, 0f);
        }
    }
}