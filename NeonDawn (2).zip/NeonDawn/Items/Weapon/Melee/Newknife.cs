﻿using Microsoft.Xna.Framework;

using NeonDawn.Projs.Melee;

using System.Collections.Generic;

using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Weapon.Melee
{
    public class Newknife : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7,"“蚁”式轻型小刀");
            //Tooltip.AddTranslation(7,"此武器攻击为连招型攻击（拔刀剑类似\n" +
            //   "在连招结束前攻击不会停止，第二段会给予玩家2秒无敌并冲刺一小段距离。\n" +
            //   "武器伤害会增长玩家防御力的50%，玩家防御力越高，武器的伤害越高，武器自带5点破甲（基础伤害为10）。\n" +
            //   "右键将小刀扔出去，但是只会造成0.75倍伤害，每投掷四次产生幻影，造成0.5倍伤害。\n" +
            //   "此武器攻击为连招型攻击（拔刀剑类似");
        }

        public override void SetDefaults()
        {
            base.Item.damage = 10;
            base.Item.width = 64;
            base.Item.DamageType = DamageClass.Melee;
            base.Item.crit = 4;
            base.Item.noMelee = true;
            base.Item.useTurn = false;
            Item.noUseGraphic = true;
            base.Item.useAnimation = (base.Item.useTime = 10);
            base.Item.useStyle = 1;
            base.Item.knockBack = 5f;
            base.Item.UseSound = SoundID.Item1;
            base.Item.autoReuse = true;
            base.Item.height = 64;
            base.Item.value = Item.buyPrice(0, 60, 0, 0);
            base.Item.rare = 3;
            Item.shoot = ModContent.ProjectileType<Newknifep>();
            Item.shootSpeed = 8f;
        }

        public override void HoldItem(Player player)
        {
            player.GetArmorPenetration(DamageClass.Melee) += 5;
        }

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        private int charger;

        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse != 2)
            {
                base.Item.shootSpeed = 8f;
                Item.shoot = ModContent.ProjectileType<Newknifep>();
                return true;
            }
            if (player.altFunctionUse == 2)
            {
                Item.autoReuse = true;
                base.Item.shootSpeed = 8f;
                Item.shoot = ModContent.ProjectileType<Knifeproj>();
                return true;
            }
            return true;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            float dir = velocity.ToRotation();
            float speed = velocity.Length();
            if (player.altFunctionUse == 2)
            {
                Projectile.NewProjectile(source, position, velocity, ModContent.ProjectileType<Knifeproj>(), (int)((double)damage * 0.75), Item.knockBack, player.whoAmI, 0f, 0f);

                this.charger++;
                if (this.charger >= 4)
                {
                    for (int i = 0; i < 1; i++)
                    {
                        Projectile.NewProjectile(source, position + NeonDawn.WeaponVector(12, dir), NeonDawn.WeaponVector(speed * Main.rand.NextFloat(.5f, 1f), dir + Main.rand.NextFloat(0, 1)), ModContent.ProjectileType<Knifeproj>(), (int)((double)damage * 0.75), Item.knockBack, player.whoAmI, 0f, 0f);
                    }
                    this.charger = 0;
                    return true;
                }
                return false;
            }
            else
            {
                Projectile.NewProjectile(source, position, velocity, ModContent.ProjectileType<Newknifep>(), damage, Item.knockBack, player.whoAmI, 0f, 0f);
            }
            return false;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(31, 162, 255));
                }
            }
        }

        public override void ModifyWeaponDamage(Player player, ref StatModifier damage)
        {
            Item.damage = 10;
            Item.damage += player.statDefense / 2;
            base.ModifyWeaponDamage(player, ref damage);
        }

        public override void AddRecipes()
        {
            CreateRecipe().
            AddIngredient(ItemID.Ruby, 1).
            AddIngredient(ItemID.IronBar, 6).
            AddIngredient(ItemID.Gel, 99).
            AddTile(TileID.Anvils).
            Register();

            CreateRecipe().
            AddIngredient(ItemID.Ruby, 1).
            AddIngredient(ItemID.LeadBar, 6).
            AddIngredient(ItemID.Gel, 99).
            AddTile(TileID.Anvils).
            Register();
        }
    }
}