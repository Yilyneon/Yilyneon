﻿using Terraria;
using System;
using System.Collections.Generic;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Terraria.DataStructures;
using NeonDawn.Projs.Magic;

namespace NeonDawn.Items.Weapon.Magic
{
    public class VIIILaserGun : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "八号激光枪");
            //DisplayName.AddTranslation(1, "Blaster NO.8");
            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
        }

        public override void SetDefaults()
        {
            Item.COverride().VIII = true;
            Item.damage = 10;
            Item.width = 42;
            Item.height = 30;
            Item.useTime = 10;
            Item.useAnimation = 80;
            Item.crit = 4;
            Item.mana = 2;
            Item.noMelee = true;
            Item.autoReuse = true;
            Item.rare = ItemRarityID.Red;
            Item.UseSound = null;
            Item.shoot = ModContent.ProjectileType<VIIILaserGunPro>();
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.DamageType = DamageClass.Magic;
            Item.value = Item.sellPrice(0, 0, 10, 0);
            Item.shootSpeed = 15f;
            Item.rare = 1;
            Item.glowMask = (short)NeonDawn.MyGlows["VIIILaserGun"];
        }

        private int charger;

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2?(new Vector2(-2f, 0f));
        }

        public override void HoldItem(Player player)
        {
            if (player.GetModPlayer<AccessoryValidLibrary>().eightbitstart == 1)
            {
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitSpawn"), player.Center.X, player.Center.Y, 1.5f, 0f);
            }
            if (player.statLife <= player.statLifeMax / 10 && player.GetModPlayer<AccessoryValidLibrary>().eightbitnote == 0)
            {
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitlowhealth"), player.Center.X, player.Center.Y, 1.2f, 0f);
                player.GetModPlayer<AccessoryValidLibrary>().eightbitnote = 1500;
            }
            if (player.statMana <= player.statManaMax / 5 && player.GetModPlayer<AccessoryValidLibrary>().eightbitmananote == 0)
            {
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitlowmana"), player.Center.X, player.Center.Y, 1.2f, 0f);
                player.GetModPlayer<AccessoryValidLibrary>().eightbitmananote = 1500;
            }
        }

        public override void UpdateInventory(Player player)
        {
            player.GetModPlayer<AccessoryValidLibrary>().RespawnSound = true;
            base.UpdateInventory(player);
        }

        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                Item.UseSound = new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitspecial", 0);
                base.Item.useTime = 4;
                base.Item.useAnimation = 64;
                base.Item.shootSpeed = 15f;
            }
            else
            {
                Item.useTime = 10;
                Item.useAnimation = 80;
                base.Item.shootSpeed = 12f;
            }

            return base.CanUseItem(player);
        }

        public override bool? UseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitspecial"), player.Center.X, player.Center.Y, 1.2f, 0f);
                player.BuyItem(6, -1);
            }
            return base.UseItem(player);
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            this.charger++;
            if (this.charger >= 256)
            {
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bithighscore"), player.Center.X, player.Center.Y, 0.5f, 0f);
                this.charger = 0;
            }
            if (player.altFunctionUse == 2)
            {
                Projectile.NewProjectile(source, position, velocity, ModContent.ProjectileType<VIIILaserGunPro>(), (int)(damage * 1.5), Item.knockBack, Main.myPlayer, 0, 0);
            }
            else
            {
                Projectile.NewProjectile(source, position, velocity, ModContent.ProjectileType<VIIILaserGunPro>(), damage, Item.knockBack, Main.myPlayer, 0, 0);
                player.statMana -= 2;
                Helper.PlaySound(new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/8bitattack"), player.Center.X, player.Center.Y, 0.5f, 0f);
            }
            return false;
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            if (Utils.PressingShift(Main.keyState))
            {
                TooltipLine line = new TooltipLine(base.Mod, "效果", "这是效果测试")
                {
                    OverrideColor = new Color?(Color.LightCyan)
                };
                tooltips.Add(line);
                return;
            }
            TooltipLine line2 = new TooltipLine(base.Mod, "按住shift", "按住shif来查看效果")
            {
                OverrideColor = new Color?(Color.Gray)
            };
            tooltips.Add(line2);
        }
    }
}