﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Terraria;
using Terraria.ModLoader;
using Terraria.ID;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria.GameContent.Creative;
using Terraria.DataStructures;
using Terraria.GameContent;
using Terraria.UI.Chat;
using NeonDawn.Projs.Ranged;
using NeonDawn;

namespace NeonDawn.Items.Weapon.Ranged
{
    public class GraniteGun : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "花岗岩爆破者");
            //DisplayName.AddTranslation(1, "GraniteBlaster");
            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
            //Tooltip.AddTranslation(7, "33%的几率不消耗弹药（右键不消耗弹药）\n" +
            //  "这把枪会把火枪子弹转换为纳米弹，右键点击可以射出2枚感应雷。\n" +
            //  "此枪自带激光瞄准，握持此枪时自带10的盔甲穿透。\n" +
            //  "“虽然它的效果不是那么出奇，但是它仍然能让你拥有很好的使用体验”");

            //Tooltip.AddTranslation(1, "" +
            //"This gun can only shoot meteorbullet. \n" +
            //"Every five shoot will extra Shoot phoenix. \n" +
            //"The phoenix will make 200% weapon damage to enemies. \n" +
            //"Other changes; \n" +
            //"Damage from 24 increase to 26. \n" +
            //"Crit from 4% increase to 8%. \n" +
            //"Shootspeed from 13 increase to 15.\n" +
            //" [c/FFD700:The phoenix will eventually rebirth from Nirvana.]");
        }

        public override void SetDefaults()
        {
            Item.damage = 20;
            base.Item.width = 78;
            base.Item.height = 46;
            base.Item.useTime = 10;
            base.Item.useAnimation = 10;
            Item.crit = 6;
            Item.noMelee = true;
            Item.autoReuse = true;
            Item.rare = ItemRarityID.Red;
            Item.shoot = ProjectileID.NanoBullet;
            Item.useStyle = ItemUseStyleID.Shoot;
            Item.DamageType = DamageClass.Ranged;
            Item.useAmmo = AmmoID.Bullet;
            Item.value = Item.sellPrice(0, 3, 0, 0);
            Item.shootSpeed = 15f;
            Item.noUseGraphic = true;
            Item.glowMask = (short)NeonDawn.MyGlows["GraniteGun"];
        }

        private static Color RGBColorN(float Time)
        {
            Color ColorA;
            ColorA = new Color(255, 0, 0);
            Color ColorB;
            ColorB = new Color(255, 255, 0);
            Color ColorC;
            ColorC = new Color(0, 255, 0);
            Color ColorD;
            ColorD = new Color(0, 255, 255);
            Color ColorE;
            ColorE = new Color(0, 0, 255);
            Color ColorF;
            ColorF = new Color(255, 0, 255);
            while (Time >= 600f)
            {
                Time -= 600f;
            }
            while (Time < 0f)
            {
                Time += 600f;
            }
            Color RGB;
            if (Time < 100f)
            {
                RGB = Color.Lerp(ColorA, ColorB, Time / 100f);
            }
            else if (Time < 200f)
            {
                RGB = Color.Lerp(ColorB, ColorC, (Time - 100f) / 100f);
            }
            else if (Time < 300f)
            {
                RGB = Color.Lerp(ColorC, ColorD, (Time - 200f) / 100f);
            }
            else if (Time < 400f)
            {
                RGB = Color.Lerp(ColorD, ColorE, (Time - 300f) / 100f);
            }
            else if (Time < 500f)
            {
                RGB = Color.Lerp(ColorE, ColorF, (Time - 400f) / 100f);
            }
            else
            {
                RGB = Color.Lerp(ColorF, ColorA, (Time - 500f) / 100f);
            }
            RGB.A = 0;
            return RGB;
        }

        public static Color RGBColor(bool NoAuto = false, float Time = 0f)
        {
            Color ColorA;
            ColorA = new Color(255, 0, 0);
            Color ColorB;
            ColorB = new Color(255, 255, 0);
            Color ColorC;
            ColorC = new Color(0, 255, 0);
            Color ColorD;
            ColorD = new Color(0, 255, 255);
            Color ColorE;
            ColorE = new Color(0, 0, 255);
            Color ColorF;
            ColorF = new Color(255, 0, 255);
            GraniteGun.specialColorTimer[0] += 1f;
            if (NoAuto)
            {
                GraniteGun.specialColorTimer[0] = Time;
            }
            while (GraniteGun.specialColorTimer[0] >= 600f)
            {
                GraniteGun.specialColorTimer[0] -= 600f;
            }
            while (GraniteGun.specialColorTimer[0] < 0f)
            {
                GraniteGun.specialColorTimer[0] += 600f;
            }
            if (GraniteGun.specialColorTimer[0] < 100f)
            {
                return Color.Lerp(ColorA, ColorB, GraniteGun.specialColorTimer[0] / 100f);
            }
            if (GraniteGun.specialColorTimer[0] < 200f)
            {
                return Color.Lerp(ColorB, ColorC, (GraniteGun.specialColorTimer[0] - 100f) / 100f);
            }
            if (GraniteGun.specialColorTimer[0] < 300f)
            {
                return Color.Lerp(ColorC, ColorD, (GraniteGun.specialColorTimer[0] - 200f) / 100f);
            }
            if (GraniteGun.specialColorTimer[0] < 400f)
            {
                return Color.Lerp(ColorD, ColorE, (GraniteGun.specialColorTimer[0] - 300f) / 100f);
            }
            if (GraniteGun.specialColorTimer[0] < 500f)
            {
                return Color.Lerp(ColorE, ColorF, (GraniteGun.specialColorTimer[0] - 400f) / 100f);
            }
            return Color.Lerp(ColorF, ColorA, (GraniteGun.specialColorTimer[0] - 500f) / 100f);
        }

        private static readonly float[] specialColorTimer = new float[2];

        public static Color SAETColor(bool NoAuto = false, float Time = 0f)
        {
            Color ColorA = new Color(125, 34, 91);
            Color ColorB = new Color(255, 255, 255);
            Color ColorC = new Color(188, 62, 73);
            Color ColorD = new Color(255, 255, 255);
            Color ColorE = new Color(233, 154, 90);
            Color ColorF = new Color(255, 255, 255);
            Color ColorG = new Color(255, 229, 122);
            Color ColorH = new Color(255, 255, 255);
            Color ColorI = new Color(154, 225, 110);
            Color ColorJ = new Color(255, 255, 255);
            Color ColorK = new Color(65, 234, 242);
            Color ColorL = new Color(255, 255, 255);
            Color ColorM = new Color(255, 99, 239);
            Color ColorN = new Color(255, 255, 255);
            GraniteGun.specialColorTimer[1] += 1f;
            if (NoAuto)
            {
                GraniteGun.specialColorTimer[1] = Time;
            }
            while (GraniteGun.specialColorTimer[1] >= 600f)
            {
                GraniteGun.specialColorTimer[1] -= 600f;
            }
            while (GraniteGun.specialColorTimer[1] < 0f)
            {
                GraniteGun.specialColorTimer[1] += 600f;
            }
            if (GraniteGun.specialColorTimer[1] < 50f)
            {
                return Color.Lerp(ColorA, ColorB, GraniteGun.specialColorTimer[1] / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 100f)
            {
                return Color.Lerp(ColorB, ColorC, (GraniteGun.specialColorTimer[1] - 50f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 150f)
            {
                return Color.Lerp(ColorC, ColorD, (GraniteGun.specialColorTimer[1] - 100f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 200f)
            {
                return Color.Lerp(ColorD, ColorE, (GraniteGun.specialColorTimer[1] - 150f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 250f)
            {
                return Color.Lerp(ColorE, ColorF, (GraniteGun.specialColorTimer[1] - 200f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 300f)
            {
                return Color.Lerp(ColorF, ColorG, (GraniteGun.specialColorTimer[1] - 250f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 350f)
            {
                return Color.Lerp(ColorG, ColorH, (GraniteGun.specialColorTimer[1] - 300f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 400f)
            {
                return Color.Lerp(ColorH, ColorI, (GraniteGun.specialColorTimer[1] - 350f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 450f)
            {
                return Color.Lerp(ColorI, ColorJ, (GraniteGun.specialColorTimer[1] - 400f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 500f)
            {
                return Color.Lerp(ColorJ, ColorK, (GraniteGun.specialColorTimer[1] - 450f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 550f)
            {
                return Color.Lerp(ColorK, ColorL, (GraniteGun.specialColorTimer[1] - 500f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 600f)
            {
                return Color.Lerp(ColorL, ColorM, (GraniteGun.specialColorTimer[1] - 550f) / 100f);
            }
            if (GraniteGun.specialColorTimer[1] < 650f)
            {
                return Color.Lerp(ColorM, ColorN, (GraniteGun.specialColorTimer[1] - 600f) / 100f);
            }
            return Color.Lerp(ColorN, ColorA, (GraniteGun.specialColorTimer[1] - 650f) / 100f);
        }

        public override bool AltFunctionUse(Player player)
        {
            return true;
        }

        public override bool CanConsumeAmmo(Item ammo, Player player)
        {
            bool falg = base.CanConsumeAmmo(ammo, player);
            if (player.altFunctionUse == 2)
            {
                return player.altFunctionUse != 2;
            }
            else
            {
                if (Utils.NextBool(Main.rand, 3))
                {
                    falg = false;
                }
            }
            return falg;
        }

        public override bool PreDrawTooltipLine(DrawableTooltipLine line, ref int yOffset)
        {
            if (line.Name == "ItemName" && line.Mod == "Terraria")
            {
                GraniteGun.PrimeTooltipLine(line, ref yOffset);
                return false;
            }
            GraniteGun.RGBtooltip += 1f;
            if (GraniteGun.RGBtooltip > 700f)
            {
                GraniteGun.RGBtooltip = 0f;
            }
            for (int i = 0; i < line.Text.Length; i++)
            {
                float dis = 0f;
                for (int j = 0; j < i; j++)
                {
                    dis += line.Font.MeasureString(line.Text[j].ToString()).X;
                }
                ChatManager.DrawColorCodedStringWithShadow(Main.spriteBatch, line.Font, line.Text[i].ToString(), new Vector2((float)line.X + dis, (float)line.Y), GraniteGun.SAETColor(true, GraniteGun.RGBtooltip + (float)(700 / line.Text.Length * i)), line.Rotation, line.Origin, line.BaseScale, line.MaxWidth, line.Spread);
            }
            return base.PreDrawTooltipLine(line, ref yOffset);
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2?(new Vector2(-10f, 4f));
        }

        public override bool CanUseItem(Player player)
        {
            if (player.altFunctionUse == 2)
            {
                base.Item.useTime = 60;
                base.Item.useAnimation = 60;
                Item.noUseGraphic = false;
                Item.channel = false;
                base.Item.shootSpeed = 15f;
            }
            else
            {
                base.Item.useTime = 10;
                base.Item.useAnimation = 10;
                Item.noUseGraphic = true;
                Item.channel = true;
                base.Item.shootSpeed = 12f;
            }
            return base.CanUseItem(player);
        }

        public override void PostDrawInWorld(SpriteBatch spriteBatch, Color lightColor, Color alphaColor, float rotation, float scale, int whoAmI)
        {
            Texture2D texture = (Texture2D)ModContent.Request<Texture2D>("NeonDawn/Items/Weapon/Ranged/GraniteGun_Extra").Value;
            Vector2 drawOrigin = new Vector2(texture.Width / 2, texture.Height / 2);
            Color color = Color.White;
            Main.spriteBatch.Draw(texture, new Vector2((float)(Item.Center.X - (int)Main.screenPosition.X), (float)(Item.Center.Y - (int)Main.screenPosition.Y)), null, color, rotation, drawOrigin, scale, SpriteEffects.None, 0f);
            base.PostDrawInWorld(spriteBatch, lightColor, alphaColor, rotation, scale, whoAmI);
        }

        public static void PrimeTooltipLine(DrawableTooltipLine line, ref int yOffset)
        {
            Main.spriteBatch.End();
            Main.spriteBatch.Begin(0, BlendState.Additive, null, null, null, null, Main.UIScaleMatrix);
            ChatManager.DrawColorCodedStringWithShadow(Main.spriteBatch, FontAssets.MouseText.Value, line.Text, new Vector2((float)line.X, (float)line.Y),
                new Color(255, 255, 255), line.Rotation, line.Origin, line.BaseScale, line.MaxWidth, line.Spread);
            Vector2 size = FontAssets.MouseText.Value.MeasureString(line.Text);
            Color color = Color.Lerp(new Color(107, 117, 136, 192), new Color(0, 238, 255, 192), Helper.Osc01(3f, 0f)) * 1f;
            color.A = 255;
            Main.spriteBatch.Draw(ModContent.Request<Texture2D>("NeonDawn/Effects/Ray3").Value, new Vector2((float)line.X + 125, (float)(line.Y + 5)) + size / 5f,
                 default(Rectangle?), color, 0f, Utils.Size(ModContent.Request<Texture2D>("NeonDawn/Effects/Ray3").Value) / 2f,
                 new Vector2(size.X / 150f, 0.5f), 0, 0f);
            Main.spriteBatch.End();
            Main.spriteBatch.Begin(0, null, null, null, null, null, Main.UIScaleMatrix);
        }

        public static void RGBDrawTooltipLine(DrawableTooltipLine line)
        {
            for (int i = 0; i < line.Text.Length; i++)
            {
                float dis = 0f;
                for (int j = 0; j < i; j++)
                {
                    dis += line.Font.MeasureString(line.Text[j].ToString()).X;
                }
                ChatManager.DrawColorCodedStringWithShadow(Main.spriteBatch, line.Font, line.Text[i].ToString(), new Vector2((float)line.X + dis, (float)line.Y), GraniteGun.RGBColor(true, GraniteGun.RGBtooltip + (float)(600 / line.Text.Length * i)), line.Rotation, line.Origin, line.BaseScale, line.MaxWidth, line.Spread);
            }
        }

        public override void HoldItem(Player player)
        {
            player.GetArmorPenetration<GenericDamageClass>() += 10f;
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            if (player.altFunctionUse == 2)
            {
                Terraria.Audio.SoundEngine.PlaySound(SoundID.Item61, position);
                for (int i = 0; i < 2; i++)
                {
                    Projectile.NewProjectile(source, position, velocity, 141, (int)((double)damage * 2), Item.knockBack, Main.myPlayer, 0, 0);
                }
            }
            else
            {
                Terraria.Audio.SoundEngine.PlaySound(SoundID.Item11, position);
                NeonPlayer modPlayer = NeonPlayer.ModPlayer(player);
                Projectile.NewProjectile(source, position, Vector2.Zero, ModContent.ProjectileType<GraniteGun_Pro>(), damage, 0, 0, 0);
                if (type == 14)
                {
                    position.Y -= 5f;
                    Projectile.NewProjectileDirect(source, position, velocity, 285, damage, knockback, player.whoAmI, 0f, 0f);
                }
                else
                {
                    position.Y -= 5f;
                    Projectile.NewProjectileDirect(source, position, velocity, type, damage, knockback, player.whoAmI, 0f, 0f).extraUpdates++;
                }
            }
            return false;
        }

        private static float RGBtooltip;
    }
}