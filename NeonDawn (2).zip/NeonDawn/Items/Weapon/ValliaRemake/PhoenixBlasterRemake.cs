﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework.Graphics;

namespace NeonDawn.Items.Weapon.ValliaRemake
{
    public class PhoenixBlasterRemake : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "凤凰爆破枪");
            //DisplayName.AddTranslation(1, "Re;PhoenixBlaster");
            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
            //Tooltip.AddTranslation(7, "" +
            //  " 这把枪只能射出陨石弹，且每五发会额外射出一只凤凰，造成200%的伤害.\n" +
            //  "其他改动：\n" +
            //  "面板从24提升至26\n" +
            //  "暴击率从4%提升至8%\n" +
            //  "射速从13下调至15\n" +
            //  "[c/FFD700:“凤凰终将涅槃重生。”]");

            //Tooltip.AddTranslation(1, "" +
            //"This gun can only shoot meteorbullet. \n" +
            //"Every five shoot will extra Shoot phoenix. \n" +
            //"The phoenix will make 200% weapon damage to enemies. \n" +
            //"Other changes; \n" +
            //"Damage from 24 increase to 26. \n" +
            //"Crit from 4% increase to 8%. \n" +
            //"Shootspeed from 13 increase to 15.\n" +
            //" [c/FFD700:The phoenix will eventually rebirth from Nirvana.]");
        }

        public override void PostDrawInWorld(SpriteBatch spriteBatch, Color lightColor, Color alphaColor, float rotation, float scale, int whoAmI)
        {
            Texture2D texture = Mod.Assets.Request<Texture2D>("Items/Weapon/ValliaRemake/PhoenixBlasterRemake_Glow").Value;
            Color color = Color.White;
            Vector2 drawOrigin = new Vector2(Terraria.GameContent.TextureAssets.Item[Item.type].Value.Width * 0.5f, Item.height * 0.5f);
            Main.spriteBatch.Draw(texture, new Vector2((float)(Item.Center.X - (int)Main.screenPosition.X), (float)(Item.Center.Y - (int)Main.screenPosition.Y)), null, color, rotation, drawOrigin, scale, SpriteEffects.None, 0f);
        }

        public override void SetDefaults()
        {
            Item.glowMask = (short)NeonDawn.MyGlows["PhoenixBlasterRemake"];
            Item.damage = 26;
            Item.knockBack = 0.75f;
            Item.crit = 8;
            Item.rare = 3;
            Item.useTime = 15;
            Item.useAnimation = 15;
            Item.useStyle = 5;
            Item.autoReuse = true;
            Item.DamageType = DamageClass.Ranged;
            Item.value = Item.sellPrice(0, 0, 60, 0);
            Item.UseSound = new Terraria.Audio.SoundStyle("NeonDawn/Sounds/Items/GraniteGunShoot", 0);
            Item.width = 24;
            Item.height = 24;
            Item.scale = 1f;
            Item.maxStack = 1;
            Item.noMelee = true;
            Item.shoot = 36;
            Item.shootSpeed = 30f;
            Item.useAmmo = AmmoID.Bullet;
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2(2f, 0f);
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(254, 158, 35));
                }
            }
        }

        public override void ModifyShootStats(Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback)
        {
            type = 36;
            base.ModifyShootStats(player, ref position, ref velocity, ref type, ref damage, ref knockback);
        }

        private int charger;

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            Projectile.NewProjectile(source, position, velocity, type = 36, (int)((double)damage * 1), Item.knockBack, Main.myPlayer, 0, 0);
            this.charger++;
            if (this.charger >= 5)
            {
                for (int i = 0; i < 1; i++)
                {
                    Projectile.NewProjectile(source, position, velocity, type = 706, (int)((double)damage * 2), Item.knockBack, Main.myPlayer, 0, 0);
                }
                this.charger = 0;
            }
            return false;
        }
    }
}