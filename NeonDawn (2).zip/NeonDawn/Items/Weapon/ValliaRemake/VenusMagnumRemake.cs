﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Weapon.ValliaRemake
{
    public class VenusMagnumRemake : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.AddTranslation(7, "维纳斯万能枪");
            //DisplayName.AddTranslation(1, "Venus Magnum");
            Terraria.GameContent.Creative.CreativeItemSacrificesCatalog.Instance.SacrificeCountNeededByItemId[Type] = 1;
            //Tooltip.AddTranslation(7, "“实至名归，万能枪现在能够模仿几乎所有枪械了。”\n" +
            //    "这把枪的普通攻击会把所有子弹变成叶绿弹（模仿的子弹不会）。\n" +
            //    "当玩家有以下武器时，此枪会模仿出那把武器的效果;\n" +
            //    "机枪类：\n" +
            //    "当玩家拥有机枪类武器时，这把枪会会额外射出火枪子弹，造成0.5倍伤害。\n" +
            //    "当玩家拥有巨兽鲨时，这把枪会增加4点伤害。\n" +
            //    "当玩家拥有星璇机枪时，这把枪会增加8点伤害。\n" +
            //    "当玩家拥有太空海豚机关枪时，这把枪会增加12点伤害。\n" +
            //    "狙击枪：\n" +
            //    "当玩家拥有狙击步枪时，这把枪会会额外射出高射速子弹，造成2倍伤害，这把枪会增加5点伤害。\n" +
            //    "霰弹枪：\n" +
            //    "当玩家拥有霰弹枪类武器时，这把枪会会额外射出爆炸子弹，造成0.8倍伤害，且子弹会散射。\n" +
            //    "当玩家拥有战术霰弹枪时，这把枪会增加5点伤害。\n" +
            //    "当玩家拥有外星霰弹枪时，这把枪会增加8点伤害。\n" +
            //    "当玩家拥有火箭炮武器时，这把枪会会额外射出雪人火箭，造成1.5倍伤害。\n" +
            //    "当玩家拥有火箭发射器时，这把枪会增加5点伤害。\n" +
            //    "当玩家拥有雪人炮时，这把枪会增加8点伤害。\n" +
            //    "当玩家拥有超级星星炮时，这把枪会会额外射出星星，造成1.2倍伤害，这把枪会增加4点伤害。\n" +
            //    "当玩家拥有玉米糖果步枪时，这把枪会会额外射出玉米糖，造成1次伤害，这把枪会增加4点伤害。\n" +
            //    "有40%几率不消耗子弹\n" +
            //    "“只可惜这把枪不能模仿“kitchenGun”");

            //Tooltip.AddTranslation(1, "Just like the name,This weapon can imitate Almost all Guns.\n" +
            //    "This gun only can shoot Chlorophyte bullet. \n" +
            //    "Machine gun class：\n" +
            //    "when player using Machine gun class weapons ,this gun will extra shoot a bullet , will make 50% weapon damage to enemies.\n" +
            //    "When player have Megashark in inventory this gun will increase 4 damage.\n" +
            //    "When player have VortexBeater in inventory this gun will increase 8 damage.\n" +
            //    "When player have S.D.M.G. in inventory this gun will increase 12 damage.\n" +
            //    "Sniper Rifle class：\n" +
            //    "When player have Sniper Rifle in inventory this gun will increase 5 damage .this gun will extra shoot a high velocity bullet , will make 200% weapon damage to enemies.\n" +
            //    "Shotgun class class：\n" +
            //    "when player using Shotgun class weapons ,this gun will extra shoot a Exploding bullet, will make 80% weapon damage to enemies ,the all bullet will scatter.\n" +
            //    "When player have Tactical Shotgun in inventory this gun will increase 5 damage.\n" +
            //    "When player have Xeno popper in inventory this gun will increase 8 damage.\n" +
            //    "when player using Cannon/Rocket luncher class weapons ,this gun will extra shoot a Rocket , will make 150% weapon damage to enemies.\n" +
            //    "When player have Rocket luncher in inventory this gun will increase 5 damage.\n" +
            //    "When player have Snowman Cannon in inventory this gun will increase 8 damage.\n" +
            //    "When player have Super star shooter in inventory this gun will increase 4 damage,this gun will extra shoot a Star, will make 120% weapon damage to enemies.\n" +
            //    "When player have Candy Corn Rifle in inventory this gun will increase 4 damage,this gun will extra shoot a CandyCorn, will make weapon damage to enemies.\n" +
            //    "40% chance to not Consume ammo.\n" +
            //    "“Unfortunately, this gun cannot be imitate “kitchenGun”.");
        }

        public override void SetDefaults()
        {
            Item.damage = 38;
            Item.knockBack = 5.25f;
            Item.crit = 4;
            Item.rare = 7;
            Item.useTime = 8;
            Item.useAnimation = 8;
            Item.useStyle = 5;
            Item.autoReuse = true;
            Item.DamageType = DamageClass.Ranged;
            Item.value = Item.sellPrice(0, 0, 60, 0);
            Item.UseSound = SoundID.Item41;
            Item.width = 24;
            Item.height = 24;
            Item.scale = 1f;
            Item.maxStack = 1;
            Item.noMelee = true;
            Item.shootSpeed = 13.5f;
            Item.shoot = ProjectileID.BulletHighVelocity;
            Item.useAmmo = AmmoID.Bullet;
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2(2f, 0f);
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(82, 171, 68));
                }
            }
        }

        public override void ModifyWeaponDamage(Player player, ref StatModifier damage)
        {
            Item.damage = 38;
            foreach (Item item in player.inventory)
            {
                if (item.type == 533)
                {
                    Item.damage += 4;
                }
                if (item.type == 3475)
                {
                    Item.damage += 8;
                }
                if (item.type == 1553)
                {
                    Item.damage += 12;
                }
                if (item.type == 1254)
                {
                    Item.damage += 5;
                }
                if (item.type == 759)
                {
                    Item.damage += 5;
                }
                if (item.type == 1946)
                {
                    Item.damage += 10;
                }
                if (item.type == 679)
                {
                    Item.damage += 5;
                }
                if (item.type == 2797)
                {
                    Item.damage += 8;
                }
                if (item.type == 4060)
                {
                    Item.damage += 4;
                    break;
                }
            }

            base.ModifyWeaponDamage(player, ref damage);
        }

        public override bool CanConsumeAmmo(Item ammo, Player player) => Main.rand.Next(100) > 40;

        public override void ModifyShootStats(Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback)
        {
            type = 207;
            Projectile.NewProjectile(null, position, velocity, 207, (int)((double)damage), Item.knockBack, Main.myPlayer, 0, 0);
            foreach (Item item in player.inventory)
            {
                if (item.type == 533 || item.type == 1553 || item.type == 3475)
                {
                    Projectile.NewProjectile(null, position, velocity, 14, (int)((double)damage * 0.5), Item.knockBack, Main.myPlayer, 0, 0);
                }
                if (item.type == 1254)
                {
                    Projectile.NewProjectile(null, position, velocity, 242, (int)((double)damage * 2), Item.knockBack, Main.myPlayer, 0, 0);
                }
                if (item.type == 1782)
                {
                    Projectile.NewProjectile(null, position, velocity, 311, (int)((double)damage), Item.knockBack, Main.myPlayer, 0, 0);
                }
                if (item.type == 759 || item.type == 1946)
                {
                    Projectile.NewProjectile(null, position, velocity, 338, (int)((double)damage * 1.5), Item.knockBack, Main.myPlayer, 0, 0);
                }
                if (item.type == 679 || item.type == 2797)
                {
                    velocity.X += Main.rand.Next(-5, 5);
                    velocity.Y += Main.rand.Next(-5, 5);
                    Projectile.NewProjectile(null, position, velocity, 286, (int)((double)damage * 0.8), Item.knockBack, Main.myPlayer, 0, 0);
                }
                if (item.type == 4060)
                {
                    Projectile.NewProjectile(null, position, velocity, 728, (int)((double)damage * 1.2), Item.knockBack, Main.myPlayer, 0, 0);
                    break;
                }
            }
            base.ModifyShootStats(player, ref position, ref velocity, ref type, ref damage, ref knockback);
        }
    }
}