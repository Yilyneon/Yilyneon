﻿using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Weapon.ValliaRemake
{
    public class RecipeChanger : GlobalItem
    {
        public override void SetDefaults(Item item)
        {
            if (item.type == ItemID.PhoenixBlaster)//重置物品凤凰冲击波
            {
                item.SetDefaults(ModContent.ItemType<PhoenixBlasterRemake>(), false);
            }

        }

    }
}

