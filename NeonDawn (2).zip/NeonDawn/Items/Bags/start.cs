﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using NeonDawn.Projs.NoSort;

using System.Collections.Generic;

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Bags
{
    public class start : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("物资牵引器");
            //Tooltip.SetDefault("一个物资牵引器\n" +
            //    "可以呼唤一个载有基础物品的空投\n" +
            //    "“放心用，没问题的。”探测器的音响重复地说道");
        }

        public override void SetDefaults()
        {
            base.Item.width = (base.Item.height = 16);
            base.Item.rare = 4;
            base.Item.maxStack = 99;
            base.Item.useStyle = 4;
            base.Item.consumable = true;
            base.Item.useTime = (base.Item.useAnimation = 20);
            base.Item.noMelee = true;
            Item.rare = ItemRarityID.Red;
            base.Item.shoot = ModContent.ProjectileType<Startproj>();
            base.Item.shootSpeed = 20f;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(255, 102, 204));
                }
            }
        }

        public override void PostDrawInInventory(SpriteBatch sb, Vector2 position, Rectangle frame, Color drawColor, Color ItemColor, Vector2 origin, float scale)
        {
            sb.Draw(ModContent.Request<Texture2D>("NeonDawn/Items/Bags/start_Glow").Value, position, frame, (new Color(150, Main.DiscoG, 255)), 0f, origin, scale, SpriteEffects.None, 0f);
        }

        public override void ModifyShootStats(Player player, ref Vector2 position, ref Vector2 velocity, ref int type, ref int damage, ref float knockback)
        {
            if (Main.myPlayer == player.whoAmI)
            {
                position.X = Main.MouseWorld.X;
                position.Y = player.Center.Y - 800f;
                velocity.X = (float)Main.rand.Next(0, 0);
                velocity.Y = (float)Main.rand.Next(0, 0);
            }
            base.ModifyShootStats(player, ref position, ref velocity, ref type, ref damage, ref knockback);
        }
    }
}