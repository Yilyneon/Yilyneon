﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NeonDawn.Items.Bags
{
    public class EnterVoucher : ModItem
    {
        public override void SetStaticDefaults()
        {
            //DisplayName.SetDefault("旅行者身份凭证");
            //Tooltip.SetDefault("这是一个统一发放给每个旅行者的证件，请妥善保管\n" +
            //"上面会实时记录你的信息\n" +
            //"最后，感谢您选择了第13个附属宇宙NeonDawn进行体验\n" +
            //"本物品除了信息展示外，也会为您提供一些实质性的帮助\n" +
            //"在您的背包中收藏此物品后，它会实时报时与显示您的位置");
        }

        public override void SetDefaults()
        {
            Item.glowMask = (short)NeonDawn.MyGlows["EnterVoucher"];
            Item.width = 58;
            Item.height = 48;
            Item.rare = ItemRarityID.Red;
        }

        public override void ModifyTooltips(List<TooltipLine> tooltips)
        {
            Player player = Main.player[Main.myPlayer];
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("旅行者名称：" + player.name))
            {
                OverrideColor = new Color?(new Color(255, 255, 255))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("旅行者生命值: {0}", player.statLifeMax2))
            {
                OverrideColor = new Color?(new Color(241, 139, 63))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("旅行者防御力: {0}点", player.statDefense))
            {
                OverrideColor = new Color?(new Color(241, 139, 63))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("生命回复: 速度{0}", player.lifeRegen))
            {
                OverrideColor = new Color?(new Color(205, 45, 45))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("旅行者魔力值: {0}", player.statManaMax2))
            {
                OverrideColor = new Color?(new Color(63, 139, 241))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("近战暴击率加成: {0}%", player.GetCritChance(DamageClass.Melee)))
            {
                OverrideColor = new Color?(new Color(255, 218, 76))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("远程暴击率加成: {0}%", player.GetCritChance(DamageClass.Ranged)))
            {
                OverrideColor = new Color?(new Color(188, 253, 68))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("魔法暴击率加成: {0}%", player.GetCritChance(DamageClass.Magic)))
            {
                OverrideColor = new Color?(new Color(255, 83, 255))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("最大召唤物数量: {0}", player.maxMinions))
            {
                OverrideColor = new Color?(new Color(0, 255, 255))
            });
            tooltips.Add(new TooltipLine(base.Mod, "info", string.Format("最大炮台数量: {0}", player.maxTurrets))
            {
                OverrideColor = new Color?(new Color(0, 255, 255))
            });
        }

        public override void UpdateInventory(Player player)
        {
            if (base.Item.favorited)
            {
                player.GetModPlayer<AccessoryValidLibrary>().EnterVoucher = true;
            }
        }
    }
}