﻿using Microsoft.Xna.Framework;

using System.Collections.Generic;

using Terraria.ModLoader;

namespace NeonDawn.Items.Materials
{
    public class Scrap : ModItem
    {
        public override void SetStaticDefaults()
        {
            //base.DisplayName.SetDefault("废铁");
            //Tooltip.SetDefault("“物质牵引器爆炸后剩余的废铁，或许可以回收利用？”");
        }

        public override void SetDefaults()
        {
            base.Item.width = 15;
            base.Item.height = 12;
            base.Item.maxStack = 9999;
            base.Item.value = 250;
            base.Item.rare = 3;
        }

        public override void ModifyTooltips(List<TooltipLine> list)
        {
            foreach (TooltipLine tooltipLine in list)
            {
                if (tooltipLine.Mod == "Terraria" && tooltipLine.Name == "ItemName")
                {
                    tooltipLine.OverrideColor = new Color?(new Color(97, 87, 86));
                }
            }
        }
    }
}